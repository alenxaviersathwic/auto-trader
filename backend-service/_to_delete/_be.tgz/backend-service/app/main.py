import time
from contextlib import asynccontextmanager
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
except ImportError:
    from pytz import timezone as ZoneInfo
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from app.core.config.settings import settings
from app.core.db.session import async_engine, async_session_factory
from app.core.exception.exception_handlers import register_exception_handlers
from app.core.logging.logger import (
    BOLD,
    BRIGHT_BLACK,
    BRIGHT_CYAN,
    BRIGHT_GREEN,
    BRIGHT_RED,
    BRIGHT_YELLOW,
    CYAN,
    GREEN,
    MAGENTA,
    RED,
    RESET,
    YELLOW,
    BRIGHT_WHITE,
    DIM,
    logger,
    setup_logging,
)
from app.core.logging.http_logger import HttpTrafficLoggingMiddleware
from app.core.response.api_response import ApiResponse
from app.core.response.response_helper import success
from app.core.scheduler.scheduler import shutdown_scheduler, start_scheduler
from app.modules.strategies.service.seed_service import SeedService


BANNER = rf"""
{BRIGHT_CYAN}{BOLD}
   ____           __           ______     _     __
  / __ \_________ / /__  _____ / ____/____(_)___/ /
 / / / / ___/ __  / _ \/ ___/ / / __/ ___/ / __  / 
/ /_/ / /  / /_/ /  __/ /    / /_/ / /  / / /_/ /  
\____/_/   \__,_/\___/_/     \____/_/  /_/\__,_/   
{RESET}{BRIGHT_BLACK}────────────────────────────────────────────────────────────────────────{RESET}
 {BRIGHT_WHITE}OrderGrid Unified High-Frequency Trading Core{RESET}
 • {DIM}Environment:{RESET}  {BRIGHT_GREEN}{settings.APP_ENV}{RESET}
 • {DIM}Worker Mode:{RESET}  {BRIGHT_CYAN}Single Uvicorn Worker (PID bound){RESET}
 • {DIM}Scheduler:{RESET}    {BRIGHT_YELLOW}APScheduler (Timezone: {settings.SCHEDULER_TIMEZONE}){RESET}
 • {DIM}Encryption:{RESET}   {BRIGHT_GREEN}AES-GCM Master Key Loaded{RESET}
{BRIGHT_BLACK}────────────────────────────────────────────────────────────────────────{RESET}
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.
    Runs on single uvicorn worker.
    """
    setup_logging()
    print(BANNER)
    logger.info(f"Booting {settings.APP_NAME} in [{settings.APP_ENV}] mode...")

    # 1. Verify DB connection & apply idempotent opportunities table rename if needed
    try:
        async with async_session_factory() as session:
            await session.execute(text("SELECT 1"))
            for stmt in (
                "ALTER TABLE IF EXISTS suggestion_runs RENAME TO opportunity_runs;",
                "ALTER TABLE IF EXISTS suggestion_masters RENAME TO opportunity_masters;",
                "DO $$ BEGIN IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='opportunity_masters' AND column_name='suggestions_total') THEN ALTER TABLE opportunity_masters RENAME COLUMN suggestions_total TO opportunities_total; END IF; END $$;",
                "DO $$ BEGIN IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='opportunity_masters' AND column_name='last_suggestion_count') THEN ALTER TABLE opportunity_masters RENAME COLUMN last_suggestion_count TO last_opportunity_count; END IF; END $$;",
                "ALTER INDEX IF EXISTS ix_suggestion_masters_day_code RENAME TO ix_opportunity_masters_day_code;",
                "ALTER INDEX IF EXISTS uq_suggestion_masters_day_code_session RENAME TO uq_opportunity_masters_day_code_session;",
                "ALTER INDEX IF EXISTS ix_suggestion_masters_state RENAME TO ix_opportunity_masters_state;",
                "ALTER TABLE IF EXISTS trade_suggestions RENAME TO trade_opportunities;",
                "ALTER INDEX IF EXISTS ix_trade_suggestions_master_id RENAME TO ix_trade_opportunities_master_id;",
                "ALTER INDEX IF EXISTS ix_trade_suggestions_code_latest RENAME TO ix_trade_opportunities_code_latest;",
                "ALTER INDEX IF EXISTS ix_trade_suggestions_outcome RENAME TO ix_trade_opportunities_outcome;",
                "ALTER TABLE IF EXISTS suggestion_memories RENAME TO opportunity_memories;",
                "DO $$ BEGIN IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='opportunity_memories' AND column_name='suggestion_id') THEN ALTER TABLE opportunity_memories RENAME COLUMN suggestion_id TO opportunity_id; END IF; END $$;",
                "ALTER INDEX IF EXISTS ix_suggestion_memories_underlying RENAME TO ix_opportunity_memories_underlying;",
            ):
                await session.execute(text(stmt))
            await session.commit()
        logger.info(f"{BRIGHT_GREEN}PostgreSQL & pgvector connection established successfully.{RESET}")
    except Exception as e:
        logger.error(f"Database connection check warning: {e}")

    # 2. Seed strategy/rule registry (idempotent -- checks by code, skips what already exists).
    # Includes the Oct-2026 research-backed strategy + guardrail registry
    # (task wf-73cd02ba-57fd-81e6-bc87-e3915505046a).
    try:
        async with async_session_factory() as session:
            seed_res = await SeedService().seed_defaults(session)
            await session.commit()
        logger.info(f"{BRIGHT_GREEN}Strategy/rule registry seeded: {seed_res}{RESET}")
    except Exception as e:
        logger.error(f"Strategy/rule registry seeding failed on startup: {e}")

    # 3. Resume the loop of every ACTIVE MANUAL session dated today (their loops died with the last process)
    try:
        from app.modules.sessions.engine import session_loop_runner

        resumed = await session_loop_runner.resume_today()
        logger.info(f"{BRIGHT_GREEN}Session loops resumed: {resumed}{RESET}")
    except Exception as e:
        logger.error(f"Session loop resume failed on startup: {e}")

    # 3b. Daily 16:00 IST: finished sessions' picks move to session_picks_archive (also run now to catch up)
    try:
        from app.modules.sessions.job.session_picks_archive_job import (
            archive_finished_session_picks,
            register_archive_job,
        )

        await archive_finished_session_picks()
        register_archive_job()
    except Exception as e:
        logger.error(f"Session picks archive setup failed: {e}")

    # 4. Start scheduler
    start_scheduler()
    logger.info(f"{BRIGHT_YELLOW}APScheduler started with timezone {settings.SCHEDULER_TIMEZONE}.{RESET}")

    yield

    # Shutdown sequence
    logger.info("Initiating graceful shutdown sequence...")
    shutdown_scheduler()
    try:
        from app.modules.sessions.engine import session_loop_runner

        await session_loop_runner.stop_all()
    except Exception as e:
        logger.error(f"Session loop shutdown failed: {e}")
    await async_engine.dispose()
    logger.info("Database connection pools disposed. Shutdown clean.")


def create_application() -> FastAPI:
    """FastAPI Application factory."""
    app = FastAPI(
        title=settings.APP_NAME,
        version="0.1.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # CORS configuration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Global unified exception handling
    register_exception_handlers(app)

    # Detailed HTTP Traffic Logger (Request & Response with Headers, Body & Timing)
    app.add_middleware(HttpTrafficLoggingMiddleware)

    # Base & Healthcheck Routes
    @app.get(
        "/health",
        include_in_schema=False,
    )
    @app.get(
        "/api/v1/health",
        response_model=ApiResponse[dict],
        status_code=status.HTTP_200_OK,
        tags=["System"],
    )
    async def health_check():
        """Universal healthcheck returning standard ApiResponse envelope."""
        db_connected = False
        vector_available = False
        try:
            async with async_session_factory() as session:
                res = await session.execute(text("SELECT 1"))
                if res.scalar() == 1:
                    db_connected = True
                ext_res = await session.execute(
                    text("SELECT 1 FROM pg_extension WHERE extname = 'vector'")
                )
                if ext_res.scalar() == 1:
                    vector_available = True
        except Exception:
            db_connected = False

        tz = ZoneInfo(settings.SCHEDULER_TIMEZONE)
        now_local = datetime.now(tz).isoformat()

        health_data = {
            "status": "healthy" if db_connected else "degraded",
            "environment": settings.APP_ENV,
            "timestamp": now_local,
            "timezone": settings.SCHEDULER_TIMEZONE,
            "database": {
                "connected": db_connected,
                "pgvector": vector_available,
            },
        }

        return success(data=health_data, message="System is operational")

    # Feature Module Routers
    from app.modules.users.controller import oauth_router, user_router
    from app.modules.strategies.controller import (
        strategy_router,
        rule_router,
    )
    from app.modules.strategies.mcp import strategy_mcp_router
    from app.modules.master.controller import master_router
    from app.modules.research.controller import research_router
    from app.modules.research.mcp import research_mcp_router
    from app.modules.research.engine import research_engine  # auto-registers research engine
    from app.modules.opportunities.controller import opportunity_router
    from app.modules.opportunities.engine import opportunity_engine  # auto-registers opportunities engine
    from app.modules.sessions.controller import session_pick_router, session_router

    app.include_router(user_router, prefix=settings.API_V1_PREFIX)
    app.include_router(oauth_router, prefix=settings.API_V1_PREFIX)

    app.include_router(strategy_router, prefix=settings.API_V1_PREFIX)
    app.include_router(rule_router, prefix=settings.API_V1_PREFIX)
    app.include_router(master_router, prefix=settings.API_V1_PREFIX)
    app.include_router(research_router, prefix=settings.API_V1_PREFIX)
    app.include_router(opportunity_router, prefix=settings.API_V1_PREFIX)
    app.include_router(session_router, prefix=settings.API_V1_PREFIX)
    app.include_router(session_pick_router, prefix=settings.API_V1_PREFIX)

    app.include_router(strategy_mcp_router)
    app.include_router(research_mcp_router)

    return app


app = create_application()
