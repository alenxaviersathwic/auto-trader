"""auto-trader application package."""
