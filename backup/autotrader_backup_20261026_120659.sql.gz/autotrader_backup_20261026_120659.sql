--
-- PostgreSQL database dump
--

\restrict DaWsDv7yuQSzNQ5cjozsvH1epF3AwO0nxxK4JogjTf9gFoMhAAkHF3pjvqyLyVj

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg12+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_versions DROP CONSTRAINT IF EXISTS strategy_versions_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_rules DROP CONSTRAINT IF EXISTS strategy_rules_strategy_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_performance_snapshots DROP CONSTRAINT IF EXISTS strategy_performance_snapshots_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_health_events DROP CONSTRAINT IF EXISTS strategy_health_events_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rule_versions DROP CONSTRAINT IF EXISTS rule_versions_rule_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_run_events DROP CONSTRAINT IF EXISTS research_run_events_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_run_documents DROP CONSTRAINT IF EXISTS research_run_documents_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_run_documents DROP CONSTRAINT IF EXISTS research_run_documents_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_queries DROP CONSTRAINT IF EXISTS research_queries_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_claims DROP CONSTRAINT IF EXISTS research_claims_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_chunks DROP CONSTRAINT IF EXISTS research_chunks_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.research_candidates DROP CONSTRAINT IF EXISTS research_candidates_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_tool_calls DROP CONSTRAINT IF EXISTS master_tool_calls_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_runs DROP CONSTRAINT IF EXISTS master_runs_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_proposals DROP CONSTRAINT IF EXISTS master_proposals_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_proposals DROP CONSTRAINT IF EXISTS master_proposals_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_messages DROP CONSTRAINT IF EXISTS master_messages_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.master_messages DROP CONSTRAINT IF EXISTS master_messages_conversation_id_fkey;
DROP INDEX IF EXISTS public.uq_research_underlyings_code;
DROP INDEX IF EXISTS public.uq_research_risk_terms_term;
DROP INDEX IF EXISTS public.uq_research_documents_url_hash;
DROP INDEX IF EXISTS public.ix_users_name_active;
DROP INDEX IF EXISTS public.ix_upstox_configs_user_id_active;
DROP INDEX IF EXISTS public.ix_strategy_versions_strat_ver_active;
DROP INDEX IF EXISTS public.ix_strategies_code_active;
DROP INDEX IF EXISTS public.ix_rules_code_active;
DROP INDEX IF EXISTS public.ix_rule_versions_rule_ver_active;
DROP INDEX IF EXISTS public.ix_registry_items_type_code_active;
DROP INDEX IF EXISTS public.ix_health_policies_code_active;
DROP INDEX IF EXISTS public.idx_research_underlyings_type;
DROP INDEX IF EXISTS public.idx_research_underlyings_status;
DROP INDEX IF EXISTS public.idx_research_sources_type;
DROP INDEX IF EXISTS public.idx_research_sources_status;
DROP INDEX IF EXISTS public.idx_research_runs_status;
DROP INDEX IF EXISTS public.idx_research_runs_state;
DROP INDEX IF EXISTS public.idx_research_runs_created_at;
DROP INDEX IF EXISTS public.idx_research_run_events_run_id;
DROP INDEX IF EXISTS public.idx_research_run_docs_run_id;
DROP INDEX IF EXISTS public.idx_research_risk_terms_status;
DROP INDEX IF EXISTS public.idx_research_queries_run_id;
DROP INDEX IF EXISTS public.idx_research_documents_published_at;
DROP INDEX IF EXISTS public.idx_research_documents_domain;
DROP INDEX IF EXISTS public.idx_research_config_version;
DROP INDEX IF EXISTS public.idx_research_claims_embedding;
DROP INDEX IF EXISTS public.idx_research_claims_doc;
DROP INDEX IF EXISTS public.idx_research_claims_code;
DROP INDEX IF EXISTS public.idx_research_chunks_embedding;
DROP INDEX IF EXISTS public.idx_research_chunks_doc_id;
DROP INDEX IF EXISTS public.idx_research_candidates_run_id;
DROP INDEX IF EXISTS public.idx_research_candidates_code;
DROP INDEX IF EXISTS public.idx_research_candidates_brief_embedding;
DROP INDEX IF EXISTS public.idx_master_tool_servers_name_active;
DROP INDEX IF EXISTS public.idx_master_tool_policies_server_tool_active;
DROP INDEX IF EXISTS public.idx_master_tool_calls_tool_name;
DROP INDEX IF EXISTS public.idx_master_tool_calls_run_id;
DROP INDEX IF EXISTS public.idx_master_runs_state;
DROP INDEX IF EXISTS public.idx_master_runs_conversation_id;
DROP INDEX IF EXISTS public.idx_master_proposals_status;
DROP INDEX IF EXISTS public.idx_master_proposals_conversation_id;
DROP INDEX IF EXISTS public.idx_master_preferences_key_active;
DROP INDEX IF EXISTS public.idx_master_messages_conv_seq;
DROP INDEX IF EXISTS public.idx_master_conversations_status;
DROP INDEX IF EXISTS public.idx_master_conversations_last_msg;
DROP INDEX IF EXISTS public.idx_master_configs_key_active;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_versions DROP CONSTRAINT IF EXISTS strategy_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_rules DROP CONSTRAINT IF EXISTS strategy_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_performance_snapshots DROP CONSTRAINT IF EXISTS strategy_performance_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_health_events DROP CONSTRAINT IF EXISTS strategy_health_events_pkey;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS strategies_pkey;
ALTER TABLE IF EXISTS ONLY public.rules DROP CONSTRAINT IF EXISTS rules_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_versions DROP CONSTRAINT IF EXISTS rule_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.research_underlyings DROP CONSTRAINT IF EXISTS research_underlyings_pkey;
ALTER TABLE IF EXISTS ONLY public.research_sources DROP CONSTRAINT IF EXISTS research_sources_pkey;
ALTER TABLE IF EXISTS ONLY public.research_runs DROP CONSTRAINT IF EXISTS research_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.research_run_events DROP CONSTRAINT IF EXISTS research_run_events_pkey;
ALTER TABLE IF EXISTS ONLY public.research_run_documents DROP CONSTRAINT IF EXISTS research_run_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.research_risk_terms DROP CONSTRAINT IF EXISTS research_risk_terms_pkey;
ALTER TABLE IF EXISTS ONLY public.research_queries DROP CONSTRAINT IF EXISTS research_queries_pkey;
ALTER TABLE IF EXISTS ONLY public.research_documents DROP CONSTRAINT IF EXISTS research_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.research_config DROP CONSTRAINT IF EXISTS research_config_pkey;
ALTER TABLE IF EXISTS ONLY public.research_claims DROP CONSTRAINT IF EXISTS research_claims_pkey;
ALTER TABLE IF EXISTS ONLY public.research_chunks DROP CONSTRAINT IF EXISTS research_chunks_pkey;
ALTER TABLE IF EXISTS ONLY public.research_candidates DROP CONSTRAINT IF EXISTS research_candidates_pkey;
ALTER TABLE IF EXISTS ONLY public.registry_items DROP CONSTRAINT IF EXISTS registry_items_pkey;
ALTER TABLE IF EXISTS ONLY public.master_tool_servers DROP CONSTRAINT IF EXISTS master_tool_servers_pkey;
ALTER TABLE IF EXISTS ONLY public.master_tool_policies DROP CONSTRAINT IF EXISTS master_tool_policies_pkey;
ALTER TABLE IF EXISTS ONLY public.master_tool_calls DROP CONSTRAINT IF EXISTS master_tool_calls_pkey;
ALTER TABLE IF EXISTS ONLY public.master_runs DROP CONSTRAINT IF EXISTS master_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.master_proposals DROP CONSTRAINT IF EXISTS master_proposals_pkey;
ALTER TABLE IF EXISTS ONLY public.master_preferences DROP CONSTRAINT IF EXISTS master_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.master_messages DROP CONSTRAINT IF EXISTS master_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.master_conversations DROP CONSTRAINT IF EXISTS master_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.master_configs DROP CONSTRAINT IF EXISTS master_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.health_policies DROP CONSTRAINT IF EXISTS health_policies_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.upstox_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_performance_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_health_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_underlyings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_sources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_run_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_run_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_risk_terms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_queries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_config ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_claims ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_chunks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.research_candidates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.registry_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_tool_servers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_tool_policies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_tool_calls ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_proposals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_preferences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.import_batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.health_policies ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.upstox_configs_id_seq;
DROP TABLE IF EXISTS public.upstox_configs;
DROP SEQUENCE IF EXISTS public.strategy_versions_id_seq;
DROP TABLE IF EXISTS public.strategy_versions;
DROP SEQUENCE IF EXISTS public.strategy_rules_id_seq;
DROP TABLE IF EXISTS public.strategy_rules;
DROP SEQUENCE IF EXISTS public.strategy_performance_snapshots_id_seq;
DROP TABLE IF EXISTS public.strategy_performance_snapshots;
DROP SEQUENCE IF EXISTS public.strategy_health_events_id_seq;
DROP TABLE IF EXISTS public.strategy_health_events;
DROP SEQUENCE IF EXISTS public.strategies_id_seq;
DROP TABLE IF EXISTS public.strategies;
DROP SEQUENCE IF EXISTS public.rules_id_seq;
DROP TABLE IF EXISTS public.rules;
DROP SEQUENCE IF EXISTS public.rule_versions_id_seq;
DROP TABLE IF EXISTS public.rule_versions;
DROP SEQUENCE IF EXISTS public.research_underlyings_id_seq;
DROP TABLE IF EXISTS public.research_underlyings;
DROP SEQUENCE IF EXISTS public.research_sources_id_seq;
DROP TABLE IF EXISTS public.research_sources;
DROP SEQUENCE IF EXISTS public.research_runs_id_seq;
DROP TABLE IF EXISTS public.research_runs;
DROP SEQUENCE IF EXISTS public.research_run_events_id_seq;
DROP TABLE IF EXISTS public.research_run_events;
DROP SEQUENCE IF EXISTS public.research_run_documents_id_seq;
DROP TABLE IF EXISTS public.research_run_documents;
DROP SEQUENCE IF EXISTS public.research_risk_terms_id_seq;
DROP TABLE IF EXISTS public.research_risk_terms;
DROP SEQUENCE IF EXISTS public.research_queries_id_seq;
DROP TABLE IF EXISTS public.research_queries;
DROP SEQUENCE IF EXISTS public.research_documents_id_seq;
DROP TABLE IF EXISTS public.research_documents;
DROP SEQUENCE IF EXISTS public.research_config_id_seq;
DROP TABLE IF EXISTS public.research_config;
DROP SEQUENCE IF EXISTS public.research_claims_id_seq;
DROP TABLE IF EXISTS public.research_claims;
DROP SEQUENCE IF EXISTS public.research_chunks_id_seq;
DROP TABLE IF EXISTS public.research_chunks;
DROP SEQUENCE IF EXISTS public.research_candidates_id_seq;
DROP TABLE IF EXISTS public.research_candidates;
DROP SEQUENCE IF EXISTS public.registry_items_id_seq;
DROP TABLE IF EXISTS public.registry_items;
DROP SEQUENCE IF EXISTS public.master_tool_servers_id_seq;
DROP TABLE IF EXISTS public.master_tool_servers;
DROP SEQUENCE IF EXISTS public.master_tool_policies_id_seq;
DROP TABLE IF EXISTS public.master_tool_policies;
DROP SEQUENCE IF EXISTS public.master_tool_calls_id_seq;
DROP TABLE IF EXISTS public.master_tool_calls;
DROP SEQUENCE IF EXISTS public.master_runs_id_seq;
DROP TABLE IF EXISTS public.master_runs;
DROP SEQUENCE IF EXISTS public.master_proposals_id_seq;
DROP TABLE IF EXISTS public.master_proposals;
DROP SEQUENCE IF EXISTS public.master_preferences_id_seq;
DROP TABLE IF EXISTS public.master_preferences;
DROP SEQUENCE IF EXISTS public.master_messages_id_seq;
DROP TABLE IF EXISTS public.master_messages;
DROP SEQUENCE IF EXISTS public.master_conversations_id_seq;
DROP TABLE IF EXISTS public.master_conversations;
DROP SEQUENCE IF EXISTS public.master_configs_id_seq;
DROP TABLE IF EXISTS public.master_configs;
DROP SEQUENCE IF EXISTS public.import_batches_id_seq;
DROP TABLE IF EXISTS public.import_batches;
DROP SEQUENCE IF EXISTS public.health_policies_id_seq;
DROP TABLE IF EXISTS public.health_policies;
DROP TABLE IF EXISTS public.alembic_version;
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: health_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_policies (
    id bigint NOT NULL,
    code character varying(60) NOT NULL,
    name character varying(120) NOT NULL,
    scope jsonb DEFAULT '"ALL"'::jsonb NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.health_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: health_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.health_policies_id_seq OWNED BY public.health_policies.id;


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id bigint NOT NULL,
    file_name character varying(255) NOT NULL,
    source_format character varying(20) NOT NULL,
    mode character varying(10) DEFAULT 'SKIP'::character varying NOT NULL,
    dry_run boolean DEFAULT false NOT NULL,
    total_items integer DEFAULT 0 NOT NULL,
    created_count integer DEFAULT 0 NOT NULL,
    updated_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    errors jsonb,
    warnings jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.import_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.import_batches_id_seq OWNED BY public.import_batches.id;


--
-- Name: master_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_configs (
    id bigint NOT NULL,
    config_key character varying(80) NOT NULL,
    config_value jsonb NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_configs_id_seq OWNED BY public.master_configs.id;


--
-- Name: master_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_conversations (
    id bigint NOT NULL,
    title character varying(150) DEFAULT 'New Conversation'::character varying NOT NULL,
    summary text,
    last_message_at timestamp with time zone DEFAULT now() NOT NULL,
    message_count integer DEFAULT 0 NOT NULL,
    created_by_user_id bigint,
    archived boolean DEFAULT false NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_conversations_id_seq OWNED BY public.master_conversations.id;


--
-- Name: master_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    seq integer NOT NULL,
    role character varying(10) NOT NULL,
    content text NOT NULL,
    blocks jsonb,
    run_id bigint,
    redacted boolean DEFAULT false NOT NULL,
    model character varying(80),
    tokens_in integer,
    tokens_out integer,
    latency_ms integer,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_messages_id_seq OWNED BY public.master_messages.id;


--
-- Name: master_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_preferences (
    id bigint NOT NULL,
    key character varying(80) NOT NULL,
    value jsonb NOT NULL,
    source_message_id bigint,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_preferences_id_seq OWNED BY public.master_preferences.id;


--
-- Name: master_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_proposals (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    message_id bigint,
    kind character varying(30) NOT NULL,
    target_type character varying(30),
    target_code character varying(100),
    user_text text NOT NULL,
    back_translation text NOT NULL,
    payload jsonb NOT NULL,
    diff jsonb,
    complications jsonb NOT NULL,
    assumptions jsonb NOT NULL,
    structure_analysis jsonb,
    validation jsonb,
    content_hash character varying(64) NOT NULL,
    proposal_status character varying(15) DEFAULT 'PENDING'::character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    confirmed_at timestamp with time zone,
    confirm_mode character varying(25),
    result_refs jsonb,
    failure_reason character varying(500),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_proposals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_proposals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_proposals_id_seq OWNED BY public.master_proposals.id;


--
-- Name: master_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_runs (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    user_message_id bigint,
    state character varying(15) DEFAULT 'RUNNING'::character varying NOT NULL,
    intent character varying(25),
    thread_id character varying(60) NOT NULL,
    iterations integer DEFAULT 0 NOT NULL,
    tool_call_count integer DEFAULT 0 NOT NULL,
    clarification_round integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    error character varying(500),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_runs_id_seq OWNED BY public.master_runs.id;


--
-- Name: master_tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_tool_calls (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    server_name character varying(60) NOT NULL,
    tool_name character varying(80) NOT NULL,
    tier character varying(10) NOT NULL,
    arguments jsonb,
    result_summary jsonb,
    call_status character varying(10) NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_tool_calls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_tool_calls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_tool_calls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_tool_calls_id_seq OWNED BY public.master_tool_calls.id;


--
-- Name: master_tool_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_tool_policies (
    id bigint NOT NULL,
    server_name character varying(60) NOT NULL,
    tool_name character varying(80) NOT NULL,
    tier character varying(10) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    auto_approve boolean DEFAULT false NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_tool_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_tool_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_tool_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_tool_policies_id_seq OWNED BY public.master_tool_policies.id;


--
-- Name: master_tool_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_tool_servers (
    id bigint NOT NULL,
    name character varying(60) NOT NULL,
    transport character varying(10) DEFAULT 'HTTP'::character varying NOT NULL,
    url character varying(300),
    auth_ref character varying(60),
    tier_cap character varying(10) DEFAULT 'PROPOSE'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_seen_at timestamp with time zone,
    last_error character varying(300),
    tool_count integer DEFAULT 0 NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_tool_servers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.master_tool_servers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_tool_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.master_tool_servers_id_seq OWNED BY public.master_tool_servers.id;


--
-- Name: registry_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registry_items (
    id bigint NOT NULL,
    registry_type character varying(30) NOT NULL,
    code character varying(60) NOT NULL,
    name character varying(120) NOT NULL,
    kind character varying(10) DEFAULT 'BUILT_IN'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    schema jsonb,
    expression jsonb,
    handler_key character varying(80),
    executable boolean DEFAULT false NOT NULL,
    requires jsonb,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registry_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.registry_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registry_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.registry_items_id_seq OWNED BY public.registry_items.id;


--
-- Name: research_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_candidates (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    underlying_type character varying(10) NOT NULL,
    underlying_code character varying(30) NOT NULL,
    news_status character varying(20) NOT NULL,
    suggested boolean DEFAULT false NOT NULL,
    rank smallint,
    direction character varying(10),
    bearish_watch boolean DEFAULT false NOT NULL,
    score numeric(5,1),
    score_label character varying(8),
    positive_weight numeric(8,3) DEFAULT 0.000 NOT NULL,
    negative_weight numeric(8,3) DEFAULT 0.000 NOT NULL,
    negative_share numeric(4,3) DEFAULT 0.000 NOT NULL,
    positive_claims integer DEFAULT 0 NOT NULL,
    negative_claims integer DEFAULT 0 NOT NULL,
    material_negatives jsonb DEFAULT '[]'::jsonb NOT NULL,
    independent_sources integer DEFAULT 0 NOT NULL,
    fresh_article_count integer DEFAULT 0 NOT NULL,
    newest_article_at timestamp with time zone,
    oldest_article_at timestamp with time zone,
    flags jsonb DEFAULT '[]'::jsonb NOT NULL,
    reasons jsonb DEFAULT '[]'::jsonb NOT NULL,
    thesis text,
    supporting_points jsonb DEFAULT '[]'::jsonb NOT NULL,
    watch_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    citations jsonb DEFAULT '[]'::jsonb NOT NULL,
    brief_embedding public.vector(768),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_candidates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_candidates_id_seq OWNED BY public.research_candidates.id;


--
-- Name: research_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_chunks (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    chunk_index integer NOT NULL,
    text text NOT NULL,
    token_count integer DEFAULT 0 NOT NULL,
    embedding public.vector(768) NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_chunks_id_seq OWNED BY public.research_chunks.id;


--
-- Name: research_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_claims (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    chunk_id bigint,
    underlying_code character varying(30) NOT NULL,
    channel character varying(12) DEFAULT 'DIRECT'::character varying NOT NULL,
    stance character varying(10) NOT NULL,
    magnitude smallint DEFAULT '1'::smallint NOT NULL,
    confidence numeric(3,2) DEFAULT 0.80 NOT NULL,
    horizon character varying(10) DEFAULT 'DAYS'::character varying NOT NULL,
    catalyst character varying(20) DEFAULT 'OTHER'::character varying NOT NULL,
    is_risk_event boolean DEFAULT false NOT NULL,
    event_date date,
    statement character varying(300) NOT NULL,
    quote character varying(500) NOT NULL,
    quote_verified boolean DEFAULT false NOT NULL,
    origin character varying(10) DEFAULT 'EXTRACT'::character varying NOT NULL,
    published_at timestamp with time zone,
    extraction_version character varying(30) DEFAULT 'v1.0'::character varying NOT NULL,
    embedding public.vector(768),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_claims_id_seq OWNED BY public.research_claims.id;


--
-- Name: research_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_config (
    id bigint NOT NULL,
    version integer NOT NULL,
    weights jsonb DEFAULT '{}'::jsonb NOT NULL,
    thresholds jsonb DEFAULT '{}'::jsonb NOT NULL,
    limits jsonb DEFAULT '{}'::jsonb NOT NULL,
    note character varying(200),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_config_id_seq OWNED BY public.research_config.id;


--
-- Name: research_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_documents (
    id bigint NOT NULL,
    url_hash character varying(64) NOT NULL,
    url character varying(1000) NOT NULL,
    canonical_url character varying(1000) NOT NULL,
    domain character varying(120) NOT NULL,
    source_id bigint,
    title character varying(500) NOT NULL,
    published_at timestamp with time zone,
    fetched_at timestamp with time zone NOT NULL,
    content_hash character varying(64) NOT NULL,
    text text NOT NULL,
    word_count integer DEFAULT 0 NOT NULL,
    language character varying(8) DEFAULT 'en'::character varying,
    fetch_status character varying(10) DEFAULT 'OK'::character varying NOT NULL,
    duplicate_of_id bigint,
    first_seen_run_id bigint NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_documents_id_seq OWNED BY public.research_documents.id;


--
-- Name: research_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_queries (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    underlying_code character varying(30),
    query_text character varying(500) NOT NULL,
    provider character varying(30) NOT NULL,
    result_count integer DEFAULT 0 NOT NULL,
    planned_by character varying(20) DEFAULT 'TEMPLATE'::character varying NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_queries_id_seq OWNED BY public.research_queries.id;


--
-- Name: research_risk_terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_risk_terms (
    id bigint NOT NULL,
    term character varying(100) NOT NULL,
    category character varying(30) NOT NULL,
    default_severity smallint DEFAULT '3'::smallint NOT NULL,
    applies_to_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_risk_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_risk_terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_risk_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_risk_terms_id_seq OWNED BY public.research_risk_terms.id;


--
-- Name: research_run_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_run_documents (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    document_id bigint NOT NULL,
    underlying_code character varying(30),
    query_id bigint,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_run_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_run_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_run_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_run_documents_id_seq OWNED BY public.research_run_documents.id;


--
-- Name: research_run_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_run_events (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    seq integer NOT NULL,
    node character varying(40),
    level character varying(10) DEFAULT 'INFO'::character varying NOT NULL,
    message character varying(500) NOT NULL,
    data jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_run_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_run_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_run_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_run_events_id_seq OWNED BY public.research_run_events.id;


--
-- Name: research_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_runs (
    id bigint NOT NULL,
    scope jsonb DEFAULT '["INDEX", "COMMODITY"]'::jsonb NOT NULL,
    trigger_source character varying(10) DEFAULT 'UI'::character varying NOT NULL,
    triggered_by character varying(60),
    state character varying(12) DEFAULT 'QUEUED'::character varying NOT NULL,
    result_kind character varying(20),
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    config_version integer DEFAULT 1 NOT NULL,
    current_node character varying(40),
    progress_pct integer DEFAULT 0 NOT NULL,
    stats jsonb DEFAULT '{}'::jsonb NOT NULL,
    resumable boolean DEFAULT false NOT NULL,
    thread_id character varying(60) NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    error character varying(500),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_runs_id_seq OWNED BY public.research_runs.id;


--
-- Name: research_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_sources (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    source_type character varying(10) NOT NULL,
    base_url character varying(300) NOT NULL,
    feed_url character varying(400),
    credibility_weight numeric(3,2) DEFAULT 0.60 NOT NULL,
    applies_to_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    applies_to_groups jsonb,
    enabled boolean DEFAULT true NOT NULL,
    last_fetch_at timestamp with time zone,
    last_error character varying(300),
    ok_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_sources_id_seq OWNED BY public.research_sources.id;


--
-- Name: research_underlyings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_underlyings (
    id bigint NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    underlying_type character varying(10) NOT NULL,
    group_name character varying(30) NOT NULL,
    exchange character varying(10) NOT NULL,
    aliases jsonb DEFAULT '[]'::jsonb NOT NULL,
    keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    heavyweights jsonb DEFAULT '[]'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_underlyings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_underlyings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_underlyings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_underlyings_id_seq OWNED BY public.research_underlyings.id;


--
-- Name: rule_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_versions (
    id bigint NOT NULL,
    rule_id bigint NOT NULL,
    version_no integer NOT NULL,
    content jsonb NOT NULL,
    change_note character varying(300),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rule_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rule_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rule_versions_id_seq OWNED BY public.rule_versions.id;


--
-- Name: rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rules (
    id bigint NOT NULL,
    code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    rule_kind character varying(15) NOT NULL,
    rule_type character varying(25) NOT NULL,
    action character varying(10),
    priority character varying(8) DEFAULT 'MEDIUM'::character varying NOT NULL,
    applies_to jsonb DEFAULT '{}'::jsonb NOT NULL,
    condition_text text NOT NULL,
    current_version_id bigint,
    evidence jsonb,
    review_by date,
    executable boolean DEFAULT false NOT NULL,
    review_flags jsonb,
    provenance jsonb,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rules_id_seq OWNED BY public.rules.id;


--
-- Name: strategies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategies (
    id bigint NOT NULL,
    code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    category character varying(20) NOT NULL,
    structure character varying(30),
    bias character varying(10),
    option_side character varying(5),
    markets jsonb DEFAULT '[]'::jsonb NOT NULL,
    underlying_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    exchange character varying(10),
    trading_modes jsonb DEFAULT '[]'::jsonb NOT NULL,
    execution_modes jsonb DEFAULT '[]'::jsonb NOT NULL,
    timeframe character varying(10),
    definition_format character varying(10) DEFAULT 'RULE_TREE'::character varying NOT NULL,
    executable boolean DEFAULT false NOT NULL,
    lifecycle_status character varying(12) DEFAULT 'DRAFT'::character varying NOT NULL,
    health character varying(10) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    health_override character varying(10),
    health_override_reason character varying(255),
    health_override_until timestamp with time zone,
    validation_status character varying(15) DEFAULT 'UNTESTED'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    risk_profile jsonb,
    "references" jsonb,
    risk_notes jsonb,
    how_it_works jsonb,
    tags jsonb,
    attributes jsonb,
    provenance jsonb,
    review_flags jsonb,
    current_version_id bigint,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategies_id_seq OWNED BY public.strategies.id;


--
-- Name: strategy_health_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_health_events (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    from_health character varying(10) NOT NULL,
    to_health character varying(10) NOT NULL,
    reason character varying(255) NOT NULL,
    snapshot_id bigint,
    triggered_by character varying(10) DEFAULT 'POLICY'::character varying NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_health_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_health_events_id_seq OWNED BY public.strategy_health_events.id;


--
-- Name: strategy_performance_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_performance_snapshots (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    version_no integer,
    source character varying(15) NOT NULL,
    domain character varying(10) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    period_from date,
    period_to date,
    as_of timestamp with time zone,
    total_trades integer DEFAULT 0 NOT NULL,
    winning_trades integer DEFAULT 0 NOT NULL,
    losing_trades integer DEFAULT 0 NOT NULL,
    win_rate_pct numeric(6,2) DEFAULT '0'::numeric NOT NULL,
    net_pnl numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    profit_factor numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    max_drawdown numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    legacy_health character varying(10),
    reliability_flags jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_performance_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_performance_snapshots_id_seq OWNED BY public.strategy_performance_snapshots.id;


--
-- Name: strategy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_rules (
    id bigint NOT NULL,
    strategy_version_id bigint NOT NULL,
    rule_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    required boolean DEFAULT true NOT NULL,
    weight integer DEFAULT 1 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    param_overrides jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_rules_id_seq OWNED BY public.strategy_rules.id;


--
-- Name: strategy_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_versions (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    version_no integer NOT NULL,
    schema_version integer DEFAULT 2 NOT NULL,
    definition jsonb NOT NULL,
    content_hash character varying(64) NOT NULL,
    change_note character varying(300),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_versions_id_seq OWNED BY public.strategy_versions.id;


--
-- Name: upstox_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upstox_configs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    api_key character varying(100) DEFAULT ''::character varying NOT NULL,
    api_secret_enc text DEFAULT ''::text NOT NULL,
    mobile character varying(15) DEFAULT ''::character varying NOT NULL,
    pin_enc text DEFAULT ''::text NOT NULL,
    totp_secret_enc text DEFAULT ''::text NOT NULL,
    access_token_enc text,
    redirect_uri character varying(300) DEFAULT ''::character varying NOT NULL,
    auto_auth_enabled boolean DEFAULT true NOT NULL,
    token_expires_at timestamp with time zone,
    auth_status character varying(20) DEFAULT 'NEVER'::character varying NOT NULL,
    last_auth_at timestamp with time zone,
    last_error character varying(500),
    upstox_user_id character varying(50),
    profile_name character varying(100),
    email character varying(150),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.upstox_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.upstox_configs_id_seq OWNED BY public.upstox_configs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: health_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_policies ALTER COLUMN id SET DEFAULT nextval('public.health_policies_id_seq'::regclass);


--
-- Name: import_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches ALTER COLUMN id SET DEFAULT nextval('public.import_batches_id_seq'::regclass);


--
-- Name: master_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_configs ALTER COLUMN id SET DEFAULT nextval('public.master_configs_id_seq'::regclass);


--
-- Name: master_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_conversations ALTER COLUMN id SET DEFAULT nextval('public.master_conversations_id_seq'::regclass);


--
-- Name: master_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_messages ALTER COLUMN id SET DEFAULT nextval('public.master_messages_id_seq'::regclass);


--
-- Name: master_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_preferences ALTER COLUMN id SET DEFAULT nextval('public.master_preferences_id_seq'::regclass);


--
-- Name: master_proposals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_proposals ALTER COLUMN id SET DEFAULT nextval('public.master_proposals_id_seq'::regclass);


--
-- Name: master_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_runs ALTER COLUMN id SET DEFAULT nextval('public.master_runs_id_seq'::regclass);


--
-- Name: master_tool_calls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_calls ALTER COLUMN id SET DEFAULT nextval('public.master_tool_calls_id_seq'::regclass);


--
-- Name: master_tool_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_policies ALTER COLUMN id SET DEFAULT nextval('public.master_tool_policies_id_seq'::regclass);


--
-- Name: master_tool_servers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_servers ALTER COLUMN id SET DEFAULT nextval('public.master_tool_servers_id_seq'::regclass);


--
-- Name: registry_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registry_items ALTER COLUMN id SET DEFAULT nextval('public.registry_items_id_seq'::regclass);


--
-- Name: research_candidates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_candidates ALTER COLUMN id SET DEFAULT nextval('public.research_candidates_id_seq'::regclass);


--
-- Name: research_chunks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_chunks ALTER COLUMN id SET DEFAULT nextval('public.research_chunks_id_seq'::regclass);


--
-- Name: research_claims id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_claims ALTER COLUMN id SET DEFAULT nextval('public.research_claims_id_seq'::regclass);


--
-- Name: research_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_config ALTER COLUMN id SET DEFAULT nextval('public.research_config_id_seq'::regclass);


--
-- Name: research_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_documents ALTER COLUMN id SET DEFAULT nextval('public.research_documents_id_seq'::regclass);


--
-- Name: research_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_queries ALTER COLUMN id SET DEFAULT nextval('public.research_queries_id_seq'::regclass);


--
-- Name: research_risk_terms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_risk_terms ALTER COLUMN id SET DEFAULT nextval('public.research_risk_terms_id_seq'::regclass);


--
-- Name: research_run_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_documents ALTER COLUMN id SET DEFAULT nextval('public.research_run_documents_id_seq'::regclass);


--
-- Name: research_run_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_events ALTER COLUMN id SET DEFAULT nextval('public.research_run_events_id_seq'::regclass);


--
-- Name: research_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_runs ALTER COLUMN id SET DEFAULT nextval('public.research_runs_id_seq'::regclass);


--
-- Name: research_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_sources ALTER COLUMN id SET DEFAULT nextval('public.research_sources_id_seq'::regclass);


--
-- Name: research_underlyings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_underlyings ALTER COLUMN id SET DEFAULT nextval('public.research_underlyings_id_seq'::regclass);


--
-- Name: rule_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions ALTER COLUMN id SET DEFAULT nextval('public.rule_versions_id_seq'::regclass);


--
-- Name: rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules ALTER COLUMN id SET DEFAULT nextval('public.rules_id_seq'::regclass);


--
-- Name: strategies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies ALTER COLUMN id SET DEFAULT nextval('public.strategies_id_seq'::regclass);


--
-- Name: strategy_health_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events ALTER COLUMN id SET DEFAULT nextval('public.strategy_health_events_id_seq'::regclass);


--
-- Name: strategy_performance_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots ALTER COLUMN id SET DEFAULT nextval('public.strategy_performance_snapshots_id_seq'::regclass);


--
-- Name: strategy_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules ALTER COLUMN id SET DEFAULT nextval('public.strategy_rules_id_seq'::regclass);


--
-- Name: strategy_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions ALTER COLUMN id SET DEFAULT nextval('public.strategy_versions_id_seq'::regclass);


--
-- Name: upstox_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs ALTER COLUMN id SET DEFAULT nextval('public.upstox_configs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0004_create_research_tables
\.


--
-- Data for Name: health_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_policies (id, code, name, scope, params, enabled, status, created_at) FROM stdin;
1	DEFAULT	Default Health Policy	"ALL"	{"window": 30, "minTrades": 30, "suspendIfDrawdownAbove": 50000, "degradeIfProfitFactorBelow": 1.0, "suspendIfProfitFactorBelow": 0.8, "suspendAfterConsecutiveLosses": 5}	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, file_name, source_format, mode, dry_run, total_items, created_count, updated_count, skipped_count, failed_count, errors, warnings, status, created_at) FROM stdin;
\.


--
-- Data for Name: master_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_configs (id, config_key, config_value, status, created_at) FROM stdin;
\.


--
-- Data for Name: master_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_conversations (id, title, summary, last_message_at, message_count, created_by_user_id, archived, status, created_at) FROM stdin;
12	Qwen Trading Session	\N	2026-10-22 07:44:00.815031+00	1	\N	f	0	2026-10-22 07:41:37.477432+00
13	hellop	\N	2026-10-22 08:06:53.705489+00	2	\N	f	0	2026-10-22 08:06:34.503038+00
53	Buy Nifty ATM Call when close > VWAP and RSI > 60	\N	2026-10-22 09:21:24.808449+00	2	\N	f	0	2026-10-22 09:19:28.349748+00
52	What strategies are registered?	\N	2026-10-22 09:18:51.652148+00	2	\N	f	0	2026-10-22 09:18:26.350022+00
51	What strategies are registered?	\N	2026-10-22 09:16:05.55053+00	1	\N	f	0	2026-10-22 09:16:02.32063+00
50	Strategy Query Test	\N	2026-10-22 09:09:20.484808+00	2	\N	f	0	2026-10-22 09:07:35.319081+00
49	What strategies are registered?	\N	2026-10-22 08:56:20.030028+00	1	\N	f	0	2026-10-22 08:56:18.080804+00
47	Greeting Test	\N	2026-10-22 08:48:35.435815+00	2	\N	f	0	2026-10-22 08:47:22.445054+00
48	What strategies are registered?	\N	2026-10-22 08:47:59.984391+00	2	\N	f	0	2026-10-22 08:47:28.896343+00
46	Chat Testing	\N	2026-10-22 08:33:19.830142+00	0	\N	f	0	2026-10-22 08:33:19.857176+00
\.


--
-- Data for Name: master_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_messages (id, conversation_id, seq, role, content, blocks, run_id, redacted, model, tokens_in, tokens_out, latency_ms, status, created_at) FROM stdin;
1	12	1	USER	Hello, what trading strategies do you know?	\N	1	f	\N	\N	\N	\N	1	2026-10-22 07:44:00.770601+00
2	12	2	ASSISTANT	Could not find strategy `nifty_option_pulse_buying_v1`.	null	1	f	\N	\N	\N	\N	1	2026-10-22 07:44:00.824471+00
3	13	1	USER	hai	\N	2	f	\N	\N	\N	\N	1	2026-10-22 08:06:37.435978+00
4	13	2	ASSISTANT	I could not clearly understand what you would like to do. You can describe a strategy to add, ask about an existing strategy, or define a risk guardrail rule.	null	2	f	\N	\N	\N	\N	1	2026-10-22 08:06:37.462788+00
5	13	3	USER	hellop	\N	3	f	\N	\N	\N	\N	1	2026-10-22 08:06:53.679506+00
6	13	4	ASSISTANT	I could not clearly understand what you would like to do. You can describe a strategy to add, ask about an existing strategy, or define a risk guardrail rule.	null	3	f	\N	\N	\N	\N	1	2026-10-22 08:06:53.713304+00
36	48	1	USER	What strategies are registered?	\N	35	f	\N	\N	\N	\N	1	2026-10-22 08:47:30.599517+00
37	47	1	USER	hai	\N	36	f	\N	\N	\N	\N	1	2026-10-22 08:47:40.90832+00
38	47	2	ASSISTANT	Hello! I'm AI Master, your expert trading assistant and algorithmic copilot for Auto-Trader. How can I assist you today? Whether you're exploring strategies like **VWAP Reclaim**, **EMA Pullback**, or **Supertrend with ADX**, or want to discuss risk management, market analysis, or custom strategy ideas—feel free to share! 😊	null	36	f	\N	\N	\N	\N	1	2026-10-22 08:47:40.926426+00
39	48	2	ASSISTANT	No strategies found matching your search query. You can ask me to create one for you!	null	35	f	\N	\N	\N	\N	1	2026-10-22 08:47:30.631127+00
40	48	3	USER	Set max daily portfolio loss to 2%	\N	37	f	\N	\N	\N	\N	1	2026-10-22 08:47:59.964649+00
41	47	3	USER	what is RSI?	\N	38	f	\N	\N	\N	\N	1	2026-10-22 08:48:35.415672+00
42	47	4	ASSISTANT	**RSI (Relative Strength Index)** is a momentum oscillator that measures the speed and change of price movements. Developed by **Welles Wilder**, it ranges from **0 to 100** and helps identify **overbought** (above 70) or **oversold** (below 30) conditions. Here’s how it works:\n\n### Key Concepts:\n1. **Overbought/Oversold Levels**:  \n   - **>70**: Potential reversal (sell signal).  \n   - **<30**: Potential reversal (buy signal).  \n   - *Note*: These levels are not absolute and can vary in trending markets.\n\n2. **Divergence**:  \n   - **Bullish Divergence**: Price makes lower lows, but RSI makes higher lows → potential reversal.  \n   - **Bearish Divergence**: Price makes higher highs, but RSI makes lower highs → potential reversal.\n\n3. **Trend Confirmation**:  \n   - In **bullish trends**, RSI stays above 50.  \n   - In **bearish trends**, RSI stays below 50.  \n\n### Use in Strategies:  \n- **VWAP Reclaim**: RSI can confirm overbought/oversold conditions during VWAP breakouts.  \n- **EMA Pullback**: RSI may signal oversold levels during pullbacks, hinting at trend resumption.  \n\n### Limitations:  \n- **False Signals**: RSI can generate false reversals in volatile or trending markets.  \n- **Lagging Indicator**: It reacts to price changes, not predicting them.  \n\nWould you like examples of how RSI is used in specific strategies or markets? 😊	null	38	f	\N	\N	\N	\N	1	2026-10-22 08:48:35.44081+00
43	49	1	USER	What strategies are registered?	\N	39	f	\N	\N	\N	\N	1	2026-10-22 08:56:20.013698+00
44	49	2	ASSISTANT	No strategies found matching your search query. You can ask me to create one for you!	null	39	f	\N	\N	\N	\N	1	2026-10-22 08:56:20.035874+00
45	50	1	USER	What strategies are registered?	\N	40	f	\N	\N	\N	\N	1	2026-10-22 09:08:10.479544+00
46	50	2	ASSISTANT	### Registered Strategies (10 of 33 shown)\n\n- **15-Minute Opening Range Breakout** (`ORB_15M`) — SINGLE_LONG | `ACTIVE`\n- **Previous Day High / Low Breakout** (`PDH_PDL_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **VWAP Reclaim & Continuation** (`VWAP_RECLAIM`) — SINGLE_LONG | `ACTIVE`\n- **9/21 EMA Trend Pullback** (`EMA_PULLBACK`) — SINGLE_LONG | `ACTIVE`\n- **Supertrend with ADX Confirmation** (`SUPERTREND_ADX`) — SINGLE_LONG | `ACTIVE`\n- **Bollinger Band Squeeze Breakout** (`BB_SQUEEZE`) — SINGLE_LONG | `ACTIVE`\n- **Inside Bar Momentum Breakout** (`INSIDE_BAR_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **Central Pivot Range (CPR) Trend Reversal** (`CPR_NARROW`) — SINGLE_LONG | `ACTIVE`\n- **RSI Oversold Level Reversal** (`RSI_LEVEL_REVERSAL`) — SINGLE_LONG | `ACTIVE`\n- **Open Interest Wall Support Bounce** (`OI_WALL_BOUNCE`) — SINGLE_LONG | `ACTIVE`\n\n💡 *Ask me to explain any strategy (e.g. `explain VWAP_RECLAIM`) or describe a new setup to create one!*	null	40	f	\N	\N	\N	\N	1	2026-10-22 09:08:10.504183+00
47	50	3	USER	Set max daily portfolio loss to 2%	\N	41	f	\N	\N	\N	\N	1	2026-10-22 09:09:20.475356+00
48	50	4	ASSISTANT	I have prepared a proposal (**Proposal #1**) for your review.\n\nPlease verify the back-translation and risk structure below before confirming.	[{"type": "PROPOSAL_REF", "proposalId": 1}]	41	f	\N	\N	\N	\N	1	2026-10-22 09:09:20.490784+00
49	51	1	USER	What strategies are registered?	\N	42	f	\N	\N	\N	\N	1	2026-10-22 09:16:05.521262+00
50	51	2	ASSISTANT	### Registered Strategies (10 of 33 shown)\n\n- **15-Minute Opening Range Breakout** (`ORB_15M`) — SINGLE_LONG | `ACTIVE`\n- **Previous Day High / Low Breakout** (`PDH_PDL_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **VWAP Reclaim & Continuation** (`VWAP_RECLAIM`) — SINGLE_LONG | `ACTIVE`\n- **9/21 EMA Trend Pullback** (`EMA_PULLBACK`) — SINGLE_LONG | `ACTIVE`\n- **Supertrend with ADX Confirmation** (`SUPERTREND_ADX`) — SINGLE_LONG | `ACTIVE`\n- **Bollinger Band Squeeze Breakout** (`BB_SQUEEZE`) — SINGLE_LONG | `ACTIVE`\n- **Inside Bar Momentum Breakout** (`INSIDE_BAR_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **Central Pivot Range (CPR) Trend Reversal** (`CPR_NARROW`) — SINGLE_LONG | `ACTIVE`\n- **RSI Oversold Level Reversal** (`RSI_LEVEL_REVERSAL`) — SINGLE_LONG | `ACTIVE`\n- **Open Interest Wall Support Bounce** (`OI_WALL_BOUNCE`) — SINGLE_LONG | `ACTIVE`\n\n💡 *Ask me to explain any strategy (e.g. `explain VWAP_RECLAIM`) or describe a new setup to create one!*	null	42	f	\N	\N	\N	\N	1	2026-10-22 09:16:05.55514+00
51	52	1	USER	What strategies are registered?	\N	43	f	\N	\N	\N	\N	1	2026-10-22 09:18:34.607043+00
52	52	2	ASSISTANT	### Registered Strategies (10 of 33 shown)\n\n- **15-Minute Opening Range Breakout** (`ORB_15M`) — SINGLE_LONG | `ACTIVE`\n- **Previous Day High / Low Breakout** (`PDH_PDL_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **VWAP Reclaim & Continuation** (`VWAP_RECLAIM`) — SINGLE_LONG | `ACTIVE`\n- **9/21 EMA Trend Pullback** (`EMA_PULLBACK`) — SINGLE_LONG | `ACTIVE`\n- **Supertrend with ADX Confirmation** (`SUPERTREND_ADX`) — SINGLE_LONG | `ACTIVE`\n- **Bollinger Band Squeeze Breakout** (`BB_SQUEEZE`) — SINGLE_LONG | `ACTIVE`\n- **Inside Bar Momentum Breakout** (`INSIDE_BAR_BREAK`) — SINGLE_LONG | `ACTIVE`\n- **Central Pivot Range (CPR) Trend Reversal** (`CPR_NARROW`) — SINGLE_LONG | `ACTIVE`\n- **RSI Oversold Level Reversal** (`RSI_LEVEL_REVERSAL`) — SINGLE_LONG | `ACTIVE`\n- **Open Interest Wall Support Bounce** (`OI_WALL_BOUNCE`) — SINGLE_LONG | `ACTIVE`\n\n💡 *Ask me to explain any strategy (e.g. `explain VWAP_RECLAIM`) or describe a new setup to create one!*	null	43	f	\N	\N	\N	\N	1	2026-10-22 09:18:34.624032+00
53	52	3	USER	Set max daily portfolio loss to 2%	\N	44	f	\N	\N	\N	\N	1	2026-10-22 09:18:51.639275+00
57	53	3	USER	what nis best rule in our system	\N	46	f	\N	\N	\N	\N	1	2026-10-22 09:21:24.72274+00
54	52	4	ASSISTANT	I have prepared a proposal (**Proposal #2**) for your review.\n\nPlease verify the back-translation and risk structure below before confirming.	[{"type": "PROPOSAL_REF", "proposalId": 2}]	44	f	\N	\N	\N	\N	1	2026-10-22 09:18:51.655925+00
56	53	2	ASSISTANT	To build an accurate definition, I need clarification on a few details:	[{"type": "QUESTION", "questions": [{"id": "indicator_vwap", "text": "Indicator 'VWAP' is not found in the technical indicator registry. How should we measure it?", "options": ["Use RSI(14)", "Use VWAP", "Use EMA(20)", "Drop this condition"], "recommended": "Use RSI(14)"}, {"id": "indicator_rsi", "text": "Indicator 'RSI' is not found in the technical indicator registry. How should we measure it?", "options": ["Use RSI(14)", "Use VWAP", "Use EMA(20)", "Drop this condition"], "recommended": "Use RSI(14)"}, {"id": "exit_stop", "text": "This strategy does not specify an exit condition or stop loss. How should risk be managed?", "options": ["Stop loss at 25% of entry premium and exit at 15:10:00", "Stop loss at 20 points and target at 40 points", "Exit on opposite signal or 15:15:00 market close"], "recommended": "Stop loss at 25% of entry premium and exit at 15:10:00"}]}]	45	f	\N	\N	\N	\N	1	2026-10-22 09:19:41.611958+00
58	53	4	ASSISTANT	The best rule in our system depends on your trading goals and risk tolerance. Here’s a breakdown of our core strategies and their strengths:  \n\n1. **VWAP Reclaim & Continuation (VWAP_RECLAIM)**  \n   - **Best For**: Trend continuation after a VWAP break.  \n   - **Why**: VWAP acts as a dynamic support/resistance level, and the strategy captures momentum during price reclaiming.  \n\n2. **Supertrend with ADX Confirmation (SUPERTREND_ADX)**  \n   - **Best For**: Trend-following with trend strength validation.  \n   - **Why**: ADX confirms trend validity, reducing false signals from the Supertrend.  \n\n3. **9/21 EMA Trend Pullback (EMA_PULLBACK)**  \n   - **Best For**: High-probability pullbacks in strong trends.  \n   - **Why**: Combines EMA crossovers with pullback entry rules for precise timing.  \n\n### Your Idea: **Nifty ATM Call on Close > VWAP + RSI > 60**  \n- **Alignment**: Your condition (VWAP + RSI) partially overlaps with **VWAP_RECLAIM** (VWAP focus) but lacks the RSI component.  \n- **Recommendation**:  \n  - **Existing Strategy**: Use **VWAP_RECLAIM** as a base and add RSI > 60 as a filter for overbought momentum.  \n  - **Custom Strategy**: If you prefer, we can build a hybrid rule combining VWAP, RSI, and ATM options logic.  \n\nWould you like to refine this idea further or explore a custom strategy?	null	46	f	\N	\N	\N	\N	1	2026-10-22 09:21:24.841319+00
55	53	1	USER	Buy Nifty ATM Call when close > VWAP and RSI > 60	\N	45	f	\N	\N	\N	\N	1	2026-10-22 09:19:41.560634+00
\.


--
-- Data for Name: master_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_preferences (id, key, value, source_message_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: master_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_proposals (id, conversation_id, message_id, kind, target_type, target_code, user_text, back_translation, payload, diff, complications, assumptions, structure_analysis, validation, content_hash, proposal_status, expires_at, confirmed_at, confirm_mode, result_refs, failure_reason, status, created_at) FROM stdin;
1	50	\N	NEW_RULE	\N	max_daily_loss_2pct	Set max daily portfolio loss to 2%	Halts all trading execution and closes active positions if total daily portfolio loss exceeds 2.0%.	{"code": "max_daily_loss_2pct", "kind": "GUARDRAIL", "name": "Max Daily Portfolio Loss (2.0%)", "action": "HALT_TRADING", "priority": "CRITICAL", "parameters": {"scope": "PORTFOLIO", "resetAt": "SESSION_OPEN", "maxLossPct": 2.0}, "conditionText": "Total portfolio unrealized + realized daily loss exceeds 2.0% of account capital"}	\N	[]	[]	{}	{"valid": true, "issues": []}	5f53ed5b9db29ef7aa77d22ee575f82b0d00827a0bda9765a3a7799cc537b39e	PENDING	2026-10-22 11:09:31.357615+00	\N	\N	\N	\N	1	2026-10-22 09:09:20.490784+00
2	52	\N	NEW_RULE	\N	max_daily_loss_2pct	Set max daily portfolio loss to 2%	Halts all trading execution and closes active positions if total daily portfolio loss exceeds 2.0%.	{"code": "max_daily_loss_2pct", "kind": "GUARDRAIL", "name": "Max Daily Portfolio Loss (2.0%)", "action": "HALT_TRADING", "priority": "CRITICAL", "parameters": {"scope": "PORTFOLIO", "resetAt": "SESSION_OPEN", "maxLossPct": 2.0}, "conditionText": "Total portfolio unrealized + realized daily loss exceeds 2.0% of account capital"}	\N	[]	[]	{}	{"valid": true, "issues": []}	5f53ed5b9db29ef7aa77d22ee575f82b0d00827a0bda9765a3a7799cc537b39e	PENDING	2026-10-22 11:19:03.319909+00	\N	\N	\N	\N	1	2026-10-22 09:18:51.655925+00
\.


--
-- Data for Name: master_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_runs (id, conversation_id, user_message_id, state, intent, thread_id, iterations, tool_call_count, clarification_round, started_at, finished_at, error, status, created_at) FROM stdin;
1	12	1	COMPLETED	EXPLAIN	conv-12	0	0	0	2026-10-22 07:44:00.806794+00	2026-10-22 07:44:23.910999+00	\N	1	2026-10-22 07:44:00.770601+00
2	13	3	COMPLETED	UNCLEAR	conv-13	0	0	0	2026-10-22 08:06:37.451706+00	2026-10-22 08:06:53.352444+00	\N	1	2026-10-22 08:06:37.435978+00
3	13	5	COMPLETED	UNCLEAR	conv-13	0	0	0	2026-10-22 08:06:53.699377+00	2026-10-22 08:07:21.964272+00	\N	1	2026-10-22 08:06:53.679506+00
36	47	37	COMPLETED	CHAT	conv-47	0	0	0	2026-10-22 08:47:40.917853+00	2026-10-22 08:47:56.582066+00	\N	1	2026-10-22 08:47:40.90832+00
35	48	36	COMPLETED	FIND	conv-48	0	0	0	2026-10-22 08:47:30.620699+00	2026-10-22 08:47:59.446856+00	\N	1	2026-10-22 08:47:30.599517+00
37	48	40	FAILED	\N	conv-48	0	0	0	2026-10-22 08:47:59.978317+00	2026-10-22 08:48:23.187922+00	Expecting value: line 1 column 1 (char 0)	1	2026-10-22 08:47:59.964649+00
38	47	41	COMPLETED	CHAT	conv-47	0	0	0	2026-10-22 08:48:35.430408+00	2026-10-22 08:49:33.317289+00	\N	1	2026-10-22 08:48:35.415672+00
39	49	43	COMPLETED	FIND	conv-49	0	0	0	2026-10-22 08:56:20.026492+00	2026-10-22 08:56:37.996599+00	\N	1	2026-10-22 08:56:20.013698+00
40	50	45	COMPLETED	FIND	conv-50	0	0	0	2026-10-22 09:08:10.493293+00	2026-10-22 09:08:10.53457+00	\N	1	2026-10-22 09:08:10.479544+00
41	50	47	COMPLETED	ADD_RULE	conv-50	0	0	0	2026-10-22 09:09:20.482824+00	2026-10-22 09:09:31.372704+00	\N	1	2026-10-22 09:09:20.475356+00
42	51	49	COMPLETED	FIND	conv-51	0	0	0	2026-10-22 09:16:05.544978+00	2026-10-22 09:16:05.575743+00	\N	1	2026-10-22 09:16:05.521262+00
43	52	51	COMPLETED	FIND	conv-52	0	0	0	2026-10-22 09:18:34.616101+00	2026-10-22 09:18:34.66043+00	\N	1	2026-10-22 09:18:34.607043+00
44	52	53	COMPLETED	ADD_RULE	conv-52	0	0	0	2026-10-22 09:18:51.647886+00	2026-10-22 09:19:03.335203+00	\N	1	2026-10-22 09:18:51.639275+00
45	53	55	WAITING_USER	ADD_STRATEGY	conv-53	0	0	1	2026-10-22 09:19:41.586646+00	2026-10-22 09:20:43.013687+00	\N	1	2026-10-22 09:19:41.560634+00
46	53	57	COMPLETED	CHAT	conv-53	0	0	0	2026-10-22 09:21:24.792304+00	2026-10-22 09:22:52.191431+00	\N	1	2026-10-22 09:21:24.72274+00
\.


--
-- Data for Name: master_tool_calls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_tool_calls (id, run_id, server_name, tool_name, tier, arguments, result_summary, call_status, duration_ms, status, created_at) FROM stdin;
1	1	strategy-rules	get_strategy_history	READ	{"code": "nifty_option_pulse_buying_v1"}	{"error": "'StrategyRepository' object has no attribute 'search_versions'"}	ERROR	146	1	2026-10-22 07:44:00.824471+00
2	36	strategy-rules	search_strategies	READ	{"limit": 5}	{"strategies": "List of 5 items", "totalItems": "33"}	OK	47	1	2026-10-22 08:47:40.926426+00
3	35	strategy-rules	search_strategies	READ	{"query": "What strategies are registered?"}	{"error": "name 'String' is not defined"}	ERROR	31	1	2026-10-22 08:47:30.631127+00
4	38	strategy-rules	search_strategies	READ	{"limit": 5}	{"strategies": "List of 5 items", "totalItems": "33"}	OK	38	1	2026-10-22 08:48:35.44081+00
5	39	strategy-rules	search_strategies	READ	{"query": "What strategies are registered?"}	{"error": "name 'String' is not defined"}	ERROR	36	1	2026-10-22 08:56:20.035874+00
6	40	strategy-rules	search_strategies	READ	{"limit": 20, "query": null}	{"strategies": "List of 20 items", "totalItems": "33"}	OK	20	1	2026-10-22 09:08:10.504183+00
7	42	strategy-rules	search_strategies	READ	{"limit": 20, "query": null}	{"strategies": "List of 20 items", "totalItems": "33"}	OK	13	1	2026-10-22 09:16:05.55514+00
8	43	strategy-rules	search_strategies	READ	{"limit": 20, "query": null}	{"strategies": "List of 20 items", "totalItems": "33"}	OK	19	1	2026-10-22 09:18:34.624032+00
9	45	strategy-rules	list_registry	READ	{"query": "VWAP", "registryType": "INDICATOR"}	{"error": "'RegistryItem' object has no attribute 'type'"}	ERROR	48	1	2026-10-22 09:19:41.611958+00
10	45	strategy-rules	list_registry	READ	{"query": "RSI", "registryType": "INDICATOR"}	{"error": "'RegistryItem' object has no attribute 'type'"}	ERROR	2	1	2026-10-22 09:19:41.611958+00
11	46	strategy-rules	search_strategies	READ	{"limit": 5}	{"strategies": "List of 5 items", "totalItems": "33"}	OK	268	1	2026-10-22 09:21:24.841319+00
\.


--
-- Data for Name: master_tool_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_tool_policies (id, server_name, tool_name, tier, enabled, auto_approve, status, created_at) FROM stdin;
1	strategy-rules	list_registry	READ	t	t	1	2026-10-22 07:44:00.770601+00
2	strategy-rules	get_registry_item	READ	t	t	1	2026-10-22 07:44:00.770601+00
3	strategy-rules	search_strategies	READ	t	t	1	2026-10-22 07:44:00.770601+00
4	strategy-rules	get_strategy	READ	t	t	1	2026-10-22 07:44:00.770601+00
5	strategy-rules	get_strategy_history	READ	t	t	1	2026-10-22 07:44:00.770601+00
6	strategy-rules	search_rules	READ	t	t	1	2026-10-22 07:44:00.770601+00
7	strategy-rules	get_rule	READ	t	t	1	2026-10-22 07:44:00.770601+00
8	strategy-rules	validate_definition	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
9	strategy-rules	analyze_structure	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
10	strategy-rules	find_similar	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
11	strategy-rules	analyze_conflicts	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
12	strategy-rules	evaluate_definition	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
13	strategy-rules	explain_definition	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
14	strategy-rules	diff_definitions	ANALYZE	t	t	1	2026-10-22 07:44:00.770601+00
\.


--
-- Data for Name: master_tool_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_tool_servers (id, name, transport, url, auth_ref, tier_cap, enabled, last_seen_at, last_error, tool_count, status, created_at) FROM stdin;
1	strategy-rules	HTTP	/mcp/strategy	STRATEGY_MCP_TOKEN	ANALYZE	t	\N	\N	14	1	2026-10-22 07:44:00.770601+00
2	research	HTTP	http://localhost:8000/mcp/research	MCP_RESEARCH_TOKEN	OPERATE	t	\N	\N	10	1	2026-10-22 11:16:48.943092+00
\.


--
-- Data for Name: registry_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registry_items (id, registry_type, code, name, kind, version, schema, expression, handler_key, executable, requires, description, enabled, status, created_at) FROM stdin;
1	OPERATOR	IS_ABOVE	Is Above (>)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Above (>)	t	1	2026-10-20 06:44:12.072716+00
2	OPERATOR	IS_ABOVE_OR_EQUAL	Is Above or Equal (>=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Above or Equal (>=)	t	1	2026-10-20 06:44:12.072716+00
3	OPERATOR	IS_BELOW	Is Below (<)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Below (<)	t	1	2026-10-20 06:44:12.072716+00
4	OPERATOR	IS_BELOW_OR_EQUAL	Is Below or Equal (<=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Below or Equal (<=)	t	1	2026-10-20 06:44:12.072716+00
5	OPERATOR	EQUALS	Equals (==)	BUILT_IN	1	null	\N	operator_handler	t	\N	Equals (==)	t	1	2026-10-20 06:44:12.072716+00
6	OPERATOR	NOT_EQUALS	Not Equals (!=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Not Equals (!=)	t	1	2026-10-20 06:44:12.072716+00
7	OPERATOR	BETWEEN	Between	BUILT_IN	1	null	\N	operator_handler	t	\N	Between	t	1	2026-10-20 06:44:12.072716+00
8	OPERATOR	IN	In List	BUILT_IN	1	null	\N	operator_handler	t	\N	In List	t	1	2026-10-20 06:44:12.072716+00
9	OPERATOR	NOT_IN	Not In List	BUILT_IN	1	null	\N	operator_handler	t	\N	Not In List	t	1	2026-10-20 06:44:12.072716+00
10	OPERATOR	CROSSES_ABOVE	Crosses Above	BUILT_IN	1	null	\N	operator_handler	t	\N	Crosses Above	t	1	2026-10-20 06:44:12.072716+00
11	OPERATOR	CROSSES_BELOW	Crosses Below	BUILT_IN	1	null	\N	operator_handler	t	\N	Crosses Below	t	1	2026-10-20 06:44:12.072716+00
12	OPERAND_SOURCE	PRICE	Bar Price (OHLCV)	BUILT_IN	1	null	\N	price_handler	t	\N	Bar Price (OHLCV)	t	1	2026-10-20 06:44:12.072716+00
13	OPERAND_SOURCE	DAY	Daily Level (PDH/PDL)	BUILT_IN	1	null	\N	day_handler	t	\N	Daily Level (PDH/PDL)	t	1	2026-10-20 06:44:12.072716+00
14	OPERAND_SOURCE	INDICATOR	Technical Indicator	BUILT_IN	1	null	\N	indicator_handler	t	\N	Technical Indicator	t	1	2026-10-20 06:44:12.072716+00
15	OPERAND_SOURCE	TIME	Time of Day	BUILT_IN	1	null	\N	time_handler	t	\N	Time of Day	t	1	2026-10-20 06:44:12.072716+00
16	OPERAND_SOURCE	CONTEXT	Market Context	BUILT_IN	1	null	\N	context_handler	t	\N	Market Context	t	1	2026-10-20 06:44:12.072716+00
17	OPERAND_SOURCE	POSITION	Live Position State	BUILT_IN	1	null	\N	position_handler	t	\N	Live Position State	t	1	2026-10-20 06:44:12.072716+00
18	OPERAND_SOURCE	TRADE_PLAN	Trade Plan / Cost	BUILT_IN	1	null	\N	plan_handler	t	\N	Trade Plan / Cost	t	1	2026-10-20 06:44:12.072716+00
19	OPERAND_SOURCE	CONSTANT	Literal Constant	BUILT_IN	1	null	\N	const_handler	t	\N	Literal Constant	t	1	2026-10-20 06:44:12.072716+00
20	OPERAND_SOURCE	PARAM	Strategy Parameter	BUILT_IN	1	null	\N	param_handler	t	\N	Strategy Parameter	t	1	2026-10-20 06:44:12.072716+00
21	STRIKE_SELECTOR	ATM_OFFSET	ATM Strike Offset	BUILT_IN	1	null	\N	strike_atm	t	\N	ATM Strike Offset	t	1	2026-10-20 06:44:12.072716+00
22	STRIKE_SELECTOR	DELTA	Nearest Delta	BUILT_IN	1	null	\N	strike_delta	t	\N	Nearest Delta	t	1	2026-10-20 06:44:12.072716+00
23	STRIKE_SELECTOR	PREMIUM	Nearest Premium	BUILT_IN	1	null	\N	strike_premium	t	\N	Nearest Premium	t	1	2026-10-20 06:44:12.072716+00
24	STOP_TYPE	PERCENT	Percentage Stop	BUILT_IN	1	null	\N	stop_pct	t	\N	Percentage Stop	t	1	2026-10-20 06:44:12.072716+00
25	STOP_TYPE	AMOUNT	Total INR Amount	BUILT_IN	1	null	\N	stop_amt	t	\N	Total INR Amount	t	1	2026-10-20 06:44:12.072716+00
26	STOP_TYPE	POINTS	Absolute Index Points	BUILT_IN	1	null	\N	stop_pts	t	\N	Absolute Index Points	t	1	2026-10-20 06:44:12.072716+00
27	TARGET_TYPE	PERCENT	Percentage Target	BUILT_IN	1	null	\N	target_pct	t	\N	Percentage Target	t	1	2026-10-20 06:44:12.072716+00
28	TARGET_TYPE	AMOUNT	Total INR Target	BUILT_IN	1	null	\N	target_amt	t	\N	Total INR Target	t	1	2026-10-20 06:44:12.072716+00
29	TARGET_TYPE	POINTS	Absolute Index Target	BUILT_IN	1	null	\N	target_pts	t	\N	Absolute Index Target	t	1	2026-10-20 06:44:12.072716+00
30	TRAIL_TYPE	LINEAR	Linear Trailing Stop	BUILT_IN	1	null	\N	trail_linear	t	\N	Linear Trailing Stop	t	1	2026-10-20 06:44:12.072716+00
31	EXPIRY_CYCLE	WEEKLY	Weekly Expiry	BUILT_IN	1	null	\N	expiry_weekly	t	\N	Weekly Expiry	t	1	2026-10-20 06:44:12.072716+00
32	EXPIRY_CYCLE	MONTHLY	Monthly Expiry	BUILT_IN	1	null	\N	expiry_monthly	t	\N	Monthly Expiry	t	1	2026-10-20 06:44:12.072716+00
33	LEG_ACTION	OPEN_LEG	Open Leg	BUILT_IN	1	null	\N	action_open	t	\N	Open Leg	t	1	2026-10-20 06:44:12.072716+00
34	LEG_ACTION	CLOSE_LEG	Close Leg	BUILT_IN	1	null	\N	action_close	t	\N	Close Leg	t	1	2026-10-20 06:44:12.072716+00
35	STRUCTURE	SINGLE_LONG	Single Leg Long Option	BUILT_IN	1	null	\N	struct_long	t	\N	Single Leg Long Option	t	1	2026-10-20 06:44:12.072716+00
36	STRUCTURE	BULL_PUT_SPREAD	Bull Put Credit Spread	BUILT_IN	1	null	\N	struct_spread	t	\N	Bull Put Credit Spread	t	1	2026-10-20 06:44:12.072716+00
37	STRUCTURE	BEAR_CALL_SPREAD	Bear Call Credit Spread	BUILT_IN	1	null	\N	struct_spread	t	\N	Bear Call Credit Spread	t	1	2026-10-20 06:44:12.072716+00
38	STRUCTURE	IRON_CONDOR	Iron Condor	BUILT_IN	1	null	\N	struct_condor	t	\N	Iron Condor	t	1	2026-10-20 06:44:12.072716+00
39	STRUCTURE	SHORT_STRANGLE	Short Strangle	BUILT_IN	1	null	\N	struct_strangle	t	\N	Short Strangle	t	1	2026-10-20 06:44:12.072716+00
40	STRUCTURE	CUSTOM_MULTI_LEG	Custom Multi-Leg Option	BUILT_IN	1	null	\N	struct_multi	t	\N	Custom Multi-Leg Option	t	1	2026-10-20 06:44:12.072716+00
41	STRUCTURE	MIXED	Mixed Strategy Structure	BUILT_IN	1	null	\N	struct_mixed	t	\N	Mixed Strategy Structure	t	1	2026-10-20 06:44:12.072716+00
42	EVALUATOR	ORB15	15-Minute Opening Range Breakout Evaluator	BUILT_IN	1	null	\N	\N	f	\N	15-Minute Opening Range Breakout Evaluator	t	1	2026-10-20 06:44:12.072716+00
43	EVALUATOR	EMA_PULLBACK	EMA Trend Pullback Evaluator	BUILT_IN	1	null	\N	\N	f	\N	EMA Trend Pullback Evaluator	t	1	2026-10-20 06:44:12.072716+00
44	INDICATOR	EMA	Exponential Moving Average	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 9}}}	\N	ind_ema	t	\N	Exponential Moving Average	t	1	2026-10-20 06:44:12.072716+00
45	INDICATOR	SMA	Simple Moving Average	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}}}	\N	ind_sma	t	\N	Simple Moving Average	t	1	2026-10-20 06:44:12.072716+00
46	INDICATOR	RSI	Relative Strength Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_rsi	t	\N	Relative Strength Index	t	1	2026-10-20 06:44:12.072716+00
47	INDICATOR	CCI	Commodity Channel Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}}}	\N	ind_cci	t	\N	Commodity Channel Index	t	1	2026-10-20 06:44:12.072716+00
48	INDICATOR	ADX	Average Directional Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_adx	t	\N	Average Directional Index	t	1	2026-10-20 06:44:12.072716+00
49	INDICATOR	ATR	Average True Range	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_atr	t	\N	Average True Range	t	1	2026-10-20 06:44:12.072716+00
50	INDICATOR	SUPERTREND	Supertrend	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 10}, "multiplier": {"type": "float", "default": 3.0}}}	\N	ind_supertrend	t	\N	Supertrend	t	1	2026-10-20 06:44:12.072716+00
51	INDICATOR	BBANDS	Bollinger Bands	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}, "stdDev": {"type": "float", "default": 2.0}}}	\N	ind_bbands	t	\N	Bollinger Bands	t	1	2026-10-20 06:44:12.072716+00
52	INDICATOR	VWAP	Volume Weighted Average Price	BUILT_IN	1	null	\N	ind_vwap	t	\N	Volume Weighted Average Price	t	1	2026-10-20 06:44:12.072716+00
53	INDICATOR	PIVOT_POINTS	Pivot Points (Standard / Camarilla)	BUILT_IN	1	{"params": {"variant": {"type": "str", "default": "STANDARD"}}}	\N	ind_pivots	t	\N	Pivot Points (Standard / Camarilla)	t	1	2026-10-20 06:44:12.072716+00
54	INDICATOR	MARKET_REGIME	Market Regime Classifier	BUILT_IN	1	null	\N	\N	f	\N	Market Regime Classifier	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: research_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_candidates (id, run_id, underlying_type, underlying_code, news_status, suggested, rank, direction, bearish_watch, score, score_label, positive_weight, negative_weight, negative_share, positive_claims, negative_claims, material_negatives, independent_sources, fresh_article_count, newest_article_at, oldest_article_at, flags, reasons, thesis, supporting_points, watch_items, citations, brief_embedding, status, created_at) FROM stdin;
1	6	INDEX	NIFTY	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
2	6	INDEX	BANKNIFTY	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
3	6	INDEX	FINNIFTY	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
4	6	INDEX	MIDCPNIFTY	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
5	6	INDEX	SENSEX	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
6	6	INDEX	BANKEX	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
7	6	COMMODITY	CRUDEOIL	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
8	6	COMMODITY	NATURALGAS	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
9	6	COMMODITY	GOLD	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
10	6	COMMODITY	SILVER	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
11	6	COMMODITY	COPPER	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
12	6	COMMODITY	ZINC	NO_COVERAGE	f	\N	\N	f	\N	\N	0.000	0.000	0.000	0	0	[]	0	0	\N	\N	["LOW_COVERAGE"]	["Insufficient coverage: 0 independent source(s) (minimum 3 required)"]	\N	[]	[]	[]	[0.25771388,0.9877758,-3.7823384,0.154674,0.18642245,0.8829998,-0.9379587,0.8102769,-0.055568784,-0.70222694,-0.21816517,0.15055248,1.0949423,0.532819,0.14107004,-0.63202995,0.09955356,-0.22743739,-0.069503255,0.7913798,-0.7246202,-1.450553,-0.33166775,-0.2205432,2.0953171,-0.30276507,0.47852618,-0.56160057,-0.65790933,-0.7117264,0.392096,-0.53838915,-0.6754551,-1.1405603,-0.85400677,-0.64668936,0.85351026,0.60561454,-1.6718154,0.45097587,-0.34019867,-0.26599357,-0.3251033,0.114296935,-0.06506734,0.65366685,1.6494585,2.0194874,1.2231903,-1.8228736,0.25563958,0.2913206,0.9515474,-0.06582818,1.1159188,-0.2766126,-1.8353554,-0.70452297,-0.34775224,0.15629037,1.3928113,0.34125793,-1.2637844,0.21209088,0.71096665,-0.85137564,-0.029882079,0.53924036,0.1334469,-0.76434195,0.21802816,-0.6191587,0.78507376,0.21783958,-0.24148746,-0.6090754,-1.0535983,0.16498452,-0.75013745,0.11180236,0.7204618,0.4804729,1.1989588,-0.34697184,1.0136166,0.27575272,0.5005041,-0.30293366,0.19446567,1.0646789,-0.08186568,1.2536141,0.9502648,-0.35500836,-0.29593042,-0.29939717,-0.76313245,0.68109196,0.21598724,-0.61172664,0.2662589,-0.4463286,-1.2360026,-1.2624261,0.56881374,0.8706884,0.81052697,0.64525473,-0.40638968,-0.34364957,-1.1190958,0.31104875,-0.3965681,-1.0986598,-0.98729455,-1.0819235,1.6489892,0.11075586,1.3916115,0.0440304,-0.8942287,-0.07299265,0.4944023,1.3489401,-0.94791305,-0.2448786,-1.7378069,0.63005686,-0.15273894,-1.485814,0.00998195,-0.36243102,-0.11240544,0.047160435,0.55344534,0.7759355,-1.1430972,-0.21156159,-0.6166396,1.3310529,0.47301793,0.46840557,0.2121285,-0.89534724,0.9528212,-0.41403157,1.1310054,-1.2068549,-0.96044934,0.6293111,0.53094447,0.22910185,0.053199727,-0.2241646,0.24269238,-0.59577143,0.86916435,-0.8406677,0.104347184,-0.73390144,0.920523,-0.04234862,-1.6791632,0.9998261,-0.03938861,-0.025076646,-0.38152498,1.2829524,0.25001717,0.77132064,-0.32930538,0.08190295,-0.5285011,-0.6304031,0.16481806,-0.009470452,0.7449189,-1.3998746,0.51043046,-0.2361841,0.5117674,-0.5727053,0.5658786,0.8744863,0.14299023,-0.38474828,0.6685224,-0.6775639,-0.2704868,-0.49865717,-0.56085515,0.60404855,0.6231381,-1.0014042,-0.94977933,0.5916365,1.189826,-0.17158993,1.3544186,-0.77297974,-0.59885806,-0.1277947,-0.32098758,0.94520026,-0.88689554,0.12386191,0.11472874,1.2904559,-0.23769532,-0.5517764,-0.05634426,-0.3245116,-0.74216676,0.1701202,0.89609766,-1.502904,0.17273167,-0.027805751,-0.92240596,0.12809221,-0.18301655,1.1543412,0.41804236,-0.9940671,0.5306506,0.17991441,-0.7471355,-0.61153173,0.33674276,0.45886186,0.16219825,-1.9592662,0.8801026,-0.2035132,-0.19396617,-0.02128989,0.3488365,0.70955306,0.115610495,0.43370658,-0.17090966,0.4930814,-0.22707845,0.2691846,-0.10786191,-0.2813506,-0.16537666,-1.0197899,-0.36368883,1.3220606,-0.67172766,0.7209303,0.74134517,0.6391697,0.10449448,-0.3763166,0.44503355,-0.41373983,-0.806088,0.020570034,0.68625045,-0.92903274,2.1167517,-1.0632375,-1.1977907,0.22158715,-0.32327032,-0.8799542,-0.08292731,-0.7117264,-0.52318937,0.49320638,0.1276656,1.3288664,0.33993173,0.78235555,0.8201897,0.18645899,-1.1907068,1.0263689,-0.56561375,-0.31093332,0.1036669,-0.04277862,-0.24058516,-0.20115553,0.81236285,-0.4949463,-0.13282838,0.30448318,0.56598854,-0.21678574,0.1745657,1.5746832,0.24584843,-0.19218953,0.34198722,-0.5286969,0.7724226,-0.3299776,-0.17554773,1.0963839,0.97116107,0.169017,0.09443077,-1.164106,0.30358696,-0.5792899,0.47198102,0.6651148,-0.31600508,-0.19458684,-0.4448536,0.3885231,-0.39864236,1.0164622,0.8356695,-0.5389387,0.2807234,0.06992317,0.22603123,-0.39274767,-0.050452605,-1.0114976,-0.027927715,1.5591067,0.19660182,0.6496577,-0.6958105,-0.16212222,-0.021900048,1.1416562,0.9972536,-1.0957775,-0.5203354,0.01866728,1.111672,0.38944083,0.40234277,0.2981353,0.86704856,-0.05362302,-0.8285909,-1.338476,-0.717199,-0.42309034,-0.90212154,0.5147353,0.617966,0.29855037,-0.034268077,0.73541695,-0.84017,0.14146706,1.1365817,0.37235215,0.84849024,1.2656306,0.33908865,-0.1625254,1.486643,-0.5991002,0.58880013,-0.9706525,0.21824257,0.727457,0.7155444,-0.36310688,1.195308,0.55874467,-0.51972145,-0.7114952,-0.2158231,0.5572402,0.20063442,-0.5553128,-1.2674148,-0.2026511,-0.8284894,0.98451966,0.11313255,-0.67717254,-0.4318978,0.59184414,0.4603768,0.68528396,0.093217224,-0.6931992,-1.1574371,-0.0014968393,-0.5473851,-0.60594,-0.48609102,0.04709728,0.17231458,-0.62591434,1.285564,-0.19641918,0.435117,1.2799246,-0.23950562,-1.4541556,0.7623196,-0.33940008,-0.06694987,1.2385238,-0.12438814,-0.6234285,0.3467495,1.3182647,0.2983084,0.54886234,-0.3821138,-0.7157048,0.68808436,-0.4807542,1.0535424,-0.04271309,-0.95400596,-0.048513494,0.8613753,0.40079832,-0.9323805,0.6511912,-0.45607185,0.79491746,0.1819238,0.22949164,0.08597349,-0.37067544,0.5225607,0.7195566,0.5434812,0.54329306,0.1779145,0.29133862,0.23483539,0.8431787,0.013089586,0.31868127,0.5420595,-0.87410283,-0.9697081,-0.6453058,0.29133648,2.5340238,1.3253194,-0.8881328,-0.32066703,1.2824804,1.0221727,-0.26763415,0.31163904,0.27858803,0.84025407,-0.23817849,0.13771784,1.6022199,1.3306444,0.7373712,0.667437,0.9173947,-0.9810341,0.61585116,0.108015046,-0.89221096,0.050074432,0.8420527,-0.35320553,1.3939427,-0.9016692,0.4380305,0.6262718,-0.26793963,-0.7243096,-0.6220856,1.0813742,0.62582,-0.7889923,1.3008708,1.3269562,-0.9357097,-1.2686065,0.26324224,0.7543024,1.0810454,-0.5527667,-0.20224045,-0.35413074,-1.4515238,0.6839356,1.2602149,0.01924368,-0.13284023,-0.55298394,0.28148243,-0.578113,-0.15083262,0.9201735,0.8277814,0.6525349,0.75774306,-0.10058747,0.19628657,0.012678171,-0.71058047,1.0463209,-0.44605717,-0.09013995,-0.060064204,0.43520892,0.24938744,0.8367028,-0.5861613,-0.08897313,-0.5946265,0.037782468,-0.02753284,-1.2487742,0.8413592,-0.09283839,-0.45797706,0.41690117,-0.11327466,-0.87980723,0.06542199,-1.1202136,-0.3617644,-0.6290965,-0.96276736,0.0039715534,0.53454804,-1.1256973,-0.42970794,0.63491344,0.29443705,-0.261136,0.0688544,0.65334296,0.3853937,-0.88668597,-0.10518922,0.16502498,0.27370307,-0.23086753,-0.8426544,-0.02523673,0.5707013,0.32064736,-1.7682108,0.9870064,-0.69807523,0.20342545,0.23574527,1.1766562,-0.93288547,-0.1329706,0.812565,-1.5524588,-0.70121795,-0.64894843,-0.5315601,0.8522413,0.556583,-0.6496322,-0.019607369,-0.29488733,-0.14901397,-1.1244851,1.1246743,-1.2661017,-1.0910717,-0.27065665,-0.7840644,0.13741261,0.71956676,0.57277554,-0.059987918,-1.3073585,0.0679583,0.06150338,-0.2413301,1.181173,0.038647,-0.1763936,0.6411247,-0.9275262,-0.52768964,0.758969,-0.8568044,0.194863,-0.33251286,0.5301602,-1.1095483,-0.19794166,-0.36661154,0.01791024,-0.35560375,-1.1303954,-0.9822138,0.32957456,0.024262333,0.58712876,-1.0520266,0.40985137,0.22136985,0.4148714,-0.7881325,-0.7603261,-1.201058,0.44545126,-0.31268784,-0.0911375,-0.9474137,0.70766073,-1.5954535,-0.28667405,-0.6644674,-0.6661907,-1.3469887,0.20437463,-1.8686336,1.0984533,-0.6920984,0.72022545,-0.18531387,0.09713901,-1.28027,0.36856794,1.0963409,0.3085253,0.5758211,-1.0873268,-1.0991684,-1.1945332,1.4147696,-0.0012858845,-0.019898623,0.0838674,0.058151104,0.30621928,-0.8008934,0.32411772,0.26330274,1.1993338,0.07301557,1.5084623,1.0113813,1.891106,-0.51376545,0.77011764,1.379288,0.6208138,-0.5439957,-0.13507085,-0.17077553,0.78170574,-0.6157398,-1.0552689,-0.7270889,-0.66513515,0.18391474,-0.16033518,0.23596665,0.6332116,0.079978116,-0.010704674,-0.29797676,-1.264408,-0.71858144,0.8852769,0.13513578,-0.48498327,-0.76354885,0.46744847,-0.06338583,0.9863877,0.44145975,0.35007533,0.17433311,-0.14857063,0.42817578,0.20934817,-1.0305192,0.19799438,-1.2699542,0.8613956,-0.6487293,0.28959,-0.5808258,0.1115409,-0.39803317,1.2781086,-0.2946511,-0.70335704,1.0558913,-0.28801838,-0.49543244,-0.21919958,-0.05814644,0.040994514,-0.51238894,0.48812562,0.8298293,-0.4024946,-0.063363165,0.011525999,-0.6901876,0.45768446,-0.67458165,-0.11870883,0.27917978,-0.26557326,0.6072603,-0.17364243,-0.2085914,-1.0014049,-0.94191176,0.1960114,-0.3867555,1.297422,-0.7533415,-1.4259531,0.096966214,0.36970922,0.28595728,1.0665994,-1.2965876,0.8320143,-0.8281983,-0.5379429,0.0097062085,-0.9340146,0.7636509,-0.8362665,-0.4278681,-0.70443124,-0.10497214,-1.6492169,-0.012707474,-1.1899203,0.9712675,-0.17023939,-0.2923206,0.5606225,-0.1810083,0.57580864,0.45573053,1.1162733,-0.09576282,-0.3825168,0.2096493,0.002956815,-0.22354785,0.2507452,-0.3076428,-0.049730763,-0.27920824,1.7080399,0.7190778,0.11882608,-1.1506785,0.9116508,0.08876432,-0.3968074,-1.2213954,0.07125327,-0.9351781]	1	2026-10-26 06:08:06.072761+00
\.


--
-- Data for Name: research_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_chunks (id, document_id, chunk_index, text, token_count, embedding, status, created_at) FROM stdin;
\.


--
-- Data for Name: research_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_claims (id, document_id, chunk_id, underlying_code, channel, stance, magnitude, confidence, horizon, catalyst, is_risk_event, event_date, statement, quote, quote_verified, origin, published_at, extraction_version, embedding, status, created_at) FROM stdin;
\.


--
-- Data for Name: research_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_config (id, version, weights, thresholds, limits, note, status, created_at) FROM stdin;
1	1	{"scale": 5.0, "domainCap": 0.3, "channelMacro": 0.5, "channelDirect": 1.0, "channelSector": 0.7, "halfLifeHours": 12.0, "channelConstituent": 0.8}	{"topN": 5, "minSources": 3, "windowHours": 24, "maxStaleHours": 12, "negShareLimit": 0.25, "bearishShareMin": 0.6, "negMagnitudeMin": 3, "vetoOnEventRisk": false, "negConfidenceMin": 0.5, "minPositiveClaims": 2, "minPositiveWeight": 1.0, "negCredibilityMin": 0.5, "eventLookaheadHours": 36, "includeBearishWatch": true, "suggestNeutralClear": false}	{"concurrency": 2, "llmTimeoutSec": 90, "retentionDays": 90, "fetchTimeoutSec": 15, "runTimeoutMinutes": 45, "maxDocsPerUnderlying": 20}	Initial baseline research configuration v1.0	1	2026-10-22 10:42:17.501176+00
\.


--
-- Data for Name: research_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_documents (id, url_hash, url, canonical_url, domain, source_id, title, published_at, fetched_at, content_hash, text, word_count, language, fetch_status, duplicate_of_id, first_seen_run_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: research_queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_queries (id, run_id, underlying_code, query_text, provider, result_count, planned_by, status, created_at) FROM stdin;
1	6	\N	India inflation RBI monetary policy 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
2	6	\N	FII DII market flows Indian equities 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
3	6	\N	Crude oil OPEC supply demand energy news 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
4	6	NIFTY	Nifty 50 news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
5	6	NIFTY	Nifty 50 outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
6	6	NIFTY	NIFTY RBI policy 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
7	6	BANKNIFTY	Bank Nifty news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
8	6	BANKNIFTY	Bank Nifty outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
9	6	BANKNIFTY	BANKNIFTY repo rate 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
10	6	FINNIFTY	Fin Nifty news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
11	6	FINNIFTY	Fin Nifty outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
12	6	FINNIFTY	FINNIFTY NBFC borrowing 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
13	6	MIDCPNIFTY	Midcap Nifty news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
14	6	MIDCPNIFTY	Midcap Nifty outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
15	6	MIDCPNIFTY	MIDCPNIFTY midcap rally 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
16	6	SENSEX	BSE Sensex news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
17	6	SENSEX	BSE Sensex outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
18	6	SENSEX	SENSEX BSE market cap 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
19	6	BANKEX	BSE Bankex news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
20	6	BANKEX	BSE Bankex outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
21	6	BANKEX	BANKEX private banks 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
22	6	CRUDEOIL	Brent Crude news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
23	6	CRUDEOIL	Brent Crude outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
24	6	CRUDEOIL	CRUDEOIL OPEC+ production 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
25	6	NATURALGAS	Natural Gas news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
26	6	NATURALGAS	Natural Gas outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
27	6	NATURALGAS	NATURALGAS EIA storage report 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
28	6	GOLD	Spot Gold news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
29	6	GOLD	Spot Gold outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
30	6	GOLD	GOLD US Federal Reserve interest rates 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
31	6	SILVER	Spot Silver news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
32	6	SILVER	Spot Silver outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
33	6	SILVER	SILVER industrial demand 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
34	6	COPPER	MCX Copper news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
35	6	COPPER	MCX Copper outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
36	6	COPPER	COPPER China manufacturing PMI 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
37	6	ZINC	MCX Zinc news today 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
38	6	ZINC	MCX Zinc outlook forecast market analysis	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
39	6	ZINC	ZINC smelter treatment charges 2026-10-26	SEARCH	0	TEMPLATE	1	2026-10-26 06:07:36.757842+00
\.


--
-- Data for Name: research_risk_terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_risk_terms (id, term, category, default_severity, applies_to_types, enabled, status, created_at) FROM stdin;
1	fraud	FRAUD	5	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
2	probe	LEGAL_REGULATORY	4	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
3	raid	LEGAL_REGULATORY	5	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
4	ban	LEGAL_REGULATORY	4	["INDEX", "COMMODITY", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
5	penalty	LEGAL_REGULATORY	3	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
6	sebi order	LEGAL_REGULATORY	4	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
7	default	DEFAULT	5	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
8	downgrade	DOWNGRADE	3	["INDEX", "STOCK", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
9	sell-off	SELL_OFF	3	["INDEX", "STOCK", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
10	plunge	SELL_OFF	3	["INDEX", "STOCK", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
11	crash	SELL_OFF	4	["INDEX", "STOCK", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
12	lower circuit	HALT	4	["INDEX", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
13	halt	HALT	4	["INDEX", "STOCK", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
14	war	GEOPOLITICAL	4	["INDEX", "COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
15	sanction	GEOPOLITICAL	4	["COMMODITY", "INDEX"]	t	1	2026-10-22 10:42:17.501176+00
16	strike	SUPPLY_SHOCK	3	["COMMODITY", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
17	shutdown	SUPPLY_SHOCK	3	["COMMODITY", "STOCK"]	t	1	2026-10-22 10:42:17.501176+00
18	outage	SUPPLY_SHOCK	3	["COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
19	oil spill	SUPPLY_SHOCK	3	["COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
20	embargo	GEOPOLITICAL	4	["COMMODITY"]	t	1	2026-10-22 10:42:17.501176+00
\.


--
-- Data for Name: research_run_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_run_documents (id, run_id, document_id, underlying_code, query_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: research_run_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_run_events (id, run_id, seq, node, level, message, data, status, created_at) FROM stdin;
1	6	1	load_context	INFO	Loaded 12 underlyings, 12 sources, and 20 risk terms.	null	1	2026-10-26 06:07:36.696059+00
2	6	2	plan_queries	INFO	Planned 39 fresh search queries across 12 underlyings.	null	1	2026-10-26 06:07:36.76101+00
3	6	3	search_and_fetch	INFO	Fetched 0 valid HTML articles (0 blocked by robots.txt/paywall).	null	1	2026-10-26 06:08:05.623501+00
4	6	4	clean_filter_dedupe	INFO	Retained 0 fresh, deduplicated articles published inside 24.0h window.	null	1	2026-10-26 06:08:05.628047+00
5	6	5	embed_chunks	INFO	Created and embedded 0 text chunks with 768-dimensional vectors.	null	1	2026-10-26 06:08:05.631938+00
6	6	6	extract_claims	INFO	Extracted 0 initial assertions from fresh documents.	null	1	2026-10-26 06:08:05.633297+00
7	6	7	verify_claims	INFO	Verified 0 claims with verbatim quotes (0 unverified dropped).	null	1	2026-10-26 06:08:05.636038+00
8	6	8	negative_sweep	INFO	Negative risk sweep complete. Found 0 risk keyword occurrences.	null	1	2026-10-26 06:08:05.638701+00
9	6	9	classify_status	INFO	Classified status for 12 underlyings.	null	1	2026-10-26 06:08:05.640061+00
10	6	10	finalize	INFO	Run 6 finished with state=COMPLETED, resultKind=NONE_SUGGESTED.	{"docsKept": 0, "llmCalls": 0, "docsBlocked": 0, "docsFetched": 15, "claimsReused": 0, "claimsDropped": 0, "sweepFindings": 0, "chunksEmbedded": 0, "claimsVerified": 0, "claimsExtracted": 0, "durationsByNodeMs": {"persist": 437, "score_rank": 0, "embed_chunks": 1, "load_context": 72, "plan_queries": 6, "write_briefs": 0, "verify_claims": 2, "extract_claims": 2, "negative_sweep": 1, "classify_status": 1, "search_and_fetch": 28864, "clean_filter_dedupe": 4}, "unreviewedSignalsByUnderlying": {"GOLD": false, "ZINC": false, "NIFTY": false, "BANKEX": false, "COPPER": false, "SENSEX": false, "SILVER": false, "CRUDEOIL": false, "FINNIFTY": false, "BANKNIFTY": false, "MIDCPNIFTY": false, "NATURALGAS": false}}	1	2026-10-26 06:08:06.081404+00
\.


--
-- Data for Name: research_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_runs (id, scope, trigger_source, triggered_by, state, result_kind, params, config_version, current_node, progress_pct, stats, resumable, thread_id, started_at, finished_at, error, status, created_at) FROM stdin;
1	["INDEX"]	MASTER	\N	COMPLETED	\N	{"scope": ["INDEX"]}	1	\N	0	{}	f	thread-research-1792668052	\N	\N	\N	1	2026-10-22 11:20:52.037137+00
2	["INDEX"]	MASTER	\N	CANCELLED	\N	{"scope": ["INDEX"]}	1	\N	0	{}	f	thread-research-1792668495	\N	\N	\N	1	2026-10-22 11:28:15.976258+00
3	["INDEX"]	MASTER	\N	CANCELLED	\N	{"scope": ["INDEX"]}	1	\N	0	{}	f	thread-research-1792668552	\N	\N	\N	1	2026-10-22 11:29:12.530717+00
4	["INDEX"]	MASTER	\N	CANCELLED	\N	{"scope": ["INDEX"]}	1	\N	0	{}	f	thread-research-1792669210	\N	\N	\N	1	2026-10-22 11:40:10.839532+00
5	["INDEX"]	MASTER	\N	COMPLETED	\N	{"scope": ["INDEX"]}	1	\N	0	{}	f	thread-research-1792669220	\N	\N	\N	1	2026-10-22 11:40:20.005717+00
6	["INDEX", "COMMODITY"]	API	\N	COMPLETED	NONE_SUGGESTED	{"topN": 5, "scope": ["INDEX", "COMMODITY"], "windowHours": 24}	1	finalize	100	{"docsKept": 0, "llmCalls": 0, "docsBlocked": 0, "docsFetched": 15, "claimsReused": 0, "claimsDropped": 0, "sweepFindings": 0, "chunksEmbedded": 0, "claimsVerified": 0, "claimsExtracted": 0, "durationsByNodeMs": {"persist": 437, "score_rank": 0, "embed_chunks": 1, "load_context": 72, "plan_queries": 6, "write_briefs": 0, "verify_claims": 2, "extract_claims": 2, "negative_sweep": 1, "classify_status": 1, "search_and_fetch": 28864, "clean_filter_dedupe": 4}, "unreviewedSignalsByUnderlying": {"GOLD": false, "ZINC": false, "NIFTY": false, "BANKEX": false, "COPPER": false, "SENSEX": false, "SILVER": false, "CRUDEOIL": false, "FINNIFTY": false, "BANKNIFTY": false, "MIDCPNIFTY": false, "NATURALGAS": false}}	f	thread-research-1792994856	2026-10-26 06:07:36.669363+00	2026-10-26 06:08:06.078839+00	\N	1	2026-10-26 06:07:36.656792+00
\.


--
-- Data for Name: research_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_sources (id, name, source_type, base_url, feed_url, credibility_weight, applies_to_types, applies_to_groups, enabled, last_fetch_at, last_error, ok_count, fail_count, status, created_at) FROM stdin;
1	Economic Times Markets	RSS	https://economictimes.indiatimes.com	\N	0.85	["INDEX", "STOCK", "COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
2	Moneycontrol Markets	RSS	https://www.moneycontrol.com	\N	0.80	["INDEX", "STOCK", "COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
3	Mint Markets	RSS	https://www.livemint.com	\N	0.85	["INDEX", "STOCK"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
4	Business Standard Markets	RSS	https://www.business-standard.com	\N	0.85	["INDEX", "STOCK", "COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
5	Reuters Business & Commodities	AGENCY	https://www.reuters.com	\N	0.95	["INDEX", "COMMODITY", "STOCK"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
6	EIA Petroleum & Energy Reports	AGENCY	https://www.eia.gov	\N	0.95	["COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
7	OPEC Press Releases	AGENCY	https://www.opec.org	\N	0.95	["COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
8	IEA International Energy Agency	AGENCY	https://www.iea.org	\N	0.90	["COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
9	World Gold Council	AGENCY	https://www.gold.org	\N	0.90	["COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
10	Reserve Bank of India (RBI)	AGENCY	https://www.rbi.org.in	\N	0.98	["INDEX", "STOCK"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
11	US Federal Reserve	AGENCY	https://www.federalreserve.gov	\N	0.98	["INDEX", "COMMODITY"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
12	Web Intelligence Search	SEARCH	https://searx.be	\N	0.70	["INDEX", "COMMODITY", "STOCK"]	\N	t	\N	\N	0	0	1	2026-10-22 10:42:17.501176+00
\.


--
-- Data for Name: research_underlyings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_underlyings (id, code, name, underlying_type, group_name, exchange, aliases, keywords, heavyweights, enabled, sort_order, status, created_at) FROM stdin;
1	NIFTY	Nifty 50 Index	INDEX	Indices	NSE	["Nifty 50", "NSE Nifty", "NIFTY50", "Nifty Index", "Indian benchmark Nifty"]	["RBI policy", "FII flows", "DII buying", "India VIX", "headline inflation", "GDP growth"]	[{"name": "HDFC Bank", "aliases": ["HDFCBANK", "HDFC Bank Ltd"], "weightPct": 13.5}, {"name": "Reliance Industries", "aliases": ["RELIANCE", "RIL"], "weightPct": 10.2}, {"name": "ICICI Bank", "aliases": ["ICICIBANK", "ICICI Bank Ltd"], "weightPct": 7.8}, {"name": "Infosys", "aliases": ["INFY", "Infosys Ltd"], "weightPct": 5.9}]	t	1	1	2026-10-22 10:42:17.501176+00
2	BANKNIFTY	Nifty Bank Index	INDEX	Indices	NSE	["Bank Nifty", "NSE Bank Nifty", "Nifty Bank", "Banking Index"]	["repo rate", "credit growth", "NPA", "net interest margin", "RBI liquidity", "banking regulatory norms"]	[{"name": "HDFC Bank", "aliases": ["HDFCBANK"], "weightPct": 29.0}, {"name": "ICICI Bank", "aliases": ["ICICIBANK"], "weightPct": 23.0}, {"name": "State Bank of India", "aliases": ["SBIN", "SBI"], "weightPct": 11.0}, {"name": "Axis Bank", "aliases": ["AXISBANK"], "weightPct": 9.5}]	t	2	1	2026-10-22 10:42:17.501176+00
3	FINNIFTY	Nifty Financial Services Index	INDEX	Indices	NSE	["Fin Nifty", "Nifty Financial Services", "Finnifty"]	["NBFC borrowing", "insurance premium growth", "housing finance", "interest rate cycle"]	[]	t	3	1	2026-10-22 10:42:17.501176+00
4	MIDCPNIFTY	Nifty Midcap Select Index	INDEX	Indices	NSE	["Midcap Nifty", "Nifty Midcap Select", "Midcap Select"]	["midcap rally", "retail flows", "market breadth", "valuation multiples"]	[]	t	4	1	2026-10-22 10:42:17.501176+00
5	SENSEX	BSE Sensex Index	INDEX	Indices	BSE	["BSE Sensex", "Sensex 30", "S&P BSE Sensex"]	["BSE market cap", "FII investment", "global cues", "corporate earnings"]	[]	t	5	1	2026-10-22 10:42:17.501176+00
6	BANKEX	BSE Bankex Index	INDEX	Indices	BSE	["BSE Bankex", "Bankex Index"]	["private banks", "PSU banks", "RBI circular", "deposit rates"]	[]	t	6	1	2026-10-22 10:42:17.501176+00
7	CRUDEOIL	Crude Oil	COMMODITY	Energy	MCX	["Brent Crude", "WTI Crude", "MCX Crude Oil", "Petroleum crude", "Crude oil futures"]	["OPEC+ production", "EIA inventory", "Middle East geopolitical tension", "Strait of Hormuz", "US shale production"]	[]	t	10	1	2026-10-22 10:42:17.501176+00
8	NATURALGAS	Natural Gas	COMMODITY	Energy	MCX	["Natural Gas", "MCX Natural Gas", "Henry Hub Natural Gas", "NatGas"]	["EIA storage report", "LNG exports", "winter heating demand", "summer cooling demand", "pipeline maintenance"]	[]	t	11	1	2026-10-22 10:42:17.501176+00
9	GOLD	Gold	COMMODITY	Metals	MCX	["Spot Gold", "MCX Gold", "Gold futures", "Yellow metal", "XAUUSD"]	["US Federal Reserve interest rates", "US dollar index DXY", "central bank gold buying", "safe haven demand", "Treasury yields"]	[]	t	12	1	2026-10-22 10:42:17.501176+00
10	SILVER	Silver	COMMODITY	Metals	MCX	["Spot Silver", "MCX Silver", "Silver futures", "XAGUSD"]	["industrial demand", "solar photovoltaic demand", "gold silver ratio", "COMEX inventory"]	[]	t	13	1	2026-10-22 10:42:17.501176+00
11	COPPER	Copper	COMMODITY	Metals	MCX	["MCX Copper", "LME Copper", "Doctor Copper", "Copper cathode"]	["China manufacturing PMI", "smelter production cuts", "LME warehouse stocks", "green energy transition"]	[]	t	14	1	2026-10-22 10:42:17.501176+00
12	ZINC	Zinc	COMMODITY	Metals	MCX	["MCX Zinc", "LME Zinc", "Zinc ingots"]	["smelter treatment charges", "galvanizing demand", "mining production halts", "European energy costs"]	[]	t	15	1	2026-10-22 10:42:17.501176+00
\.


--
-- Data for Name: rule_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_versions (id, rule_id, version_no, content, change_note, status, created_at) FROM stdin;
1	1	1	{"when": {"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": ["RANGING", "SIDEWAYS", "BEARISH"]}, "operator": "IN"}, "effect": null, "unless": {"op": "ALL", "items": [{"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": "TRENDING_UP"}, "operator": "EQUALS"}, {"left": {"code": "ADX", "output": "adx", "params": null, "source": "INDICATOR"}, "right": {"param": "minAdx"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}, "parameters": {"minAdx": 20}}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
2	2	1	{"when": {"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": ["RANGING", "SIDEWAYS", "BEARISH"]}, "operator": "IN"}, "effect": null}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
3	3	1	{"effect": null, "require": {"left": {"field": "grossTargetPerUnit", "source": "TRADE_PLAN"}, "right": {"const": 15}, "operator": "IS_ABOVE_OR_EQUAL"}}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rules (id, code, name, rule_kind, rule_type, action, priority, applies_to, condition_text, current_version_id, evidence, review_by, executable, review_flags, provenance, enabled, status, created_at) FROM stdin;
1	EMPIRICAL-CALL-REGIME-001	Avoid calls outside a confirmed uptrend	GUARDRAIL	MARKET_REGIME	AVOID	HIGH	{"markets": ["NIFTY", "BANKNIFTY", "SENSEX"], "optionSides": ["CALL"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE", "PAPER"]}	Avoid CALL option entries when market regime shows RANGING, BEARISH or SIDEWAYS conditions. Empirical data from 52 CALL paper trades shows 34.6% aggregate win rate (20-24% in bearish/ranging markets) vs 51.3% on PUT trades in same period. STRONG_COUNTER_TREND failure pattern detected 14 times on vwap_pullback_v1. Only enter CALL when regime is confirmed TRENDING_UP with ADX > 20 and spot > VWAP.	1	{"count": 52, "justification": "Empirical data from 52 CALL paper trades shows 34.6% aggregate win rate.", "failureRatePct": 65.0, "successRatePct": 35.0}	\N	f	["REGIME_DEPENDENT_EVIDENCE"]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-CALL-REGIME-001", "EMPIRICAL-CALL-REGIME-001-PAPER"]}	t	1	2026-10-20 06:44:12.072716+00
2	EMPIRICAL-PUT-PREFERENCE-003	Prefer puts over calls in sideways or bearish regimes	GUARDRAIL	DIRECTION_PREFERENCE	PREFER	MEDIUM	{"markets": ["NIFTY", "BANKNIFTY", "SENSEX"], "optionSides": ["CALL", "PUT"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE"]}	Prefer PUT option entries over CALL entries when market regime is RANGING, SIDEWAYS, or BEARISH. In confirmed downtrend or sideways conditions, PUT entries have demonstrated significantly higher win rates and positive net P&L.	2	{"count": 91, "justification": "PUT win rate = 51.3% (net +7,089 INR) vs CALL win rate = 34.6% (net -10,533 INR).", "failureRatePct": 49.0, "successRatePct": 51.0}	\N	f	["REGIME_DEPENDENT_EVIDENCE"]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-PUT-PREFERENCE-003"]}	t	1	2026-10-20 06:44:12.072716+00
3	EMPIRICAL-SENSEX-NET-EV-002	Require minimum gross premium movement for SENSEX trades	GUARDRAIL	CAPITAL	WATCH	HIGH	{"markets": ["SENSEX"], "optionSides": ["CALL", "PUT"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE"]}	For SENSEX trades (BSE lot size = 10), require minimum gross premium target movement of 15 INR per unit (= 150 INR gross per lot) before entering. Round-trip transaction costs for SENSEX are ~83-90 INR per lot.	3	{"count": 3, "justification": "Observed in 3 recent SENSEX TARGET_HIT trades with negative net_pnl due to friction costs.", "failureRatePct": 60.0, "successRatePct": 40.0}	\N	t	[]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-SENSEX-NET-EV-002"]}	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategies (id, code, name, description, category, structure, bias, option_side, markets, underlying_types, exchange, trading_modes, execution_modes, timeframe, definition_format, executable, lifecycle_status, health, health_override, health_override_reason, health_override_until, validation_status, enabled, risk_profile, "references", risk_notes, how_it_works, tags, attributes, provenance, review_flags, current_version_id, status, created_at) FROM stdin;
1	ORB_15M	15-Minute Opening Range Breakout	Built-in textbook algorithmic trading strategy: 15-Minute Opening Range Breakout.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	1	1	2026-10-20 06:44:12.072716+00
2	PDH_PDL_BREAK	Previous Day High / Low Breakout	Built-in textbook algorithmic trading strategy: Previous Day High / Low Breakout.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "BREAKOUT"]	\N	{"source": "BUILT_IN"}	\N	2	1	2026-10-20 06:44:12.072716+00
3	VWAP_RECLAIM	VWAP Reclaim & Continuation	Built-in textbook algorithmic trading strategy: VWAP Reclaim & Continuation.	VWAP	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "VWAP"]	\N	{"source": "BUILT_IN"}	\N	3	1	2026-10-20 06:44:12.072716+00
4	EMA_PULLBACK	9/21 EMA Trend Pullback	Built-in textbook algorithmic trading strategy: 9/21 EMA Trend Pullback.	TREND	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "TREND"]	\N	{"source": "BUILT_IN"}	\N	4	1	2026-10-20 06:44:12.072716+00
5	SUPERTREND_ADX	Supertrend with ADX Confirmation	Built-in textbook algorithmic trading strategy: Supertrend with ADX Confirmation.	TREND	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "TREND"]	\N	{"source": "BUILT_IN"}	\N	5	1	2026-10-20 06:44:12.072716+00
6	BB_SQUEEZE	Bollinger Band Squeeze Breakout	Built-in textbook algorithmic trading strategy: Bollinger Band Squeeze Breakout.	VOLATILITY	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "VOLATILITY"]	\N	{"source": "BUILT_IN"}	\N	6	1	2026-10-20 06:44:12.072716+00
7	INSIDE_BAR_BREAK	Inside Bar Momentum Breakout	Built-in textbook algorithmic trading strategy: Inside Bar Momentum Breakout.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "BREAKOUT"]	\N	{"source": "BUILT_IN"}	\N	7	1	2026-10-20 06:44:12.072716+00
8	CPR_NARROW	Central Pivot Range (CPR) Trend Reversal	Built-in textbook algorithmic trading strategy: Central Pivot Range (CPR) Trend Reversal.	REVERSAL	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	8	1	2026-10-20 06:44:12.072716+00
9	RSI_LEVEL_REVERSAL	RSI Oversold Level Reversal	Built-in textbook algorithmic trading strategy: RSI Oversold Level Reversal.	REVERSAL	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	9	1	2026-10-20 06:44:12.072716+00
10	OI_WALL_BOUNCE	Open Interest Wall Support Bounce	Built-in textbook algorithmic trading strategy: Open Interest Wall Support Bounce.	OI_BASED	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "OI_BASED"]	\N	{"source": "BUILT_IN"}	\N	10	1	2026-10-20 06:44:12.072716+00
11	OI_BUILDUP_MOMENTUM	Call/Put Unwinding & OI Buildup	Built-in textbook algorithmic trading strategy: Call/Put Unwinding & OI Buildup.	OI_BASED	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "OI_BASED"]	\N	{"source": "BUILT_IN"}	\N	11	1	2026-10-20 06:44:12.072716+00
12	GAP_AND_GO	Morning Gap & Go Trend Continuation	Built-in textbook algorithmic trading strategy: Morning Gap & Go Trend Continuation.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	12	1	2026-10-20 06:44:12.072716+00
13	GAP_FADE	Morning Gap Fade Mean Reversion	Built-in textbook algorithmic trading strategy: Morning Gap Fade Mean Reversion.	REVERSAL	SINGLE_LONG	BEARISH	PUT	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	13	1	2026-10-20 06:44:12.072716+00
14	EXPIRY_MOMENTUM	Expiry Day Afternoon Momentum Spike	Built-in textbook algorithmic trading strategy: Expiry Day Afternoon Momentum Spike.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	14	1	2026-10-20 06:44:12.072716+00
15	EVENT_REACTION	Macro Event Blackout & Trend Reaction	Built-in textbook algorithmic trading strategy: Macro Event Blackout & Trend Reaction.	EVENT	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "EVENT"]	\N	{"source": "BUILT_IN"}	\N	15	1	2026-10-20 06:44:12.072716+00
16	crudeoil_momentum_breakout_v1	Crude Oil Commodity Momentum Breakout V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	MOMENTUM	\N	\N	\N	["CRUDEOIL"]	["COMMODITY"]	MCX	["SHORT_TERM", "INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	DEGRADED	\N	\N	\N	UNTESTED	t	{"lotSize": 100, "targetRr": 2.2, "maxRiskPct": 20, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "MOMENTUM", "tradingModesRaw": "SHORT_TERM,INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	16	1	2026-10-20 06:44:12.072716+00
17	nifty_expiry_day_selling_v1	Nifty Expiry Day Selling	Open the position: Shortly after the market opens, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Switch for the final hour: Closes the first position and opens a tighter second one to capture the faster decay near expiry. Exit before close: Each sold option has its own stop-loss — 50% on each sell leg in the First setup and 70% in the Second setup* — and all positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 200000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 10000}	[]	[]	[{"title": "Open the position", "description": "Shortly after the market opens, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Switch for the final hour", "description": "Closes the first position and opens a tighter second one to capture the faster decay near expiry."}, {"title": "Exit before close", "description": "Each sold option has its own stop-loss — 50% on each sell leg in the First setup and 70% in the Second setup* — and all positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "algoverse_id": 19, "originalType": "IRON_CONDOR", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	17	1	2026-10-20 06:44:12.072716+00
18	banknifty_bearish_buying_v1	Bank Nifty Bearish Buying	Confirms the bearish trend: Uses Bollinger Bands, RSI, EMA, and CCI to check that Bank Nifty is under strong selling pressure. Validates participation: Confirms enough traded volume is behind the move before committing to a trade. Buys the put: Enters a Bank Nifty ATM put option once the signals line up. Manages the risk: Exits on SL or Target, whichever comes first. Actual exit price may vary slightly from what's set as SL or Target.	BREAKOUT	SINGLE_LONG	BEARISH	PUT	["BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 60000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 14730}	[]	[]	[{"title": "Confirms the bearish trend", "description": "Uses Bollinger Bands, RSI, EMA, and CCI to check that Bank Nifty is under strong selling pressure."}, {"title": "Validates participation", "description": "Confirms enough traded volume is behind the move before committing to a trade."}, {"title": "Buys the put", "description": "Enters a Bank Nifty ATM put option once the signals line up."}, {"title": "Manages the risk", "description": "Exits on SL or Target, whichever comes first. Actual exit price may vary slightly from what's set as SL or Target."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 9, "originalType": "BREAKDOWN", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:BANKNIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	18	1	2026-10-20 06:44:12.072716+00
19	nifty_credit_spread_pe_v1	Nifty Bull Put Credit Spread	Checks for strength: Uses Super Trend and Pivot Points to confirm Nifty has pushed above a key resistance level and is turning bullish. Places both legs: Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined. Exits: Closes the trade when Super Trend changes direction, or by the set exit time* — whichever comes first.	PREMIUM_SELLING	BULL_PUT_SPREAD	BULLISH	PUT	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 39753}	[]	[]	[{"title": "Checks for strength", "description": "Uses Super Trend and Pivot Points to confirm Nifty has pushed above a key resistance level and is turning bullish."}, {"title": "Places both legs", "description": "Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined."}, {"title": "Exits", "description": "Closes the trade when Super Trend changes direction, or by the set exit time* — whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 8, "originalType": "BULL_PUT_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	19	1	2026-10-20 06:44:12.072716+00
20	nifty_trend_surge_buying_v1	Trend Surge Buying	Confirm the trend: Checks that price is holding above the day's VWAP, showing genuine bullish strength. Validate the breakout: Confirms price has pushed above the previous day's high and the day's highest high before committing to a trade. Buy the call: Enters a Nifty call option around ₹200 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below VWAP or the option loses 30%, whichever comes first.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 26887}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that price is holding above the day's VWAP, showing genuine bullish strength."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above the previous day's high and the day's highest high before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹200 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below VWAP or the option loses 30%, whichever comes first."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 5, "originalType": "BREAKOUT", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	20	1	2026-10-20 06:44:12.072716+00
21	nifty_option_pulse_buying_v1	Option Pulse Buying	Confirm the trend: Checks that Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, RSI and CCI. Validate the breakout: Confirms price has pushed above key resistance and recent highs, using Signals such as Pivot Points, before committing to a trade. Buy the call: Enters a Nifty call option around ₹200 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the stop-loss triggers, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 20816}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, RSI and CCI."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above key resistance and recent highs, using Signals such as Pivot Points, before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹200 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the stop-loss triggers, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 6, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	21	1	2026-10-20 06:44:12.072716+00
22	breakout_trend_v1	Breakout & Key Level Trend V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	BREAKOUT	\N	\N	\N	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	HEALTHY	\N	\N	\N	UNTESTED	t	{"lotSize": null, "targetRr": 2.2, "maxRiskPct": 20, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "originalType": "BREAKOUT", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	22	1	2026-10-20 06:44:12.072716+00
23	paper_research_orb15_v1	Paper Research: Confirmed Opening-Range Breakout	Experimental long-call/put adaptation. Requires a complete 09:15–09:30 range, two closed breakout bars, trend alignment and no extended chase. Not validated for Indian index options.	BREAKOUT	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY", "SENSEX"]	["INDEX"]	\N	["INTRADAY"]	["PAPER"]	\N	EVALUATOR	f	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[{"url": "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4729284", "scope": "US stocks in play; results do not establish an edge in Indian index options.", "title": "Zarattini, Barbon & Aziz: A Profitable Day Trading Strategy For The U.S. Equity Market"}, {"url": "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7428398", "scope": "2026 futures preprint with negative cost-adjusted results; a counterexample to universal ORB profitability.", "title": "Fetna: Opening-Range Breakout Does Not Survive Trading Costs"}, {"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr", "scope": "Volatility measurement and stop construction; not a return forecast.", "title": "Fidelity: Average True Range"}]	["One long-option lot only; no averaging down or multi-leg execution.", "No expiry-day entries. Bid/ask depth, real Greeks and costs are required.", "Premium stop uses a delta-times-ATR approximation, not an option pricing forecast.", "V3 position policy owns exits; local stops can fill worse after gaps."]	null	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "originalType": "BREAKOUT", "executionModes": ["PAPER"], "researchStatus": "PAPER_HYPOTHESIS", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["RESEARCH_HYPOTHESIS_NOT_VALIDATED", "EVALUATOR_HANDLER_REQUIRED"]	23	1	2026-10-20 06:44:12.072716+00
24	nifty_momentum_option_buying_v1	Momentum Option Buying	Confirm the trend: Checks that Nifty is in a strong uptrend with expanding volatility, using Signals such as Super Trend and Bollinger Bands. Validate the breakout: Confirms momentum and a push above key resistance and recent highs, using Signals such as RSI, CCI, ADX and Pivot Points, along with a volume check for liquidity. Buy the call: Enters a Nifty call option around ₹240 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the leg-wise stop-loss is hit, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 40000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 15690}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Nifty is in a strong uptrend with expanding volatility, using Signals such as Super Trend and Bollinger Bands."}, {"title": "Validate the breakout", "description": "Confirms momentum and a push above key resistance and recent highs, using Signals such as RSI, CCI, ADX and Pivot Points, along with a volume check for liquidity."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹240 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the leg-wise stop-loss is hit, whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 1, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	24	1	2026-10-20 06:44:12.072716+00
25	nifty_trend_catcher_v1	Nifty Trend Catcher	Watches both directions: Uses Super Trend, Bollinger Bands, RSI, and CCI to monitor Nifty for either a bullish breakout or a bearish breakdown, and commits to whichever triggers first. Validates the move: Confirms the breakout past key Pivot Point levels and recent highs or lows before committing to a trade. Buys the option: Enters a call for a bullish move or a put for a bearish move, around 0.66 delta, once the signals line up. Manages the risk: Exits when Super Trend reverses or the option loses 10% of its value, whichever comes first. If the trade exits in a loss, a defined opposite-side trade may follow with double the initial quantity if the reversal trade is confirmed.	TREND	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 21037}	[]	[]	[{"title": "Watches both directions", "description": "Uses Super Trend, Bollinger Bands, RSI, and CCI to monitor Nifty for either a bullish breakout or a bearish breakdown, and commits to whichever triggers first."}, {"title": "Validates the move", "description": "Confirms the breakout past key Pivot Point levels and recent highs or lows before committing to a trade."}, {"title": "Buys the option", "description": "Enters a call for a bullish move or a put for a bearish move, around 0.66 delta, once the signals line up."}, {"title": "Manages the risk", "description": "Exits when Super Trend reverses or the option loses 10% of its value, whichever comes first. If the trade exits in a loss, a defined opposite-side trade may follow with double the initial quantity if the reversal trade is confirmed."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "algoverse_id": 3, "originalType": "TREND", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	25	1	2026-10-20 06:44:12.072716+00
26	banknifty_bullish_buying_v1	Bank Nifty Bullish Buying	Confirm the trend: Checks that Bank Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, Bollinger Bands, RSI and CCI. Validate the breakout: Confirms price has pushed above key resistance and recent highs, using Signals such as Camarilla Pivot Points, before committing to a trade. Buy the call: Enters a Bank Nifty call option around 0.61 delta once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the option loses 30%, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 17580}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Bank Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, Bollinger Bands, RSI and CCI."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above key resistance and recent highs, using Signals such as Camarilla Pivot Points, before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Bank Nifty call option around 0.61 delta once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the option loses 30%, whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 4, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:BANKNIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	26	1	2026-10-20 06:44:12.072716+00
27	nifty_delta_strangle_v1	Nifty Intraday Delta Based Strangle	Open the position: At a fixed time in the session, sells a call and a put chosen by delta and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Manage the risk: Each sold option has its own stop-loss with trailing, and profit-booking locks in gains when the move goes its way. Exit before close: All positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 250000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 25000}	[]	[]	[{"title": "Open the position", "description": "At a fixed time in the session, sells a call and a put chosen by delta and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Manage the risk", "description": "Each sold option has its own stop-loss with trailing, and profit-booking locks in gains when the move goes its way."}, {"title": "Exit before close", "description": "All positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": null, "algoverse_id": 17, "originalType": "SHORT_STRANGLE", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS", "STRUCTURE_DERIVED_FROM_LEGS:SHORT_STRANGLE->IRON_CONDOR"]	27	1	2026-10-20 06:44:12.072716+00
28	nifty_credit_spread_ce_v1	Nifty Bear Call Credit Spread	Checks for weakness: Uses Super Trend and Pivot Points to confirm Nifty has broken below a support level and is turning bearish. Places both legs: Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined. Exits: Closes the trade when Super Trend flips direction, or by the set exit time* - whichever comes first.	PREMIUM_SELLING	BEAR_CALL_SPREAD	BEARISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 26002}	[]	[]	[{"title": "Checks for weakness", "description": "Uses Super Trend and Pivot Points to confirm Nifty has broken below a support level and is turning bearish."}, {"title": "Places both legs", "description": "Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined."}, {"title": "Exits", "description": "Closes the trade when Super Trend flips direction, or by the set exit time* - whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 7, "originalType": "BEAR_CALL_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	28	1	2026-10-20 06:44:12.072716+00
29	paper_research_ema_pullback_v1	Paper Research: EMA Trend Pullback	Experimental long-call/put adaptation. Requires aligned rising/falling EMA 9/21, a pullback to EMA 9, then a closed-bar continuation. Not a proven profitable strategy.	MOMENTUM	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY", "SENSEX"]	["INDEX"]	\N	["INTRADAY"]	["PAPER"]	\N	EVALUATOR	f	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[{"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/ema", "scope": "Indicator mechanics and trend/support interpretation, not evidence of profitable option trading.", "title": "Fidelity: Exponential Moving Average"}, {"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr", "scope": "Volatility measurement and stop construction; not a return forecast.", "title": "Fidelity: Average True Range"}]	["One long-option lot only; no averaging down or multi-leg execution.", "No expiry-day entries. Bid/ask depth, real Greeks and costs are required.", "Premium stop uses a delta-times-ATR approximation, not an option pricing forecast.", "V3 position policy owns exits; local stops can fill worse after gaps."]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "MOMENTUM", "executionModes": ["PAPER"], "researchStatus": "PAPER_HYPOTHESIS", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["RESEARCH_HYPOTHESIS_NOT_VALIDATED", "EVALUATOR_HANDLER_REQUIRED"]	29	1	2026-10-20 06:44:12.072716+00
30	nifty_ema_directional_put_v1	EMA-Based Intraday Directional	Check for bearish trend: Confirms Nifty is turning bearish when the 9 EMA crosses below the 36 EMA, signalling downward momentum. Buy the put: Enters a Nifty ATM put option once the crossover confirms. Manage the risk: Exits when the 9 EMA crosses back above the 36 EMA, or the stop loss hits, or the target is reached, whichever comes first.	MOMENTUM	SINGLE_LONG	BEARISH	PUT	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 30000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 15000}	[]	[]	[{"title": "Check for bearish trend", "description": "Confirms Nifty is turning bearish when the 9 EMA crosses below the 36 EMA, signalling downward momentum."}, {"title": "Buy the put", "description": "Enters a Nifty ATM put option once the crossover confirms."}, {"title": "Manage the risk", "description": "Exits when the 9 EMA crosses back above the 36 EMA, or the stop loss hits, or the target is reached, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 16, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	[]	30	1	2026-10-20 06:44:12.072716+00
31	nifty_short_strangle_v1	Nifty Short Strangle	Open the position: At a fixed time after the open, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Manage the risk: Each sold option has its own stop-loss, and a strategy-level daily stop-loss caps the total loss for the day. Exit before close: All positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 250000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 28376}	[]	[]	[{"title": "Open the position", "description": "At a fixed time after the open, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Manage the risk", "description": "Each sold option has its own stop-loss, and a strategy-level daily stop-loss caps the total loss for the day."}, {"title": "Exit before close", "description": "All positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "algoverse_id": 2, "originalType": "SHORT_STRANGLE", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS", "STRUCTURE_DERIVED_FROM_LEGS:SHORT_STRANGLE->IRON_CONDOR"]	31	1	2026-10-20 06:44:12.072716+00
32	vwap_pullback_v1	VWAP Dynamic Pullback V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	VWAP	\N	\N	\N	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	DEGRADED	\N	\N	\N	UNTESTED	t	{"lotSize": null, "targetRr": 2.0, "maxRiskPct": 18, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "VWAP", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	32	1	2026-10-20 06:44:12.072716+00
33	nifty_bearish_theta_capture_v1	Nifty Bearish Theta Capture	Check for bearish trend: Confirms Nifty is turning bearish when the 9 EMA crosses below the 20 EMA, signalling downward momentum. Place both legs: Sells the ATM option to collect the premium, then buys the OTM 20 option to keep risk defined. Manage the risk: Exits when the 9 EMA crosses back above the 20 EMA, the stop-loss hits, or by the set exit time, whichever comes first.	PREMIUM_SELLING	BEAR_CALL_SPREAD	BEARISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 20000}	[]	[]	[{"title": "Check for bearish trend", "description": "Confirms Nifty is turning bearish when the 9 EMA crosses below the 20 EMA, signalling downward momentum."}, {"title": "Place both legs", "description": "Sells the ATM option to collect the premium, then buys the OTM 20 option to keep risk defined."}, {"title": "Manage the risk", "description": "Exits when the 9 EMA crosses back above the 20 EMA, the stop-loss hits, or by the set exit time, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 15, "originalType": "BEAR_CALL_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	[]	33	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategy_health_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_health_events (id, strategy_id, from_health, to_health, reason, snapshot_id, triggered_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: strategy_performance_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_performance_snapshots (id, strategy_id, version_no, source, domain, period_from, period_to, as_of, total_trades, winning_trades, losing_trades, win_rate_pct, net_pnl, profit_factor, max_drawdown, legacy_health, reliability_flags, status, created_at) FROM stdin;
1	16	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	1	1	0	100.00	1810.60	10.00	0.00	DEGRADED	["LOW_SAMPLE", "PERFECT_RECORD_TINY_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
2	17	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	10	7	3	70.00	3800.00	2.20	450.00	ACTIVE	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
3	18	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	51	35	16	68.63	8529.50	2.00	450.00	ACTIVE	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
4	19	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	14	9	5	64.29	3083.60	0.65	450.00	DEGRADED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
5	20	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	52	33	19	63.46	54839.30	2.42	450.00	ACTIVE	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
6	21	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	86	51	35	59.30	-5710.80	0.76	450.00	SUSPENDED	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
7	22	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	9	5	4	55.56	1695.70	2.10	0.00	ACTIVE	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
8	23	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	19	9	10	47.37	1549.81	4.37	460.04	ACTIVE	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
9	24	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	26	12	14	46.15	-2694.05	0.10	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
10	25	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	48	22	26	45.83	3275.70	0.96	450.00	DEGRADED	["PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
11	26	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	26	11	15	42.31	-940.65	0.08	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
12	27	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	19	8	11	42.11	-1005.05	0.13	450.00	SUSPENDED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
13	28	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	17	7	10	41.18	3531.25	0.00	450.00	SUSPENDED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
14	29	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	10	4	6	40.00	-2689.19	0.15	2689.19	DEGRADED	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
15	30	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	43	17	26	39.53	2049.60	1.05	29997.30	SUSPENDED	[]	1	2026-10-20 06:44:12.072716+00
16	31	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	29	11	18	37.93	-6486.65	0.06	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
17	32	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	137	51	86	37.23	-8562.62	0.87	25809.75	DEGRADED	[]	1	2026-10-20 06:44:12.072716+00
18	33	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	25	9	16	36.00	1038.70	0.54	450.00	SUSPENDED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategy_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_rules (id, strategy_version_id, rule_id, role, required, weight, sort_order, param_overrides, status, created_at) FROM stdin;
\.


--
-- Data for Name: strategy_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_versions (id, strategy_id, version_no, schema_version, definition, content_hash, change_note, status, created_at) FROM stdin;
1	1	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
2	2	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
3	3	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
4	4	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
5	5	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
6	6	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
7	7	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
8	8	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
9	9	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
10	10	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
11	11	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
12	12	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
13	13	1	2	{"cases": [{"key": "0", "bias": "BEARISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	54f0ef8380fa3545b0b6978a7202926fd5f9aac972b8334f963a904a3ef0d8a3	Initial built-in version	1	2026-10-20 06:44:12.072716+00
14	14	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
15	15	1	2	{"cases": [{"key": "0", "bias": "DYNAMIC", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	e717e214d7cd9a55dbb39f9745697a0c91db437055b055adc05a7926750fc5f5	Initial built-in version	1	2026-10-20 06:44:12.072716+00
16	16	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": 1, "lotSize": 100, "exchange": "MCX", "targetRr": 2.2, "entryLabel": "momentum_breakout", "indicators": ["VWAP", "EMA_9", "EMA_21", "ATR_14"], "maxRiskPct": 20}, "schemaVersion": 2}	930c2822c69528a349259b8824276bd2d4a4cb53beeeed3e162da6763601fb44	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
17	17	1	2	{"cases": [{"key": "0", "exit": null, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["3"], "trigger": "ExitedInLoss"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 85}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["4"], "trigger": "ExitedInLoss"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 85}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 10, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -10, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:29:00"}, "operator": "EQUALS"}, {"left": {"field": "daysToExpire", "source": "CONTEXT"}, "right": {"const": 0}, "operator": "EQUALS"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:24:00"}, "operator": "EQUALS"}, "actions": [{"type": "CLOSE_LEG", "legId": "1"}, {"type": "CLOSE_LEG", "legId": "2"}, {"type": "CLOSE_LEG", "legId": "3"}, {"type": "CLOSE_LEG", "legId": "4"}]}, {"key": "A2", "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:25:00"}, "operator": "EQUALS"}, {"left": {"field": "daysToExpire", "source": "CONTEXT"}, "right": {"const": 0}, "operator": "EQUALS"}]}, "actions": [{"side": "SELL", "type": "OPEN_LEG", "legId": "9", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["11"], "trigger": "ExitedInLoss"}]}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 70}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -1, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "type": "OPEN_LEG", "legId": "10", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["12"], "trigger": "ExitedInLoss"}]}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 70}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 1, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "type": "OPEN_LEG", "legId": "11", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 7, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "type": "OPEN_LEG", "legId": "12", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -7, "selector": "ATM_OFFSET"}, "optionType": "PE"}}]}, {"key": "A3", "when": {"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "3"}]}, {"key": "A4", "when": {"left": {"field": "hasExitedInLoss", "legId": "2", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "4"}]}, {"key": "A5", "when": {"left": {"field": "hasExitedInLoss", "legId": "9", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "11"}]}, {"key": "A6", "when": {"left": {"field": "hasExitedInLoss", "legId": "10", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "12"}]}]}], "bounds": {"session": {"exitTime": "15:28", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	330a9b83f7c4cacdbe89bf61161e8ae313b25d5fe5d66cc93dc6551528cf6f75	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
18	18	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 200}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 10, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "MONTHLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "3m"}, "right": {"code": "BBANDS", "output": "lower", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 24}, "operator": "IS_BELOW"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": -150}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:10:00"}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:24:00"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "volume", "source": "PRICE", "timeframe": "3m"}, "right": {"const": 50000}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "dayStopGain": {"type": "AMOUNT", "value": 2000}, "dayStopLoss": {"type": "AMOUNT", "value": 4000}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	cffb311b3d7d24dd6a1ef36caf2309baf9aea6c21df9db47f5cde2dd0124e78f	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
19	19	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -8, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	3891b29c422bb615006e3c1cfb40945fa5337b61a4eb2f332a807153da2738b5	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
20	20	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 5}, "value": 30}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 200, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"day": "YESTERDAY", "field": "high", "source": "DAY"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"day": "TODAY", "field": "previousHighestHigh", "source": "DAY"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1, "strategyStopLoss": {"type": "AMOUNT", "value": 3000}}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	be78f33bac744a7ec2d4294874fcdf542a6a2d83cb07660e79211b290ca60dd1	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
21	21	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "POINTS", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 15, "trailingValue": 15}, "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 200, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:21:00"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 100}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	ac26d58ab6213a92bb80c7cb391b3fe6d1cebfabafaf54fda72d8ae6820eb5f1	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
22	22	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": null, "lotSize": null, "exchange": null, "targetRr": 2.2, "entryLabel": "breakout", "indicators": ["SUPPORT_RESISTANCE", "DAY_HIGH_LOW", "VOLUME"], "maxRiskPct": 20}, "schemaVersion": 2}	e69d4c2339ef5b3a2acd8d668c840928dda3c4e367e466e6adad325821293aac	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
23	23	1	2	{"extras": {"version": 1, "reviewedOn": "2026-09-25", "performanceClaims": null}, "format": "EVALUATOR", "evaluator": "ORB15", "parameters": {"fastEma": 9, "slowEma": 21, "atrPeriod": 14, "rewardRisk": 2.0, "entryCutoff": "14:30", "maxAbsDelta": 0.7, "minAbsDelta": 0.35, "maxSpreadPct": 2.0, "stopAtrMultiple": 1.5, "minCompletedBars": 35, "maxPremiumRiskPct": 20.0, "minPremiumRiskPct": 5.0, "maxQuoteAgeSeconds": 60, "maxFrictionToReward": 0.25, "openingRangeMinutes": 15, "maxCapitalAllocationPct": 20.0}, "riskPolicy": {"stopMode": "EVALUATOR_OWNED"}, "schemaVersion": 2}	466dd0f8b56cdf308fbf03187820ee415ac9d06d9d67236a22a317bbdc4cb858	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
24	24	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "AMOUNT", "basis": "POSITION_TOTAL", "value": 13500}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 240, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "upper", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 141}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:21:00"}, "operator": "IS_ABOVE"}, {"left": {"code": "ADX", "output": "adx", "params": null, "source": "INDICATOR"}, "right": {"const": 33}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "volume", "source": "PRICE", "timeframe": null}, "right": {"const": 100000}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	43f23524f7356a0325daf40d037c5b63c6f64215b040b4e7a073683a4227a0fd	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
25	25	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "middle", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 120}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:19:00"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "CURRENT", "field": "open", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"op": "ALL", "items": [{"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}, "actions": [{"side": "BUY", "type": "OPEN_LEG", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 2}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}]}]}, {"key": "1", "exit": {"when": {"op": "ANY", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_ABOVE"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "middle", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 30}, "operator": "IS_BELOW"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": -120}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "low", "source": "PRICE", "timeframe": null}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:19:00"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "CURRENT", "field": "open", "source": "PRICE", "timeframe": null}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"op": "ALL", "items": [{"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "1"}, "right": {"const": 1}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}, "actions": [{"side": "BUY", "type": "OPEN_LEG", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 2}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}]}]}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "dayStopGain": {"type": "AMOUNT", "value": 1500}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	c7c8e31f0939eb6ed7db42c9c7278cb54e5f25e56d2747ee177ca98265dee583	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
26	26	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 30}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "MONTHLY", "index": 1}, "strike": {"delta": 0.61, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "upper", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 120}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R4", "params": {"variant": "CAMARILLA"}, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	4f1a84668834e6905b425523e21ca44580c6fbab9216007dd18b2c6b71ab59be	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
27	27	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:15:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.4, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}, {"side": "SELL", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.4, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}, {"side": "BUY", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.15, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}, {"side": "BUY", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.15, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "10:00:00"}, "operator": "EQUALS"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	63cf8b66607e8352f2dbe01e942a29c6dfdd3c58b011114b6504edd02e84677c	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
28	28	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_ABOVE"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 8, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	6a4af53107fe1bcafa12e9d7eb624e3d4e41f1c68df8d9b69aa0b92b7a63d946	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
29	29	1	2	{"extras": {"version": 1, "reviewedOn": "2026-09-25", "performanceClaims": null}, "format": "EVALUATOR", "evaluator": "EMA_PULLBACK", "parameters": {"fastEma": 9, "slowEma": 21, "atrPeriod": 14, "rewardRisk": 2.0, "entryCutoff": "14:30", "maxAbsDelta": 0.7, "minAbsDelta": 0.35, "maxSpreadPct": 2.0, "stopAtrMultiple": 1.5, "minCompletedBars": 35, "maxPremiumRiskPct": 20.0, "minPremiumRiskPct": 5.0, "maxQuoteAgeSeconds": 60, "maxFrictionToReward": 0.25, "openingRangeMinutes": 15, "maxCapitalAllocationPct": 20.0}, "riskPolicy": {"stopMode": "EVALUATOR_OWNED"}, "schemaVersion": 2}	0d735fa5b2e9aaa041d9436759933969ff8203d70c22b1050c65b07f12f01017	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
30	30	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 36}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_ABOVE"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 5}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 36}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_BELOW"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "14:15", "entryTime": "09:30"}, "expiryHandling": {}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	d2981fe68ce0014550ef471a9cef2d754a34739aeb94df0424a9c09126144acf	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
31	31	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 20, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -20, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "SELL", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:20:00"}, "operator": "EQUALS"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1, "strategyStopLoss": {"type": "AMOUNT", "value": 3000}}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	08086f5bba390bbf55ab861c107303c5262381d3624174c204d37c2de1260ecc	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
32	32	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": null, "lotSize": null, "exchange": null, "targetRr": 2.0, "entryLabel": "vwap_bounce", "indicators": ["VWAP", "RSI_14", "PRICE_ACTION"], "maxRiskPct": 18}, "schemaVersion": 2}	86628024af1a9afc9fd83341cfa25d52a488d8550cd33e1c7c3e8a241f43961f	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
33	33	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 20}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_ABOVE"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["2"], "trigger": "ExitedInLoss"}, {"action": "CloseLeg", "targets": ["2"], "trigger": "ExitedInProfit"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 15}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 20, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 20}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_BELOW"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "2"}]}, {"key": "A2", "when": {"left": {"field": "hasExitedInProfit", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "2"}]}]}], "bounds": {"session": {"exitTime": "14:15", "entryTime": "09:45"}, "expiryHandling": {}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	d33d5efe4cc2294ed8cbbcba654a2a20ec78cc4c638c8a958b87fdc710b08df0	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: upstox_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.upstox_configs (id, user_id, api_key, api_secret_enc, mobile, pin_enc, totp_secret_enc, access_token_enc, redirect_uri, auto_auth_enabled, token_expires_at, auth_status, last_auth_at, last_error, upstox_user_id, profile_name, email, status, created_at) FROM stdin;
1	1	d9a56b8d-da64-4589-a2a7-d41211a4d642	b+TegRw2uK5Znoluj1UvGt6oV01CDJ3O8lesckxBaRZpSlYS/9k=	8301980013	GrFs+cjqdm1obu/igHxkpRfHfx2j6whMOJAJ18dqXkT0dA==	lQRKK1W6CvhqJxUWrp3kXDimsUlt9+9dYpwJiaqbrtb0P2PK/HkW2wS2ZOjnSj5jUuYgrViEpUlrq1GU	50dAFEfRX1GxEMSn7R9E41viCHDdNjMc68mXg/8+2itvMauG1eAZvXxnIcUqctPdxryNWUfwS0U/mwVVgECrqh39H/nVrRDDeZokfqUfb8ISeOq44+hgiaWonFRqK+ZJPAsX7ACyl9r+hxAk+NpKIECoJ7ZYwtAZMLZRbygmj6r7uFgauZROgAgPjDmrZd0hgJwJAinMBqyBosYQ0bkZNtInXffM6qvzo2Zq1cw0eo71kE+tPJk82Txdk5CPg8AmLGUM4B/sTjCfytSDvmOIoIKKtynLDFza6P9jsUULUwt9uddhVMJV5l/UVFfwLTwBc5OvYn7StcyUYyVb2JVrXgC6ib/ugd8Nv6HPwqcNTErh/w8RFdkx4M0mCh/qsvxuTk1PcLFj3uXgjj+lF4P5cDpZDbnIzV4RQgQjdAg3fE+Z3st9LbhTyycU5uWUC/dwTUiG	http://localhost/api/v1/upstox/callback/1	t	2026-10-20 12:39:19.582642+00	VALID	2026-10-19 12:39:19.582642+00	\N	JW9356	ALEN XAVIER	alenxavier36@gmail.com	1	2026-10-19 11:56:23.757117+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, is_default, status, created_at) FROM stdin;
1	Alen Xavier	t	1	2026-10-19 11:56:23.757117+00
\.


--
-- Name: health_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.health_policies_id_seq', 1, true);


--
-- Name: import_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.import_batches_id_seq', 1, false);


--
-- Name: master_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_configs_id_seq', 1, false);


--
-- Name: master_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_conversations_id_seq', 53, true);


--
-- Name: master_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_messages_id_seq', 58, true);


--
-- Name: master_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_preferences_id_seq', 1, false);


--
-- Name: master_proposals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_proposals_id_seq', 2, true);


--
-- Name: master_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_runs_id_seq', 46, true);


--
-- Name: master_tool_calls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_tool_calls_id_seq', 11, true);


--
-- Name: master_tool_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_tool_policies_id_seq', 14, true);


--
-- Name: master_tool_servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.master_tool_servers_id_seq', 2, true);


--
-- Name: registry_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.registry_items_id_seq', 54, true);


--
-- Name: research_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_candidates_id_seq', 12, true);


--
-- Name: research_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_chunks_id_seq', 1, false);


--
-- Name: research_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_claims_id_seq', 1, false);


--
-- Name: research_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_config_id_seq', 1, true);


--
-- Name: research_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_documents_id_seq', 1, false);


--
-- Name: research_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_queries_id_seq', 39, true);


--
-- Name: research_risk_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_risk_terms_id_seq', 20, true);


--
-- Name: research_run_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_run_documents_id_seq', 1, false);


--
-- Name: research_run_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_run_events_id_seq', 10, true);


--
-- Name: research_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_runs_id_seq', 6, true);


--
-- Name: research_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_sources_id_seq', 12, true);


--
-- Name: research_underlyings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_underlyings_id_seq', 12, true);


--
-- Name: rule_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rule_versions_id_seq', 3, true);


--
-- Name: rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rules_id_seq', 3, true);


--
-- Name: strategies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategies_id_seq', 33, true);


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_health_events_id_seq', 1, false);


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_performance_snapshots_id_seq', 18, true);


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_rules_id_seq', 1, false);


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_versions_id_seq', 33, true);


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.upstox_configs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: health_policies health_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_policies
    ADD CONSTRAINT health_policies_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: master_configs master_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_configs
    ADD CONSTRAINT master_configs_pkey PRIMARY KEY (id);


--
-- Name: master_conversations master_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_conversations
    ADD CONSTRAINT master_conversations_pkey PRIMARY KEY (id);


--
-- Name: master_messages master_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_messages
    ADD CONSTRAINT master_messages_pkey PRIMARY KEY (id);


--
-- Name: master_preferences master_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_preferences
    ADD CONSTRAINT master_preferences_pkey PRIMARY KEY (id);


--
-- Name: master_proposals master_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_proposals
    ADD CONSTRAINT master_proposals_pkey PRIMARY KEY (id);


--
-- Name: master_runs master_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_runs
    ADD CONSTRAINT master_runs_pkey PRIMARY KEY (id);


--
-- Name: master_tool_calls master_tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_calls
    ADD CONSTRAINT master_tool_calls_pkey PRIMARY KEY (id);


--
-- Name: master_tool_policies master_tool_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_policies
    ADD CONSTRAINT master_tool_policies_pkey PRIMARY KEY (id);


--
-- Name: master_tool_servers master_tool_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_servers
    ADD CONSTRAINT master_tool_servers_pkey PRIMARY KEY (id);


--
-- Name: registry_items registry_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registry_items
    ADD CONSTRAINT registry_items_pkey PRIMARY KEY (id);


--
-- Name: research_candidates research_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_candidates
    ADD CONSTRAINT research_candidates_pkey PRIMARY KEY (id);


--
-- Name: research_chunks research_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_chunks
    ADD CONSTRAINT research_chunks_pkey PRIMARY KEY (id);


--
-- Name: research_claims research_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_claims
    ADD CONSTRAINT research_claims_pkey PRIMARY KEY (id);


--
-- Name: research_config research_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_config
    ADD CONSTRAINT research_config_pkey PRIMARY KEY (id);


--
-- Name: research_documents research_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_documents
    ADD CONSTRAINT research_documents_pkey PRIMARY KEY (id);


--
-- Name: research_queries research_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_queries
    ADD CONSTRAINT research_queries_pkey PRIMARY KEY (id);


--
-- Name: research_risk_terms research_risk_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_risk_terms
    ADD CONSTRAINT research_risk_terms_pkey PRIMARY KEY (id);


--
-- Name: research_run_documents research_run_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_documents
    ADD CONSTRAINT research_run_documents_pkey PRIMARY KEY (id);


--
-- Name: research_run_events research_run_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_events
    ADD CONSTRAINT research_run_events_pkey PRIMARY KEY (id);


--
-- Name: research_runs research_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_runs
    ADD CONSTRAINT research_runs_pkey PRIMARY KEY (id);


--
-- Name: research_sources research_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_sources
    ADD CONSTRAINT research_sources_pkey PRIMARY KEY (id);


--
-- Name: research_underlyings research_underlyings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_underlyings
    ADD CONSTRAINT research_underlyings_pkey PRIMARY KEY (id);


--
-- Name: rule_versions rule_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: strategies strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT strategies_pkey PRIMARY KEY (id);


--
-- Name: strategy_health_events strategy_health_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events
    ADD CONSTRAINT strategy_health_events_pkey PRIMARY KEY (id);


--
-- Name: strategy_performance_snapshots strategy_performance_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots
    ADD CONSTRAINT strategy_performance_snapshots_pkey PRIMARY KEY (id);


--
-- Name: strategy_rules strategy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules
    ADD CONSTRAINT strategy_rules_pkey PRIMARY KEY (id);


--
-- Name: strategy_versions strategy_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions
    ADD CONSTRAINT strategy_versions_pkey PRIMARY KEY (id);


--
-- Name: upstox_configs upstox_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_master_configs_key_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_master_configs_key_active ON public.master_configs USING btree (config_key) WHERE (status = 1);


--
-- Name: idx_master_conversations_last_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_conversations_last_msg ON public.master_conversations USING btree (last_message_at);


--
-- Name: idx_master_conversations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_conversations_status ON public.master_conversations USING btree (status);


--
-- Name: idx_master_messages_conv_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_messages_conv_seq ON public.master_messages USING btree (conversation_id, seq);


--
-- Name: idx_master_preferences_key_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_master_preferences_key_active ON public.master_preferences USING btree (key) WHERE (status = 1);


--
-- Name: idx_master_proposals_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_proposals_conversation_id ON public.master_proposals USING btree (conversation_id);


--
-- Name: idx_master_proposals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_proposals_status ON public.master_proposals USING btree (proposal_status);


--
-- Name: idx_master_runs_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_runs_conversation_id ON public.master_runs USING btree (conversation_id);


--
-- Name: idx_master_runs_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_runs_state ON public.master_runs USING btree (state);


--
-- Name: idx_master_tool_calls_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_tool_calls_run_id ON public.master_tool_calls USING btree (run_id);


--
-- Name: idx_master_tool_calls_tool_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_master_tool_calls_tool_name ON public.master_tool_calls USING btree (tool_name);


--
-- Name: idx_master_tool_policies_server_tool_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_master_tool_policies_server_tool_active ON public.master_tool_policies USING btree (server_name, tool_name) WHERE (status = 1);


--
-- Name: idx_master_tool_servers_name_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_master_tool_servers_name_active ON public.master_tool_servers USING btree (name) WHERE (status = 1);


--
-- Name: idx_research_candidates_brief_embedding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_candidates_brief_embedding ON public.research_candidates USING hnsw (brief_embedding public.vector_cosine_ops);


--
-- Name: idx_research_candidates_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_candidates_code ON public.research_candidates USING btree (underlying_code);


--
-- Name: idx_research_candidates_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_candidates_run_id ON public.research_candidates USING btree (run_id, underlying_type);


--
-- Name: idx_research_chunks_doc_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_chunks_doc_id ON public.research_chunks USING btree (document_id);


--
-- Name: idx_research_chunks_embedding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_chunks_embedding ON public.research_chunks USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: idx_research_claims_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_claims_code ON public.research_claims USING btree (underlying_code, stance);


--
-- Name: idx_research_claims_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_claims_doc ON public.research_claims USING btree (document_id);


--
-- Name: idx_research_claims_embedding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_claims_embedding ON public.research_claims USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: idx_research_config_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_config_version ON public.research_config USING btree (version);


--
-- Name: idx_research_documents_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_documents_domain ON public.research_documents USING btree (domain);


--
-- Name: idx_research_documents_published_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_documents_published_at ON public.research_documents USING btree (published_at);


--
-- Name: idx_research_queries_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_queries_run_id ON public.research_queries USING btree (run_id);


--
-- Name: idx_research_risk_terms_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_risk_terms_status ON public.research_risk_terms USING btree (status);


--
-- Name: idx_research_run_docs_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_run_docs_run_id ON public.research_run_documents USING btree (run_id, underlying_code);


--
-- Name: idx_research_run_events_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_run_events_run_id ON public.research_run_events USING btree (run_id, seq);


--
-- Name: idx_research_runs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_runs_created_at ON public.research_runs USING btree (created_at);


--
-- Name: idx_research_runs_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_runs_state ON public.research_runs USING btree (state);


--
-- Name: idx_research_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_runs_status ON public.research_runs USING btree (status);


--
-- Name: idx_research_sources_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_sources_status ON public.research_sources USING btree (status);


--
-- Name: idx_research_sources_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_sources_type ON public.research_sources USING btree (source_type);


--
-- Name: idx_research_underlyings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_underlyings_status ON public.research_underlyings USING btree (status);


--
-- Name: idx_research_underlyings_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_underlyings_type ON public.research_underlyings USING btree (underlying_type);


--
-- Name: ix_health_policies_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_health_policies_code_active ON public.health_policies USING btree (code) WHERE (status = 1);


--
-- Name: ix_registry_items_type_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registry_items_type_code_active ON public.registry_items USING btree (registry_type, code) WHERE (status = 1);


--
-- Name: ix_rule_versions_rule_ver_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rule_versions_rule_ver_active ON public.rule_versions USING btree (rule_id, version_no) WHERE (status = 1);


--
-- Name: ix_rules_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rules_code_active ON public.rules USING btree (code) WHERE (status = 1);


--
-- Name: ix_strategies_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategies_code_active ON public.strategies USING btree (code) WHERE (status = 1);


--
-- Name: ix_strategy_versions_strat_ver_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategy_versions_strat_ver_active ON public.strategy_versions USING btree (strategy_id, version_no) WHERE (status = 1);


--
-- Name: ix_upstox_configs_user_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_upstox_configs_user_id_active ON public.upstox_configs USING btree (user_id) WHERE (status = 1);


--
-- Name: ix_users_name_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_name_active ON public.users USING btree (name) WHERE (status = 1);


--
-- Name: uq_research_documents_url_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_research_documents_url_hash ON public.research_documents USING btree (url_hash) WHERE (status = 1);


--
-- Name: uq_research_risk_terms_term; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_research_risk_terms_term ON public.research_risk_terms USING btree (term) WHERE (status = 1);


--
-- Name: uq_research_underlyings_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_research_underlyings_code ON public.research_underlyings USING btree (code) WHERE (status = 1);


--
-- Name: master_messages master_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_messages
    ADD CONSTRAINT master_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.master_conversations(id) ON DELETE CASCADE;


--
-- Name: master_messages master_messages_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_messages
    ADD CONSTRAINT master_messages_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.master_runs(id) ON DELETE SET NULL;


--
-- Name: master_proposals master_proposals_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_proposals
    ADD CONSTRAINT master_proposals_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.master_conversations(id) ON DELETE CASCADE;


--
-- Name: master_proposals master_proposals_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_proposals
    ADD CONSTRAINT master_proposals_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.master_messages(id) ON DELETE SET NULL;


--
-- Name: master_runs master_runs_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_runs
    ADD CONSTRAINT master_runs_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.master_conversations(id) ON DELETE CASCADE;


--
-- Name: master_tool_calls master_tool_calls_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_tool_calls
    ADD CONSTRAINT master_tool_calls_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.master_runs(id) ON DELETE CASCADE;


--
-- Name: research_candidates research_candidates_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_candidates
    ADD CONSTRAINT research_candidates_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.research_runs(id) ON DELETE CASCADE;


--
-- Name: research_chunks research_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_chunks
    ADD CONSTRAINT research_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.research_documents(id) ON DELETE CASCADE;


--
-- Name: research_claims research_claims_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_claims
    ADD CONSTRAINT research_claims_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.research_documents(id) ON DELETE CASCADE;


--
-- Name: research_queries research_queries_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_queries
    ADD CONSTRAINT research_queries_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.research_runs(id) ON DELETE CASCADE;


--
-- Name: research_run_documents research_run_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_documents
    ADD CONSTRAINT research_run_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.research_documents(id) ON DELETE CASCADE;


--
-- Name: research_run_documents research_run_documents_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_documents
    ADD CONSTRAINT research_run_documents_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.research_runs(id) ON DELETE CASCADE;


--
-- Name: research_run_events research_run_events_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_run_events
    ADD CONSTRAINT research_run_events_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.research_runs(id) ON DELETE CASCADE;


--
-- Name: rule_versions rule_versions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rules(id) ON DELETE CASCADE;


--
-- Name: strategy_health_events strategy_health_events_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events
    ADD CONSTRAINT strategy_health_events_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_performance_snapshots strategy_performance_snapshots_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots
    ADD CONSTRAINT strategy_performance_snapshots_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_rules strategy_rules_strategy_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules
    ADD CONSTRAINT strategy_rules_strategy_version_id_fkey FOREIGN KEY (strategy_version_id) REFERENCES public.strategy_versions(id) ON DELETE CASCADE;


--
-- Name: strategy_versions strategy_versions_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions
    ADD CONSTRAINT strategy_versions_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: upstox_configs upstox_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DaWsDv7yuQSzNQ5cjozsvH1epF3AwO0nxxK4JogjTf9gFoMhAAkHF3pjvqyLyVj

