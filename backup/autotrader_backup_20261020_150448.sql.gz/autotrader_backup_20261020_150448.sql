--
-- PostgreSQL database dump
--

\restrict 2umJqLa0SAmFd8vJEmwlvNNlccwO4VC2GMdZzsRnV6incdjEUzTgJLmPLWY920r

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg12+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_versions DROP CONSTRAINT IF EXISTS strategy_versions_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_rules DROP CONSTRAINT IF EXISTS strategy_rules_strategy_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_performance_snapshots DROP CONSTRAINT IF EXISTS strategy_performance_snapshots_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_health_events DROP CONSTRAINT IF EXISTS strategy_health_events_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rule_versions DROP CONSTRAINT IF EXISTS rule_versions_rule_id_fkey;
DROP INDEX IF EXISTS public.ix_users_name_active;
DROP INDEX IF EXISTS public.ix_upstox_configs_user_id_active;
DROP INDEX IF EXISTS public.ix_strategy_versions_strat_ver_active;
DROP INDEX IF EXISTS public.ix_strategies_code_active;
DROP INDEX IF EXISTS public.ix_rules_code_active;
DROP INDEX IF EXISTS public.ix_rule_versions_rule_ver_active;
DROP INDEX IF EXISTS public.ix_registry_items_type_code_active;
DROP INDEX IF EXISTS public.ix_health_policies_code_active;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_versions DROP CONSTRAINT IF EXISTS strategy_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_rules DROP CONSTRAINT IF EXISTS strategy_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_performance_snapshots DROP CONSTRAINT IF EXISTS strategy_performance_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_health_events DROP CONSTRAINT IF EXISTS strategy_health_events_pkey;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS strategies_pkey;
ALTER TABLE IF EXISTS ONLY public.rules DROP CONSTRAINT IF EXISTS rules_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_versions DROP CONSTRAINT IF EXISTS rule_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.registry_items DROP CONSTRAINT IF EXISTS registry_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.health_policies DROP CONSTRAINT IF EXISTS health_policies_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.upstox_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_performance_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_health_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.registry_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.import_batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.health_policies ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.upstox_configs_id_seq;
DROP TABLE IF EXISTS public.upstox_configs;
DROP SEQUENCE IF EXISTS public.strategy_versions_id_seq;
DROP TABLE IF EXISTS public.strategy_versions;
DROP SEQUENCE IF EXISTS public.strategy_rules_id_seq;
DROP TABLE IF EXISTS public.strategy_rules;
DROP SEQUENCE IF EXISTS public.strategy_performance_snapshots_id_seq;
DROP TABLE IF EXISTS public.strategy_performance_snapshots;
DROP SEQUENCE IF EXISTS public.strategy_health_events_id_seq;
DROP TABLE IF EXISTS public.strategy_health_events;
DROP SEQUENCE IF EXISTS public.strategies_id_seq;
DROP TABLE IF EXISTS public.strategies;
DROP SEQUENCE IF EXISTS public.rules_id_seq;
DROP TABLE IF EXISTS public.rules;
DROP SEQUENCE IF EXISTS public.rule_versions_id_seq;
DROP TABLE IF EXISTS public.rule_versions;
DROP SEQUENCE IF EXISTS public.registry_items_id_seq;
DROP TABLE IF EXISTS public.registry_items;
DROP SEQUENCE IF EXISTS public.import_batches_id_seq;
DROP TABLE IF EXISTS public.import_batches;
DROP SEQUENCE IF EXISTS public.health_policies_id_seq;
DROP TABLE IF EXISTS public.health_policies;
DROP TABLE IF EXISTS public.alembic_version;
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: health_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_policies (
    id bigint NOT NULL,
    code character varying(60) NOT NULL,
    name character varying(120) NOT NULL,
    scope jsonb DEFAULT '"ALL"'::jsonb NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.health_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: health_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.health_policies_id_seq OWNED BY public.health_policies.id;


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id bigint NOT NULL,
    file_name character varying(255) NOT NULL,
    source_format character varying(20) NOT NULL,
    mode character varying(10) DEFAULT 'SKIP'::character varying NOT NULL,
    dry_run boolean DEFAULT false NOT NULL,
    total_items integer DEFAULT 0 NOT NULL,
    created_count integer DEFAULT 0 NOT NULL,
    updated_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    errors jsonb,
    warnings jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.import_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.import_batches_id_seq OWNED BY public.import_batches.id;


--
-- Name: registry_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registry_items (
    id bigint NOT NULL,
    registry_type character varying(30) NOT NULL,
    code character varying(60) NOT NULL,
    name character varying(120) NOT NULL,
    kind character varying(10) DEFAULT 'BUILT_IN'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    schema jsonb,
    expression jsonb,
    handler_key character varying(80),
    executable boolean DEFAULT false NOT NULL,
    requires jsonb,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registry_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.registry_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registry_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.registry_items_id_seq OWNED BY public.registry_items.id;


--
-- Name: rule_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_versions (
    id bigint NOT NULL,
    rule_id bigint NOT NULL,
    version_no integer NOT NULL,
    content jsonb NOT NULL,
    change_note character varying(300),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rule_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rule_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rule_versions_id_seq OWNED BY public.rule_versions.id;


--
-- Name: rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rules (
    id bigint NOT NULL,
    code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    rule_kind character varying(15) NOT NULL,
    rule_type character varying(25) NOT NULL,
    action character varying(10),
    priority character varying(8) DEFAULT 'MEDIUM'::character varying NOT NULL,
    applies_to jsonb DEFAULT '{}'::jsonb NOT NULL,
    condition_text text NOT NULL,
    current_version_id bigint,
    evidence jsonb,
    review_by date,
    executable boolean DEFAULT false NOT NULL,
    review_flags jsonb,
    provenance jsonb,
    enabled boolean DEFAULT true NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rules_id_seq OWNED BY public.rules.id;


--
-- Name: strategies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategies (
    id bigint NOT NULL,
    code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    category character varying(20) NOT NULL,
    structure character varying(30),
    bias character varying(10),
    option_side character varying(5),
    markets jsonb DEFAULT '[]'::jsonb NOT NULL,
    underlying_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    exchange character varying(10),
    trading_modes jsonb DEFAULT '[]'::jsonb NOT NULL,
    execution_modes jsonb DEFAULT '[]'::jsonb NOT NULL,
    timeframe character varying(10),
    definition_format character varying(10) DEFAULT 'RULE_TREE'::character varying NOT NULL,
    executable boolean DEFAULT false NOT NULL,
    lifecycle_status character varying(12) DEFAULT 'DRAFT'::character varying NOT NULL,
    health character varying(10) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    health_override character varying(10),
    health_override_reason character varying(255),
    health_override_until timestamp with time zone,
    validation_status character varying(15) DEFAULT 'UNTESTED'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    risk_profile jsonb,
    "references" jsonb,
    risk_notes jsonb,
    how_it_works jsonb,
    tags jsonb,
    attributes jsonb,
    provenance jsonb,
    review_flags jsonb,
    current_version_id bigint,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategies_id_seq OWNED BY public.strategies.id;


--
-- Name: strategy_health_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_health_events (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    from_health character varying(10) NOT NULL,
    to_health character varying(10) NOT NULL,
    reason character varying(255) NOT NULL,
    snapshot_id bigint,
    triggered_by character varying(10) DEFAULT 'POLICY'::character varying NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_health_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_health_events_id_seq OWNED BY public.strategy_health_events.id;


--
-- Name: strategy_performance_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_performance_snapshots (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    version_no integer,
    source character varying(15) NOT NULL,
    domain character varying(10) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    period_from date,
    period_to date,
    as_of timestamp with time zone,
    total_trades integer DEFAULT 0 NOT NULL,
    winning_trades integer DEFAULT 0 NOT NULL,
    losing_trades integer DEFAULT 0 NOT NULL,
    win_rate_pct numeric(6,2) DEFAULT '0'::numeric NOT NULL,
    net_pnl numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    profit_factor numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    max_drawdown numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    legacy_health character varying(10),
    reliability_flags jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_performance_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_performance_snapshots_id_seq OWNED BY public.strategy_performance_snapshots.id;


--
-- Name: strategy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_rules (
    id bigint NOT NULL,
    strategy_version_id bigint NOT NULL,
    rule_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    required boolean DEFAULT true NOT NULL,
    weight integer DEFAULT 1 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    param_overrides jsonb,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_rules_id_seq OWNED BY public.strategy_rules.id;


--
-- Name: strategy_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_versions (
    id bigint NOT NULL,
    strategy_id bigint NOT NULL,
    version_no integer NOT NULL,
    schema_version integer DEFAULT 2 NOT NULL,
    definition jsonb NOT NULL,
    content_hash character varying(64) NOT NULL,
    change_note character varying(300),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_versions_id_seq OWNED BY public.strategy_versions.id;


--
-- Name: upstox_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upstox_configs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    api_key character varying(100) DEFAULT ''::character varying NOT NULL,
    api_secret_enc text DEFAULT ''::text NOT NULL,
    mobile character varying(15) DEFAULT ''::character varying NOT NULL,
    pin_enc text DEFAULT ''::text NOT NULL,
    totp_secret_enc text DEFAULT ''::text NOT NULL,
    access_token_enc text,
    redirect_uri character varying(300) DEFAULT ''::character varying NOT NULL,
    auto_auth_enabled boolean DEFAULT true NOT NULL,
    token_expires_at timestamp with time zone,
    auth_status character varying(20) DEFAULT 'NEVER'::character varying NOT NULL,
    last_auth_at timestamp with time zone,
    last_error character varying(500),
    upstox_user_id character varying(50),
    profile_name character varying(100),
    email character varying(150),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.upstox_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.upstox_configs_id_seq OWNED BY public.upstox_configs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: health_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_policies ALTER COLUMN id SET DEFAULT nextval('public.health_policies_id_seq'::regclass);


--
-- Name: import_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches ALTER COLUMN id SET DEFAULT nextval('public.import_batches_id_seq'::regclass);


--
-- Name: registry_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registry_items ALTER COLUMN id SET DEFAULT nextval('public.registry_items_id_seq'::regclass);


--
-- Name: rule_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions ALTER COLUMN id SET DEFAULT nextval('public.rule_versions_id_seq'::regclass);


--
-- Name: rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules ALTER COLUMN id SET DEFAULT nextval('public.rules_id_seq'::regclass);


--
-- Name: strategies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies ALTER COLUMN id SET DEFAULT nextval('public.strategies_id_seq'::regclass);


--
-- Name: strategy_health_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events ALTER COLUMN id SET DEFAULT nextval('public.strategy_health_events_id_seq'::regclass);


--
-- Name: strategy_performance_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots ALTER COLUMN id SET DEFAULT nextval('public.strategy_performance_snapshots_id_seq'::regclass);


--
-- Name: strategy_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules ALTER COLUMN id SET DEFAULT nextval('public.strategy_rules_id_seq'::regclass);


--
-- Name: strategy_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions ALTER COLUMN id SET DEFAULT nextval('public.strategy_versions_id_seq'::regclass);


--
-- Name: upstox_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs ALTER COLUMN id SET DEFAULT nextval('public.upstox_configs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0002_create_strategies_and_rules
\.


--
-- Data for Name: health_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_policies (id, code, name, scope, params, enabled, status, created_at) FROM stdin;
1	DEFAULT	Default Health Policy	"ALL"	{"window": 30, "minTrades": 30, "suspendIfDrawdownAbove": 50000, "degradeIfProfitFactorBelow": 1.0, "suspendIfProfitFactorBelow": 0.8, "suspendAfterConsecutiveLosses": 5}	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, file_name, source_format, mode, dry_run, total_items, created_count, updated_count, skipped_count, failed_count, errors, warnings, status, created_at) FROM stdin;
\.


--
-- Data for Name: registry_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registry_items (id, registry_type, code, name, kind, version, schema, expression, handler_key, executable, requires, description, enabled, status, created_at) FROM stdin;
1	OPERATOR	IS_ABOVE	Is Above (>)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Above (>)	t	1	2026-10-20 06:44:12.072716+00
2	OPERATOR	IS_ABOVE_OR_EQUAL	Is Above or Equal (>=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Above or Equal (>=)	t	1	2026-10-20 06:44:12.072716+00
3	OPERATOR	IS_BELOW	Is Below (<)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Below (<)	t	1	2026-10-20 06:44:12.072716+00
4	OPERATOR	IS_BELOW_OR_EQUAL	Is Below or Equal (<=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Is Below or Equal (<=)	t	1	2026-10-20 06:44:12.072716+00
5	OPERATOR	EQUALS	Equals (==)	BUILT_IN	1	null	\N	operator_handler	t	\N	Equals (==)	t	1	2026-10-20 06:44:12.072716+00
6	OPERATOR	NOT_EQUALS	Not Equals (!=)	BUILT_IN	1	null	\N	operator_handler	t	\N	Not Equals (!=)	t	1	2026-10-20 06:44:12.072716+00
7	OPERATOR	BETWEEN	Between	BUILT_IN	1	null	\N	operator_handler	t	\N	Between	t	1	2026-10-20 06:44:12.072716+00
8	OPERATOR	IN	In List	BUILT_IN	1	null	\N	operator_handler	t	\N	In List	t	1	2026-10-20 06:44:12.072716+00
9	OPERATOR	NOT_IN	Not In List	BUILT_IN	1	null	\N	operator_handler	t	\N	Not In List	t	1	2026-10-20 06:44:12.072716+00
10	OPERATOR	CROSSES_ABOVE	Crosses Above	BUILT_IN	1	null	\N	operator_handler	t	\N	Crosses Above	t	1	2026-10-20 06:44:12.072716+00
11	OPERATOR	CROSSES_BELOW	Crosses Below	BUILT_IN	1	null	\N	operator_handler	t	\N	Crosses Below	t	1	2026-10-20 06:44:12.072716+00
12	OPERAND_SOURCE	PRICE	Bar Price (OHLCV)	BUILT_IN	1	null	\N	price_handler	t	\N	Bar Price (OHLCV)	t	1	2026-10-20 06:44:12.072716+00
13	OPERAND_SOURCE	DAY	Daily Level (PDH/PDL)	BUILT_IN	1	null	\N	day_handler	t	\N	Daily Level (PDH/PDL)	t	1	2026-10-20 06:44:12.072716+00
14	OPERAND_SOURCE	INDICATOR	Technical Indicator	BUILT_IN	1	null	\N	indicator_handler	t	\N	Technical Indicator	t	1	2026-10-20 06:44:12.072716+00
15	OPERAND_SOURCE	TIME	Time of Day	BUILT_IN	1	null	\N	time_handler	t	\N	Time of Day	t	1	2026-10-20 06:44:12.072716+00
16	OPERAND_SOURCE	CONTEXT	Market Context	BUILT_IN	1	null	\N	context_handler	t	\N	Market Context	t	1	2026-10-20 06:44:12.072716+00
17	OPERAND_SOURCE	POSITION	Live Position State	BUILT_IN	1	null	\N	position_handler	t	\N	Live Position State	t	1	2026-10-20 06:44:12.072716+00
18	OPERAND_SOURCE	TRADE_PLAN	Trade Plan / Cost	BUILT_IN	1	null	\N	plan_handler	t	\N	Trade Plan / Cost	t	1	2026-10-20 06:44:12.072716+00
19	OPERAND_SOURCE	CONSTANT	Literal Constant	BUILT_IN	1	null	\N	const_handler	t	\N	Literal Constant	t	1	2026-10-20 06:44:12.072716+00
20	OPERAND_SOURCE	PARAM	Strategy Parameter	BUILT_IN	1	null	\N	param_handler	t	\N	Strategy Parameter	t	1	2026-10-20 06:44:12.072716+00
21	STRIKE_SELECTOR	ATM_OFFSET	ATM Strike Offset	BUILT_IN	1	null	\N	strike_atm	t	\N	ATM Strike Offset	t	1	2026-10-20 06:44:12.072716+00
22	STRIKE_SELECTOR	DELTA	Nearest Delta	BUILT_IN	1	null	\N	strike_delta	t	\N	Nearest Delta	t	1	2026-10-20 06:44:12.072716+00
23	STRIKE_SELECTOR	PREMIUM	Nearest Premium	BUILT_IN	1	null	\N	strike_premium	t	\N	Nearest Premium	t	1	2026-10-20 06:44:12.072716+00
24	STOP_TYPE	PERCENT	Percentage Stop	BUILT_IN	1	null	\N	stop_pct	t	\N	Percentage Stop	t	1	2026-10-20 06:44:12.072716+00
25	STOP_TYPE	AMOUNT	Total INR Amount	BUILT_IN	1	null	\N	stop_amt	t	\N	Total INR Amount	t	1	2026-10-20 06:44:12.072716+00
26	STOP_TYPE	POINTS	Absolute Index Points	BUILT_IN	1	null	\N	stop_pts	t	\N	Absolute Index Points	t	1	2026-10-20 06:44:12.072716+00
27	TARGET_TYPE	PERCENT	Percentage Target	BUILT_IN	1	null	\N	target_pct	t	\N	Percentage Target	t	1	2026-10-20 06:44:12.072716+00
28	TARGET_TYPE	AMOUNT	Total INR Target	BUILT_IN	1	null	\N	target_amt	t	\N	Total INR Target	t	1	2026-10-20 06:44:12.072716+00
29	TARGET_TYPE	POINTS	Absolute Index Target	BUILT_IN	1	null	\N	target_pts	t	\N	Absolute Index Target	t	1	2026-10-20 06:44:12.072716+00
30	TRAIL_TYPE	LINEAR	Linear Trailing Stop	BUILT_IN	1	null	\N	trail_linear	t	\N	Linear Trailing Stop	t	1	2026-10-20 06:44:12.072716+00
31	EXPIRY_CYCLE	WEEKLY	Weekly Expiry	BUILT_IN	1	null	\N	expiry_weekly	t	\N	Weekly Expiry	t	1	2026-10-20 06:44:12.072716+00
32	EXPIRY_CYCLE	MONTHLY	Monthly Expiry	BUILT_IN	1	null	\N	expiry_monthly	t	\N	Monthly Expiry	t	1	2026-10-20 06:44:12.072716+00
33	LEG_ACTION	OPEN_LEG	Open Leg	BUILT_IN	1	null	\N	action_open	t	\N	Open Leg	t	1	2026-10-20 06:44:12.072716+00
34	LEG_ACTION	CLOSE_LEG	Close Leg	BUILT_IN	1	null	\N	action_close	t	\N	Close Leg	t	1	2026-10-20 06:44:12.072716+00
35	STRUCTURE	SINGLE_LONG	Single Leg Long Option	BUILT_IN	1	null	\N	struct_long	t	\N	Single Leg Long Option	t	1	2026-10-20 06:44:12.072716+00
36	STRUCTURE	BULL_PUT_SPREAD	Bull Put Credit Spread	BUILT_IN	1	null	\N	struct_spread	t	\N	Bull Put Credit Spread	t	1	2026-10-20 06:44:12.072716+00
37	STRUCTURE	BEAR_CALL_SPREAD	Bear Call Credit Spread	BUILT_IN	1	null	\N	struct_spread	t	\N	Bear Call Credit Spread	t	1	2026-10-20 06:44:12.072716+00
38	STRUCTURE	IRON_CONDOR	Iron Condor	BUILT_IN	1	null	\N	struct_condor	t	\N	Iron Condor	t	1	2026-10-20 06:44:12.072716+00
39	STRUCTURE	SHORT_STRANGLE	Short Strangle	BUILT_IN	1	null	\N	struct_strangle	t	\N	Short Strangle	t	1	2026-10-20 06:44:12.072716+00
40	STRUCTURE	CUSTOM_MULTI_LEG	Custom Multi-Leg Option	BUILT_IN	1	null	\N	struct_multi	t	\N	Custom Multi-Leg Option	t	1	2026-10-20 06:44:12.072716+00
41	STRUCTURE	MIXED	Mixed Strategy Structure	BUILT_IN	1	null	\N	struct_mixed	t	\N	Mixed Strategy Structure	t	1	2026-10-20 06:44:12.072716+00
42	EVALUATOR	ORB15	15-Minute Opening Range Breakout Evaluator	BUILT_IN	1	null	\N	\N	f	\N	15-Minute Opening Range Breakout Evaluator	t	1	2026-10-20 06:44:12.072716+00
43	EVALUATOR	EMA_PULLBACK	EMA Trend Pullback Evaluator	BUILT_IN	1	null	\N	\N	f	\N	EMA Trend Pullback Evaluator	t	1	2026-10-20 06:44:12.072716+00
44	INDICATOR	EMA	Exponential Moving Average	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 9}}}	\N	ind_ema	t	\N	Exponential Moving Average	t	1	2026-10-20 06:44:12.072716+00
45	INDICATOR	SMA	Simple Moving Average	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}}}	\N	ind_sma	t	\N	Simple Moving Average	t	1	2026-10-20 06:44:12.072716+00
46	INDICATOR	RSI	Relative Strength Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_rsi	t	\N	Relative Strength Index	t	1	2026-10-20 06:44:12.072716+00
47	INDICATOR	CCI	Commodity Channel Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}}}	\N	ind_cci	t	\N	Commodity Channel Index	t	1	2026-10-20 06:44:12.072716+00
48	INDICATOR	ADX	Average Directional Index	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_adx	t	\N	Average Directional Index	t	1	2026-10-20 06:44:12.072716+00
49	INDICATOR	ATR	Average True Range	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 14}}}	\N	ind_atr	t	\N	Average True Range	t	1	2026-10-20 06:44:12.072716+00
50	INDICATOR	SUPERTREND	Supertrend	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 10}, "multiplier": {"type": "float", "default": 3.0}}}	\N	ind_supertrend	t	\N	Supertrend	t	1	2026-10-20 06:44:12.072716+00
51	INDICATOR	BBANDS	Bollinger Bands	BUILT_IN	1	{"params": {"period": {"type": "int", "default": 20}, "stdDev": {"type": "float", "default": 2.0}}}	\N	ind_bbands	t	\N	Bollinger Bands	t	1	2026-10-20 06:44:12.072716+00
52	INDICATOR	VWAP	Volume Weighted Average Price	BUILT_IN	1	null	\N	ind_vwap	t	\N	Volume Weighted Average Price	t	1	2026-10-20 06:44:12.072716+00
53	INDICATOR	PIVOT_POINTS	Pivot Points (Standard / Camarilla)	BUILT_IN	1	{"params": {"variant": {"type": "str", "default": "STANDARD"}}}	\N	ind_pivots	t	\N	Pivot Points (Standard / Camarilla)	t	1	2026-10-20 06:44:12.072716+00
54	INDICATOR	MARKET_REGIME	Market Regime Classifier	BUILT_IN	1	null	\N	\N	f	\N	Market Regime Classifier	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: rule_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_versions (id, rule_id, version_no, content, change_note, status, created_at) FROM stdin;
1	1	1	{"when": {"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": ["RANGING", "SIDEWAYS", "BEARISH"]}, "operator": "IN"}, "effect": null, "unless": {"op": "ALL", "items": [{"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": "TRENDING_UP"}, "operator": "EQUALS"}, {"left": {"code": "ADX", "output": "adx", "params": null, "source": "INDICATOR"}, "right": {"param": "minAdx"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}, "parameters": {"minAdx": 20}}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
2	2	1	{"when": {"left": {"code": "MARKET_REGIME", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": ["RANGING", "SIDEWAYS", "BEARISH"]}, "operator": "IN"}, "effect": null}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
3	3	1	{"effect": null, "require": {"left": {"field": "grossTargetPerUnit", "source": "TRADE_PLAN"}, "right": {"const": 15}, "operator": "IS_ABOVE_OR_EQUAL"}}	Initial legacy rule version	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rules (id, code, name, rule_kind, rule_type, action, priority, applies_to, condition_text, current_version_id, evidence, review_by, executable, review_flags, provenance, enabled, status, created_at) FROM stdin;
1	EMPIRICAL-CALL-REGIME-001	Avoid calls outside a confirmed uptrend	GUARDRAIL	MARKET_REGIME	AVOID	HIGH	{"markets": ["NIFTY", "BANKNIFTY", "SENSEX"], "optionSides": ["CALL"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE", "PAPER"]}	Avoid CALL option entries when market regime shows RANGING, BEARISH or SIDEWAYS conditions. Empirical data from 52 CALL paper trades shows 34.6% aggregate win rate (20-24% in bearish/ranging markets) vs 51.3% on PUT trades in same period. STRONG_COUNTER_TREND failure pattern detected 14 times on vwap_pullback_v1. Only enter CALL when regime is confirmed TRENDING_UP with ADX > 20 and spot > VWAP.	1	{"count": 52, "justification": "Empirical data from 52 CALL paper trades shows 34.6% aggregate win rate.", "failureRatePct": 65.0, "successRatePct": 35.0}	\N	f	["REGIME_DEPENDENT_EVIDENCE"]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-CALL-REGIME-001", "EMPIRICAL-CALL-REGIME-001-PAPER"]}	t	1	2026-10-20 06:44:12.072716+00
2	EMPIRICAL-PUT-PREFERENCE-003	Prefer puts over calls in sideways or bearish regimes	GUARDRAIL	DIRECTION_PREFERENCE	PREFER	MEDIUM	{"markets": ["NIFTY", "BANKNIFTY", "SENSEX"], "optionSides": ["CALL", "PUT"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE"]}	Prefer PUT option entries over CALL entries when market regime is RANGING, SIDEWAYS, or BEARISH. In confirmed downtrend or sideways conditions, PUT entries have demonstrated significantly higher win rates and positive net P&L.	2	{"count": 91, "justification": "PUT win rate = 51.3% (net +7,089 INR) vs CALL win rate = 34.6% (net -10,533 INR).", "failureRatePct": 49.0, "successRatePct": 51.0}	\N	f	["REGIME_DEPENDENT_EVIDENCE"]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-PUT-PREFERENCE-003"]}	t	1	2026-10-20 06:44:12.072716+00
3	EMPIRICAL-SENSEX-NET-EV-002	Require minimum gross premium movement for SENSEX trades	GUARDRAIL	CAPITAL	WATCH	HIGH	{"markets": ["SENSEX"], "optionSides": ["CALL", "PUT"], "tradingModes": ["INTRADAY", "SHORT_TERM"], "executionDomains": ["LIVE"]}	For SENSEX trades (BSE lot size = 10), require minimum gross premium target movement of 15 INR per unit (= 150 INR gross per lot) before entering. Round-trip transaction costs for SENSEX are ~83-90 INR per lot.	3	{"count": 3, "justification": "Observed in 3 recent SENSEX TARGET_HIT trades with negative net_pnl due to friction costs.", "failureRatePct": 60.0, "successRatePct": 40.0}	\N	t	[]	{"source": "LEGACY_IMPORT", "legacy_ids": ["EMPIRICAL-SENSEX-NET-EV-002"]}	t	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategies (id, code, name, description, category, structure, bias, option_side, markets, underlying_types, exchange, trading_modes, execution_modes, timeframe, definition_format, executable, lifecycle_status, health, health_override, health_override_reason, health_override_until, validation_status, enabled, risk_profile, "references", risk_notes, how_it_works, tags, attributes, provenance, review_flags, current_version_id, status, created_at) FROM stdin;
1	ORB_15M	15-Minute Opening Range Breakout	Built-in textbook algorithmic trading strategy: 15-Minute Opening Range Breakout.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	1	1	2026-10-20 06:44:12.072716+00
2	PDH_PDL_BREAK	Previous Day High / Low Breakout	Built-in textbook algorithmic trading strategy: Previous Day High / Low Breakout.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "BREAKOUT"]	\N	{"source": "BUILT_IN"}	\N	2	1	2026-10-20 06:44:12.072716+00
3	VWAP_RECLAIM	VWAP Reclaim & Continuation	Built-in textbook algorithmic trading strategy: VWAP Reclaim & Continuation.	VWAP	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "VWAP"]	\N	{"source": "BUILT_IN"}	\N	3	1	2026-10-20 06:44:12.072716+00
4	EMA_PULLBACK	9/21 EMA Trend Pullback	Built-in textbook algorithmic trading strategy: 9/21 EMA Trend Pullback.	TREND	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "TREND"]	\N	{"source": "BUILT_IN"}	\N	4	1	2026-10-20 06:44:12.072716+00
5	SUPERTREND_ADX	Supertrend with ADX Confirmation	Built-in textbook algorithmic trading strategy: Supertrend with ADX Confirmation.	TREND	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "TREND"]	\N	{"source": "BUILT_IN"}	\N	5	1	2026-10-20 06:44:12.072716+00
6	BB_SQUEEZE	Bollinger Band Squeeze Breakout	Built-in textbook algorithmic trading strategy: Bollinger Band Squeeze Breakout.	VOLATILITY	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "VOLATILITY"]	\N	{"source": "BUILT_IN"}	\N	6	1	2026-10-20 06:44:12.072716+00
7	INSIDE_BAR_BREAK	Inside Bar Momentum Breakout	Built-in textbook algorithmic trading strategy: Inside Bar Momentum Breakout.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "BREAKOUT"]	\N	{"source": "BUILT_IN"}	\N	7	1	2026-10-20 06:44:12.072716+00
8	CPR_NARROW	Central Pivot Range (CPR) Trend Reversal	Built-in textbook algorithmic trading strategy: Central Pivot Range (CPR) Trend Reversal.	REVERSAL	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	8	1	2026-10-20 06:44:12.072716+00
9	RSI_LEVEL_REVERSAL	RSI Oversold Level Reversal	Built-in textbook algorithmic trading strategy: RSI Oversold Level Reversal.	REVERSAL	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	9	1	2026-10-20 06:44:12.072716+00
10	OI_WALL_BOUNCE	Open Interest Wall Support Bounce	Built-in textbook algorithmic trading strategy: Open Interest Wall Support Bounce.	OI_BASED	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "OI_BASED"]	\N	{"source": "BUILT_IN"}	\N	10	1	2026-10-20 06:44:12.072716+00
11	OI_BUILDUP_MOMENTUM	Call/Put Unwinding & OI Buildup	Built-in textbook algorithmic trading strategy: Call/Put Unwinding & OI Buildup.	OI_BASED	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "OI_BASED"]	\N	{"source": "BUILT_IN"}	\N	11	1	2026-10-20 06:44:12.072716+00
12	GAP_AND_GO	Morning Gap & Go Trend Continuation	Built-in textbook algorithmic trading strategy: Morning Gap & Go Trend Continuation.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	12	1	2026-10-20 06:44:12.072716+00
13	GAP_FADE	Morning Gap Fade Mean Reversion	Built-in textbook algorithmic trading strategy: Morning Gap Fade Mean Reversion.	REVERSAL	SINGLE_LONG	BEARISH	PUT	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "REVERSAL"]	\N	{"source": "BUILT_IN"}	\N	13	1	2026-10-20 06:44:12.072716+00
14	EXPIRY_MOMENTUM	Expiry Day Afternoon Momentum Spike	Built-in textbook algorithmic trading strategy: Expiry Day Afternoon Momentum Spike.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "MOMENTUM"]	\N	{"source": "BUILT_IN"}	\N	14	1	2026-10-20 06:44:12.072716+00
15	EVENT_REACTION	Macro Event Blackout & Trend Reaction	Built-in textbook algorithmic trading strategy: Macro Event Blackout & Trend Reaction.	EVENT	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	5m	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"targetRr": 2.0, "maxRiskPct": 15}	\N	\N	[{"title": "Entry Check", "description": "Verifies indicator threshold and entry criteria."}, {"title": "Risk Management", "description": "Strict 20% premium stop loss with fixed 1:2 risk-reward."}]	["BUILT_IN", "TEXTBOOK", "EVENT"]	\N	{"source": "BUILT_IN"}	\N	15	1	2026-10-20 06:44:12.072716+00
16	crudeoil_momentum_breakout_v1	Crude Oil Commodity Momentum Breakout V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	MOMENTUM	\N	\N	\N	["CRUDEOIL"]	["COMMODITY"]	MCX	["SHORT_TERM", "INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	DEGRADED	\N	\N	\N	UNTESTED	t	{"lotSize": 100, "targetRr": 2.2, "maxRiskPct": 20, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "MOMENTUM", "tradingModesRaw": "SHORT_TERM,INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	16	1	2026-10-20 06:44:12.072716+00
17	nifty_expiry_day_selling_v1	Nifty Expiry Day Selling	Open the position: Shortly after the market opens, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Switch for the final hour: Closes the first position and opens a tighter second one to capture the faster decay near expiry. Exit before close: Each sold option has its own stop-loss — 50% on each sell leg in the First setup and 70% in the Second setup* — and all positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 200000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 10000}	[]	[]	[{"title": "Open the position", "description": "Shortly after the market opens, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Switch for the final hour", "description": "Closes the first position and opens a tighter second one to capture the faster decay near expiry."}, {"title": "Exit before close", "description": "Each sold option has its own stop-loss — 50% on each sell leg in the First setup and 70% in the Second setup* — and all positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "algoverse_id": 19, "originalType": "IRON_CONDOR", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	17	1	2026-10-20 06:44:12.072716+00
18	banknifty_bearish_buying_v1	Bank Nifty Bearish Buying	Confirms the bearish trend: Uses Bollinger Bands, RSI, EMA, and CCI to check that Bank Nifty is under strong selling pressure. Validates participation: Confirms enough traded volume is behind the move before committing to a trade. Buys the put: Enters a Bank Nifty ATM put option once the signals line up. Manages the risk: Exits on SL or Target, whichever comes first. Actual exit price may vary slightly from what's set as SL or Target.	BREAKOUT	SINGLE_LONG	BEARISH	PUT	["BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 60000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 14730}	[]	[]	[{"title": "Confirms the bearish trend", "description": "Uses Bollinger Bands, RSI, EMA, and CCI to check that Bank Nifty is under strong selling pressure."}, {"title": "Validates participation", "description": "Confirms enough traded volume is behind the move before committing to a trade."}, {"title": "Buys the put", "description": "Enters a Bank Nifty ATM put option once the signals line up."}, {"title": "Manages the risk", "description": "Exits on SL or Target, whichever comes first. Actual exit price may vary slightly from what's set as SL or Target."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 9, "originalType": "BREAKDOWN", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:BANKNIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	18	1	2026-10-20 06:44:12.072716+00
19	nifty_credit_spread_pe_v1	Nifty Bull Put Credit Spread	Checks for strength: Uses Super Trend and Pivot Points to confirm Nifty has pushed above a key resistance level and is turning bullish. Places both legs: Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined. Exits: Closes the trade when Super Trend changes direction, or by the set exit time* — whichever comes first.	PREMIUM_SELLING	BULL_PUT_SPREAD	BULLISH	PUT	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 39753}	[]	[]	[{"title": "Checks for strength", "description": "Uses Super Trend and Pivot Points to confirm Nifty has pushed above a key resistance level and is turning bullish."}, {"title": "Places both legs", "description": "Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined."}, {"title": "Exits", "description": "Closes the trade when Super Trend changes direction, or by the set exit time* — whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 8, "originalType": "BULL_PUT_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	19	1	2026-10-20 06:44:12.072716+00
20	nifty_trend_surge_buying_v1	Trend Surge Buying	Confirm the trend: Checks that price is holding above the day's VWAP, showing genuine bullish strength. Validate the breakout: Confirms price has pushed above the previous day's high and the day's highest high before committing to a trade. Buy the call: Enters a Nifty call option around ₹200 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below VWAP or the option loses 30%, whichever comes first.	BREAKOUT	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 26887}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that price is holding above the day's VWAP, showing genuine bullish strength."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above the previous day's high and the day's highest high before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹200 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below VWAP or the option loses 30%, whichever comes first."}]	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 5, "originalType": "BREAKOUT", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	20	1	2026-10-20 06:44:12.072716+00
21	nifty_option_pulse_buying_v1	Option Pulse Buying	Confirm the trend: Checks that Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, RSI and CCI. Validate the breakout: Confirms price has pushed above key resistance and recent highs, using Signals such as Pivot Points, before committing to a trade. Buy the call: Enters a Nifty call option around ₹200 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the stop-loss triggers, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 20816}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, RSI and CCI."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above key resistance and recent highs, using Signals such as Pivot Points, before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹200 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the stop-loss triggers, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 6, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	21	1	2026-10-20 06:44:12.072716+00
22	breakout_trend_v1	Breakout & Key Level Trend V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	BREAKOUT	\N	\N	\N	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	HEALTHY	\N	\N	\N	UNTESTED	t	{"lotSize": null, "targetRr": 2.2, "maxRiskPct": 20, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "originalType": "BREAKOUT", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	22	1	2026-10-20 06:44:12.072716+00
23	paper_research_orb15_v1	Paper Research: Confirmed Opening-Range Breakout	Experimental long-call/put adaptation. Requires a complete 09:15–09:30 range, two closed breakout bars, trend alignment and no extended chase. Not validated for Indian index options.	BREAKOUT	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY", "SENSEX"]	["INDEX"]	\N	["INTRADAY"]	["PAPER"]	\N	EVALUATOR	f	ACTIVE	HEALTHY	\N	\N	\N	UNTESTED	t	{"marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[{"url": "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4729284", "scope": "US stocks in play; results do not establish an edge in Indian index options.", "title": "Zarattini, Barbon & Aziz: A Profitable Day Trading Strategy For The U.S. Equity Market"}, {"url": "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7428398", "scope": "2026 futures preprint with negative cost-adjusted results; a counterexample to universal ORB profitability.", "title": "Fetna: Opening-Range Breakout Does Not Survive Trading Costs"}, {"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr", "scope": "Volatility measurement and stop construction; not a return forecast.", "title": "Fidelity: Average True Range"}]	["One long-option lot only; no averaging down or multi-leg execution.", "No expiry-day entries. Bid/ask depth, real Greeks and costs are required.", "Premium stop uses a delta-times-ATR approximation, not an option pricing forecast.", "V3 position policy owns exits; local stops can fill worse after gaps."]	null	[]	{}	{"legacy": {"health": "ACTIVE", "status": "ACTIVE", "optionType": null, "originalType": "BREAKOUT", "executionModes": ["PAPER"], "researchStatus": "PAPER_HYPOTHESIS", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["RESEARCH_HYPOTHESIS_NOT_VALIDATED", "EVALUATOR_HANDLER_REQUIRED"]	23	1	2026-10-20 06:44:12.072716+00
24	nifty_momentum_option_buying_v1	Momentum Option Buying	Confirm the trend: Checks that Nifty is in a strong uptrend with expanding volatility, using Signals such as Super Trend and Bollinger Bands. Validate the breakout: Confirms momentum and a push above key resistance and recent highs, using Signals such as RSI, CCI, ADX and Pivot Points, along with a volume check for liquidity. Buy the call: Enters a Nifty call option around ₹240 premium once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the leg-wise stop-loss is hit, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 40000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 15690}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Nifty is in a strong uptrend with expanding volatility, using Signals such as Super Trend and Bollinger Bands."}, {"title": "Validate the breakout", "description": "Confirms momentum and a push above key resistance and recent highs, using Signals such as RSI, CCI, ADX and Pivot Points, along with a volume check for liquidity."}, {"title": "Buy the call", "description": "Enters a Nifty call option around ₹240 premium once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the leg-wise stop-loss is hit, whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 1, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	24	1	2026-10-20 06:44:12.072716+00
25	nifty_trend_catcher_v1	Nifty Trend Catcher	Watches both directions: Uses Super Trend, Bollinger Bands, RSI, and CCI to monitor Nifty for either a bullish breakout or a bearish breakdown, and commits to whichever triggers first. Validates the move: Confirms the breakout past key Pivot Point levels and recent highs or lows before committing to a trade. Buys the option: Enters a call for a bullish move or a put for a bearish move, around 0.66 delta, once the signals line up. Manages the risk: Exits when Super Trend reverses or the option loses 10% of its value, whichever comes first. If the trade exits in a loss, a defined opposite-side trade may follow with double the initial quantity if the reversal trade is confirmed.	TREND	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 21037}	[]	[]	[{"title": "Watches both directions", "description": "Uses Super Trend, Bollinger Bands, RSI, and CCI to monitor Nifty for either a bullish breakout or a bearish breakdown, and commits to whichever triggers first."}, {"title": "Validates the move", "description": "Confirms the breakout past key Pivot Point levels and recent highs or lows before committing to a trade."}, {"title": "Buys the option", "description": "Enters a call for a bullish move or a put for a bearish move, around 0.66 delta, once the signals line up."}, {"title": "Manages the risk", "description": "Exits when Super Trend reverses or the option loses 10% of its value, whichever comes first. If the trade exits in a loss, a defined opposite-side trade may follow with double the initial quantity if the reversal trade is confirmed."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "algoverse_id": 3, "originalType": "TREND", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	25	1	2026-10-20 06:44:12.072716+00
26	banknifty_bullish_buying_v1	Bank Nifty Bullish Buying	Confirm the trend: Checks that Bank Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, Bollinger Bands, RSI and CCI. Validate the breakout: Confirms price has pushed above key resistance and recent highs, using Signals such as Camarilla Pivot Points, before committing to a trade. Buy the call: Enters a Bank Nifty call option around 0.61 delta once the trend and breakout both line up. Manage the risk: Exits when price closes below Super Trend or the option loses 30%, whichever comes first.	MOMENTUM	SINGLE_LONG	BULLISH	CALL	["BANKNIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 45000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 17580}	[]	[]	[{"title": "Confirm the trend", "description": "Checks that Bank Nifty is in an uptrend with strong momentum behind it, using Signals such as Super Trend, Bollinger Bands, RSI and CCI."}, {"title": "Validate the breakout", "description": "Confirms price has pushed above key resistance and recent highs, using Signals such as Camarilla Pivot Points, before committing to a trade."}, {"title": "Buy the call", "description": "Enters a Bank Nifty call option around 0.61 delta once the trend and breakout both line up."}, {"title": "Manage the risk", "description": "Exits when price closes below Super Trend or the option loses 30%, whichever comes first."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 4, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:BANKNIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT", "TIME_EQUALS_NEEDS_REACHED_SEMANTICS"]	26	1	2026-10-20 06:44:12.072716+00
27	nifty_delta_strangle_v1	Nifty Intraday Delta Based Strangle	Open the position: At a fixed time in the session, sells a call and a put chosen by delta and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Manage the risk: Each sold option has its own stop-loss with trailing, and profit-booking locks in gains when the move goes its way. Exit before close: All positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 250000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 25000}	[]	[]	[{"title": "Open the position", "description": "At a fixed time in the session, sells a call and a put chosen by delta and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Manage the risk", "description": "Each sold option has its own stop-loss with trailing, and profit-booking locks in gains when the move goes its way."}, {"title": "Exit before close", "description": "All positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": null, "algoverse_id": 17, "originalType": "SHORT_STRANGLE", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS", "STRUCTURE_DERIVED_FROM_LEGS:SHORT_STRANGLE->IRON_CONDOR"]	27	1	2026-10-20 06:44:12.072716+00
28	nifty_credit_spread_ce_v1	Nifty Bear Call Credit Spread	Checks for weakness: Uses Super Trend and Pivot Points to confirm Nifty has broken below a support level and is turning bearish. Places both legs: Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined. Exits: Closes the trade when Super Trend flips direction, or by the set exit time* - whichever comes first.	PREMIUM_SELLING	BEAR_CALL_SPREAD	BEARISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 26002}	[]	[]	[{"title": "Checks for weakness", "description": "Uses Super Trend and Pivot Points to confirm Nifty has broken below a support level and is turning bearish."}, {"title": "Places both legs", "description": "Sells the ITM 2 option to collect premium, buys the OTM 8 option to keep risk defined."}, {"title": "Exits", "description": "Closes the trade when Super Trend flips direction, or by the set exit time* - whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 7, "originalType": "BEAR_CALL_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["INDICATOR_PARAMS_UNSPECIFIED", "TIMEFRAME_USES_ENGINE_DEFAULT"]	28	1	2026-10-20 06:44:12.072716+00
29	paper_research_ema_pullback_v1	Paper Research: EMA Trend Pullback	Experimental long-call/put adaptation. Requires aligned rising/falling EMA 9/21, a pullback to EMA 9, then a closed-bar continuation. Not a proven profitable strategy.	MOMENTUM	SINGLE_LONG	DYNAMIC	BOTH	["NIFTY", "BANKNIFTY", "SENSEX"]	["INDEX"]	\N	["INTRADAY"]	["PAPER"]	\N	EVALUATOR	f	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[{"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/ema", "scope": "Indicator mechanics and trend/support interpretation, not evidence of profitable option trading.", "title": "Fidelity: Exponential Moving Average"}, {"url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr", "scope": "Volatility measurement and stop construction; not a return forecast.", "title": "Fidelity: Average True Range"}]	["One long-option lot only; no averaging down or multi-leg execution.", "No expiry-day entries. Bid/ask depth, real Greeks and costs are required.", "Premium stop uses a delta-times-ATR approximation, not an option pricing forecast.", "V3 position policy owns exits; local stops can fill worse after gaps."]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "MOMENTUM", "executionModes": ["PAPER"], "researchStatus": "PAPER_HYPOTHESIS", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["RESEARCH_HYPOTHESIS_NOT_VALIDATED", "EVALUATOR_HANDLER_REQUIRED"]	29	1	2026-10-20 06:44:12.072716+00
30	nifty_ema_directional_put_v1	EMA-Based Intraday Directional	Check for bearish trend: Confirms Nifty is turning bearish when the 9 EMA crosses below the 36 EMA, signalling downward momentum. Buy the put: Enters a Nifty ATM put option once the crossover confirms. Manage the risk: Exits when the 9 EMA crosses back above the 36 EMA, or the stop loss hits, or the target is reached, whichever comes first.	MOMENTUM	SINGLE_LONG	BEARISH	PUT	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 30000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 15000}	[]	[]	[{"title": "Check for bearish trend", "description": "Confirms Nifty is turning bearish when the 9 EMA crosses below the 36 EMA, signalling downward momentum."}, {"title": "Buy the put", "description": "Enters a Nifty ATM put option once the crossover confirms."}, {"title": "Manage the risk", "description": "Exits when the 9 EMA crosses back above the 36 EMA, or the stop loss hits, or the target is reached, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "PUT", "algoverse_id": 16, "originalType": "MOMENTUM", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	[]	30	1	2026-10-20 06:44:12.072716+00
31	nifty_short_strangle_v1	Nifty Short Strangle	Open the position: At a fixed time after the open, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection. Earn through the session: Holds the hedged position to collect premium as the options lose value through the day. Manage the risk: Each sold option has its own stop-loss, and a strategy-level daily stop-loss caps the total loss for the day. Exit before close: All positions are squared off before the market ends.	PREMIUM_SELLING	IRON_CONDOR	NEUTRAL	BOTH	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	ACTIVE	DEGRADED	\N	\N	\N	UNTESTED	t	{"marginAmount": 250000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 28376}	[]	[]	[{"title": "Open the position", "description": "At a fixed time after the open, once early volatility settles, sells a call and a put and buys farther-out options on both sides as protection."}, {"title": "Earn through the session", "description": "Holds the hedged position to collect premium as the options lose value through the day."}, {"title": "Manage the risk", "description": "Each sold option has its own stop-loss, and a strategy-level daily stop-loss caps the total loss for the day."}, {"title": "Exit before close", "description": "All positions are squared off before the market ends."}]	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "algoverse_id": 2, "originalType": "SHORT_STRANGLE", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	["TIME_EQUALS_NEEDS_REACHED_SEMANTICS", "STRUCTURE_DERIVED_FROM_LEGS:SHORT_STRANGLE->IRON_CONDOR"]	31	1	2026-10-20 06:44:12.072716+00
32	vwap_pullback_v1	VWAP Dynamic Pullback V1	Descriptive legacy definition only (entry label and indicator list). Entry and exit rules are not specified, so it cannot be executed or evaluated.	VWAP	\N	\N	\N	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER"]	\N	SUMMARY	f	DRAFT	DEGRADED	\N	\N	\N	UNTESTED	t	{"lotSize": null, "targetRr": 2.0, "maxRiskPct": 18, "marginAmount": null, "riskCategory": null, "declaredMaxDrawdown": null}	[]	[]	null	[]	{}	{"legacy": {"health": "DEGRADED", "status": "ACTIVE", "optionType": null, "originalType": "VWAP", "tradingModesRaw": "INTRADAY"}, "source": "LEGACY_IMPORT"}	["NOT_EXECUTABLE_SUMMARY_ONLY"]	32	1	2026-10-20 06:44:12.072716+00
33	nifty_bearish_theta_capture_v1	Nifty Bearish Theta Capture	Check for bearish trend: Confirms Nifty is turning bearish when the 9 EMA crosses below the 20 EMA, signalling downward momentum. Place both legs: Sells the ATM option to collect the premium, then buys the OTM 20 option to keep risk defined. Manage the risk: Exits when the 9 EMA crosses back above the 20 EMA, the stop-loss hits, or by the set exit time, whichever comes first.	PREMIUM_SELLING	BEAR_CALL_SPREAD	BEARISH	CALL	["NIFTY"]	["INDEX"]	NSE	["INTRADAY"]	["PAPER", "LIVE"]	\N	RULE_TREE	t	SUSPENDED	SUSPENDED	\N	\N	\N	UNTESTED	t	{"marginAmount": 85000, "riskCategory": "high_risk_high_reward", "declaredMaxDrawdown": 20000}	[]	[]	[{"title": "Check for bearish trend", "description": "Confirms Nifty is turning bearish when the 9 EMA crosses below the 20 EMA, signalling downward momentum."}, {"title": "Place both legs", "description": "Sells the ATM option to collect the premium, then buys the OTM 20 option to keep risk defined."}, {"title": "Manage the risk", "description": "Exits when the 9 EMA crosses back above the 20 EMA, the stop-loss hits, or by the set exit time, whichever comes first."}]	[]	{}	{"legacy": {"health": "SUSPENDED", "status": "ACTIVE", "optionType": "CALL", "algoverse_id": 15, "originalType": "BEAR_CALL_SPREAD", "tradingModesRaw": "INTRADAY", "instrumentGroups": [["NFO:NIFTY"]]}, "source": "LEGACY_IMPORT"}	[]	33	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategy_health_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_health_events (id, strategy_id, from_health, to_health, reason, snapshot_id, triggered_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: strategy_performance_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_performance_snapshots (id, strategy_id, version_no, source, domain, period_from, period_to, as_of, total_trades, winning_trades, losing_trades, win_rate_pct, net_pnl, profit_factor, max_drawdown, legacy_health, reliability_flags, status, created_at) FROM stdin;
1	16	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	1	1	0	100.00	1810.60	10.00	0.00	DEGRADED	["LOW_SAMPLE", "PERFECT_RECORD_TINY_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
2	17	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	10	7	3	70.00	3800.00	2.20	450.00	ACTIVE	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
3	18	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	51	35	16	68.63	8529.50	2.00	450.00	ACTIVE	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
4	19	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	14	9	5	64.29	3083.60	0.65	450.00	DEGRADED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
5	20	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	52	33	19	63.46	54839.30	2.42	450.00	ACTIVE	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
6	21	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	86	51	35	59.30	-5710.80	0.76	450.00	SUSPENDED	["DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
7	22	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	9	5	4	55.56	1695.70	2.10	0.00	ACTIVE	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
8	23	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	19	9	10	47.37	1549.81	4.37	460.04	ACTIVE	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
9	24	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	26	12	14	46.15	-2694.05	0.10	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
10	25	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	48	22	26	45.83	3275.70	0.96	450.00	DEGRADED	["PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
11	26	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	26	11	15	42.31	-940.65	0.08	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
12	27	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	19	8	11	42.11	-1005.05	0.13	450.00	SUSPENDED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
13	28	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	17	7	10	41.18	3531.25	0.00	450.00	SUSPENDED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
14	29	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	10	4	6	40.00	-2689.19	0.15	2689.19	DEGRADED	["LOW_SAMPLE"]	1	2026-10-20 06:44:12.072716+00
15	30	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	43	17	26	39.53	2049.60	1.05	29997.30	SUSPENDED	[]	1	2026-10-20 06:44:12.072716+00
16	31	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	29	11	18	37.93	-6486.65	0.06	450.00	DEGRADED	["LOW_SAMPLE", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
17	32	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	137	51	86	37.23	-8562.62	0.87	25809.75	DEGRADED	[]	1	2026-10-20 06:44:12.072716+00
18	33	1	LEGACY_IMPORT	UNKNOWN	\N	\N	\N	25	9	16	36.00	1038.70	0.54	450.00	SUSPENDED	["LOW_SAMPLE", "PF_PNL_INCONSISTENT", "DRAWDOWN_PLACEHOLDER"]	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: strategy_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_rules (id, strategy_version_id, rule_id, role, required, weight, sort_order, param_overrides, status, created_at) FROM stdin;
\.


--
-- Data for Name: strategy_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_versions (id, strategy_id, version_no, schema_version, definition, content_hash, change_note, status, created_at) FROM stdin;
1	1	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
2	2	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
3	3	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
4	4	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
5	5	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
6	6	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
7	7	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
8	8	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
9	9	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
10	10	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
11	11	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
12	12	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
13	13	1	2	{"cases": [{"key": "0", "bias": "BEARISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	54f0ef8380fa3545b0b6978a7202926fd5f9aac972b8334f963a904a3ef0d8a3	Initial built-in version	1	2026-10-20 06:44:12.072716+00
14	14	1	2	{"cases": [{"key": "0", "bias": "BULLISH", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	2aad7681803ec07d4c524ace526ddc8f17b00dacd815aa2b910bb4d72841c0b1	Initial built-in version	1	2026-10-20 06:44:12.072716+00
15	15	1	2	{"cases": [{"key": "0", "bias": "DYNAMIC", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}}, "extras": {}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:20"}, "dayStopGain": {"type": "AMOUNT", "value": 6000}, "dayStopLoss": {"type": "AMOUNT", "value": 3000}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "parameters": {"targetRr": 2.0}, "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	e717e214d7cd9a55dbb39f9745697a0c91db437055b055adc05a7926750fc5f5	Initial built-in version	1	2026-10-20 06:44:12.072716+00
16	16	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": 1, "lotSize": 100, "exchange": "MCX", "targetRr": 2.2, "entryLabel": "momentum_breakout", "indicators": ["VWAP", "EMA_9", "EMA_21", "ATR_14"], "maxRiskPct": 20}, "schemaVersion": 2}	930c2822c69528a349259b8824276bd2d4a4cb53beeeed3e162da6763601fb44	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
17	17	1	2	{"cases": [{"key": "0", "exit": null, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["3"], "trigger": "ExitedInLoss"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 85}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["4"], "trigger": "ExitedInLoss"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 85}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 10, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -10, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:29:00"}, "operator": "EQUALS"}, {"left": {"field": "daysToExpire", "source": "CONTEXT"}, "right": {"const": 0}, "operator": "EQUALS"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:24:00"}, "operator": "EQUALS"}, "actions": [{"type": "CLOSE_LEG", "legId": "1"}, {"type": "CLOSE_LEG", "legId": "2"}, {"type": "CLOSE_LEG", "legId": "3"}, {"type": "CLOSE_LEG", "legId": "4"}]}, {"key": "A2", "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:25:00"}, "operator": "EQUALS"}, {"left": {"field": "daysToExpire", "source": "CONTEXT"}, "right": {"const": 0}, "operator": "EQUALS"}]}, "actions": [{"side": "SELL", "type": "OPEN_LEG", "legId": "9", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["11"], "trigger": "ExitedInLoss"}]}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 70}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -1, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "type": "OPEN_LEG", "legId": "10", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["12"], "trigger": "ExitedInLoss"}]}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 70}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 1, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "type": "OPEN_LEG", "legId": "11", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 7, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "type": "OPEN_LEG", "legId": "12", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -7, "selector": "ATM_OFFSET"}, "optionType": "PE"}}]}, {"key": "A3", "when": {"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "3"}]}, {"key": "A4", "when": {"left": {"field": "hasExitedInLoss", "legId": "2", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "4"}]}, {"key": "A5", "when": {"left": {"field": "hasExitedInLoss", "legId": "9", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "11"}]}, {"key": "A6", "when": {"left": {"field": "hasExitedInLoss", "legId": "10", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "12"}]}]}], "bounds": {"session": {"exitTime": "15:28", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	330a9b83f7c4cacdbe89bf61161e8ae313b25d5fe5d66cc93dc6551528cf6f75	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
18	18	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 200}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 10, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "MONTHLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "3m"}, "right": {"code": "BBANDS", "output": "lower", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 24}, "operator": "IS_BELOW"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": -150}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:10:00"}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:24:00"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "volume", "source": "PRICE", "timeframe": "3m"}, "right": {"const": 50000}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "dayStopGain": {"type": "AMOUNT", "value": 2000}, "dayStopLoss": {"type": "AMOUNT", "value": 4000}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	cffb311b3d7d24dd6a1ef36caf2309baf9aea6c21df9db47f5cde2dd0124e78f	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
19	19	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -8, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	3891b29c422bb615006e3c1cfb40945fa5337b61a4eb2f332a807153da2738b5	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
20	20	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"code": "VWAP", "output": "currentDay", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 5}, "value": 30}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 200, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"day": "YESTERDAY", "field": "high", "source": "DAY"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": "5m"}, "right": {"day": "TODAY", "field": "previousHighestHigh", "source": "DAY"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1, "strategyStopLoss": {"type": "AMOUNT", "value": 3000}}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	be78f33bac744a7ec2d4294874fcdf542a6a2d83cb07660e79211b290ca60dd1	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
21	21	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "POINTS", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 15, "trailingValue": 15}, "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 200, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:21:00"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 100}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	ac26d58ab6213a92bb80c7cb391b3fe6d1cebfabafaf54fda72d8ae6820eb5f1	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
22	22	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": null, "lotSize": null, "exchange": null, "targetRr": 2.2, "entryLabel": "breakout", "indicators": ["SUPPORT_RESISTANCE", "DAY_HIGH_LOW", "VOLUME"], "maxRiskPct": 20}, "schemaVersion": 2}	e69d4c2339ef5b3a2acd8d668c840928dda3c4e367e466e6adad325821293aac	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
23	23	1	2	{"extras": {"version": 1, "reviewedOn": "2026-09-25", "performanceClaims": null}, "format": "EVALUATOR", "evaluator": "ORB15", "parameters": {"fastEma": 9, "slowEma": 21, "atrPeriod": 14, "rewardRisk": 2.0, "entryCutoff": "14:30", "maxAbsDelta": 0.7, "minAbsDelta": 0.35, "maxSpreadPct": 2.0, "stopAtrMultiple": 1.5, "minCompletedBars": 35, "maxPremiumRiskPct": 20.0, "minPremiumRiskPct": 5.0, "maxQuoteAgeSeconds": 60, "maxFrictionToReward": 0.25, "openingRangeMinutes": 15, "maxCapitalAllocationPct": 20.0}, "riskPolicy": {"stopMode": "EVALUATOR_OWNED"}, "schemaVersion": 2}	466dd0f8b56cdf308fbf03187820ee415ac9d06d9d67236a22a317bbdc4cb858	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
24	24	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "AMOUNT", "basis": "POSITION_TOTAL", "value": 13500}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"premium": 240, "selector": "PREMIUM", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "upper", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 141}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:21:00"}, "operator": "IS_ABOVE"}, {"left": {"code": "ADX", "output": "adx", "params": null, "source": "INDICATOR"}, "right": {"const": 33}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "volume", "source": "PRICE", "timeframe": null}, "right": {"const": 100000}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 10}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	43f23524f7356a0325daf40d037c5b63c6f64215b040b4e7a073683a4227a0fd	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
25	25	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_BELOW"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "middle", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 120}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:19:00"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "CURRENT", "field": "open", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"op": "ALL", "items": [{"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}, "actions": [{"side": "BUY", "type": "OPEN_LEG", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 2}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}]}]}, {"key": "1", "exit": {"when": {"op": "ANY", "items": [{"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_ABOVE"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "middle", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 30}, "operator": "IS_BELOW"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": -120}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "low", "source": "PRICE", "timeframe": null}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:19:00"}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "CURRENT", "field": "open", "source": "PRICE", "timeframe": null}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"op": "ALL", "items": [{"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "1"}, "right": {"const": 1}, "operator": "EQUALS"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}]}, "actions": [{"side": "BUY", "type": "OPEN_LEG", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 2}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 10}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.66, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}]}]}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "dayStopGain": {"type": "AMOUNT", "value": 1500}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	c7c8e31f0939eb6ed7db42c9c7278cb54e5f25e56d2747ee177ca98265dee583	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
26	26	1	2	{"cases": [{"key": "0", "exit": {"when": {"op": "ANY", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "EQUALS"}]}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 30}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "MONTHLY", "index": 1}, "strike": {"delta": 0.61, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "BBANDS", "output": "upper", "params": null, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"code": "RSI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 70}, "operator": "IS_ABOVE"}, {"left": {"code": "CCI", "output": "value", "params": null, "source": "INDICATOR"}, "right": {"const": 120}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "R4", "params": {"variant": "CAMARILLA"}, "source": "INDICATOR"}, "operator": "IS_ABOVE"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"bar": "PREVIOUS", "field": "high", "source": "PRICE", "timeframe": null}, "operator": "IS_ABOVE"}, {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:24:00"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	4f1a84668834e6905b425523e21ca44580c6fbab9216007dd18b2c6b71ab59be	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
27	27	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "14:15:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.4, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}, {"side": "SELL", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 20}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.4, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}, {"side": "BUY", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.15, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "PE"}}, {"side": "BUY", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"delta": 0.15, "selector": "DELTA", "comparison": "NEAREST"}, "optionType": "CE"}}], "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "10:00:00"}, "operator": "EQUALS"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	63cf8b66607e8352f2dbe01e942a29c6dfdd3c58b011114b6504edd02e84677c	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
28	28	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "CROSSES_ABOVE"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 8, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"op": "ALL", "items": [{"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "SUPERTREND", "output": "value", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}, {"left": {"bar": "CURRENT", "field": "close", "source": "PRICE", "timeframe": null}, "right": {"code": "PIVOT_POINTS", "output": "S1", "params": null, "source": "INDICATOR"}, "operator": "IS_BELOW"}]}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 2}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	6a4af53107fe1bcafa12e9d7eb624e3d4e41f1c68df8d9b69aa0b92b7a63d946	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
29	29	1	2	{"extras": {"version": 1, "reviewedOn": "2026-09-25", "performanceClaims": null}, "format": "EVALUATOR", "evaluator": "EMA_PULLBACK", "parameters": {"fastEma": 9, "slowEma": 21, "atrPeriod": 14, "rewardRisk": 2.0, "entryCutoff": "14:30", "maxAbsDelta": 0.7, "minAbsDelta": 0.35, "maxSpreadPct": 2.0, "stopAtrMultiple": 1.5, "minCompletedBars": 35, "maxPremiumRiskPct": 20.0, "minPremiumRiskPct": 5.0, "maxQuoteAgeSeconds": 60, "maxFrictionToReward": 0.25, "openingRangeMinutes": 15, "maxCapitalAllocationPct": 20.0}, "riskPolicy": {"stopMode": "EVALUATOR_OWNED"}, "schemaVersion": 2}	0d735fa5b2e9aaa041d9436759933969ff8203d70c22b1050c65b07f12f01017	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
30	30	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 36}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_ABOVE"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 5}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 36}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_BELOW"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "14:15", "entryTime": "09:30"}, "expiryHandling": {}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	d2981fe68ce0014550ef471a9cef2d754a34739aeb94df0424a9c09126144acf	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
31	31	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "15:14:00"}, "operator": "EQUALS"}}, "entry": {"legs": [{"side": "BUY", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 20, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -20, "selector": "ATM_OFFSET"}, "optionType": "PE"}}, {"side": "SELL", "legId": "3", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 2, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "SELL", "legId": "4", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 50}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": -2, "selector": "ATM_OFFSET"}, "optionType": "PE"}}], "when": {"left": {"field": "timeOfDay", "source": "TIME"}, "right": {"type": "TIME", "const": "09:20:00"}, "operator": "EQUALS"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": []}], "bounds": {"session": {"exitTime": "15:14", "entryTime": "09:15"}, "expiryHandling": {}, "maxTradesPerDay": 1, "strategyStopLoss": {"type": "AMOUNT", "value": 3000}}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	08086f5bba390bbf55ab861c107303c5262381d3624174c204d37c2de1260ecc	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
32	32	1	2	{"extras": {}, "format": "SUMMARY", "summary": {"legs": null, "lotSize": null, "exchange": null, "targetRr": 2.0, "entryLabel": "vwap_bounce", "indicators": ["VWAP", "RSI_14", "PRICE_ACTION"], "maxRiskPct": 18}, "schemaVersion": 2}	86628024af1a9afc9fd83341cfa25d52a488d8550cd33e1c7c3e8a241f43961f	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
33	33	1	2	{"cases": [{"key": "0", "exit": {"when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 20}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_ABOVE"}}, "entry": {"legs": [{"side": "SELL", "legId": "1", "extras": {"uiConfigs": {"quickAdjustments": [{"action": "CloseLeg", "targets": ["2"], "trigger": "ExitedInLoss"}, {"action": "CloseLeg", "targets": ["2"], "trigger": "ExitedInProfit"}]}}, "target": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "value": 100}, "quantity": {"unit": "LOT", "value": 1}, "stopLoss": {"type": "PERCENT", "basis": "ENTRY_PREMIUM", "trail": {"type": "LINEAR", "adjustValue": 5, "trailingValue": 10}, "value": 15}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 0, "selector": "ATM_OFFSET"}, "optionType": "CE"}}, {"side": "BUY", "legId": "2", "extras": {"uiConfigs": {"quickAdjustments": []}}, "quantity": {"unit": "LOT", "value": 1}, "instrument": {"kind": "OPTION", "expiry": {"cycle": "WEEKLY", "index": 1}, "strike": {"steps": 20, "selector": "ATM_OFFSET"}, "optionType": "CE"}}], "when": {"left": {"code": "EMA", "output": "value", "params": {"period": 9}, "source": "INDICATOR", "instance": "fast", "paramsSource": "HOW_IT_WORKS_TEXT"}, "right": {"code": "EMA", "output": "value", "params": {"period": 20}, "source": "INDICATOR", "instance": "slow", "paramsSource": "HOW_IT_WORKS_TEXT"}, "operator": "IS_BELOW"}}, "extras": {"uiConfigs": {"isMoveToCost": false}}, "adjustments": [{"key": "A1", "when": {"left": {"field": "hasExitedInLoss", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "2"}]}, {"key": "A2", "when": {"left": {"field": "hasExitedInProfit", "legId": "1", "source": "POSITION", "caseKey": "0"}, "right": {"const": 1}, "operator": "EQUALS"}, "extras": {"uiConfigs": {"adjustmentMode": "quickAdjustment", "isAutoAdjustment": true}}, "actions": [{"type": "CLOSE_LEG", "legId": "2"}]}]}], "bounds": {"session": {"exitTime": "14:15", "entryTime": "09:45"}, "expiryHandling": {}, "maxTradesPerDay": 3}, "extras": {}, "format": "RULE_TREE", "riskPolicy": {"stopMode": "STRATEGY_FIXED"}, "schemaVersion": 2, "isParallelCases": false}	d33d5efe4cc2294ed8cbbcba654a2a20ec78cc4c638c8a958b87fdc710b08df0	Legacy converted seed version	1	2026-10-20 06:44:12.072716+00
\.


--
-- Data for Name: upstox_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.upstox_configs (id, user_id, api_key, api_secret_enc, mobile, pin_enc, totp_secret_enc, access_token_enc, redirect_uri, auto_auth_enabled, token_expires_at, auth_status, last_auth_at, last_error, upstox_user_id, profile_name, email, status, created_at) FROM stdin;
1	1	d9a56b8d-da64-4589-a2a7-d41211a4d642	b+TegRw2uK5Znoluj1UvGt6oV01CDJ3O8lesckxBaRZpSlYS/9k=	8301980013	GrFs+cjqdm1obu/igHxkpRfHfx2j6whMOJAJ18dqXkT0dA==	lQRKK1W6CvhqJxUWrp3kXDimsUlt9+9dYpwJiaqbrtb0P2PK/HkW2wS2ZOjnSj5jUuYgrViEpUlrq1GU	50dAFEfRX1GxEMSn7R9E41viCHDdNjMc68mXg/8+2itvMauG1eAZvXxnIcUqctPdxryNWUfwS0U/mwVVgECrqh39H/nVrRDDeZokfqUfb8ISeOq44+hgiaWonFRqK+ZJPAsX7ACyl9r+hxAk+NpKIECoJ7ZYwtAZMLZRbygmj6r7uFgauZROgAgPjDmrZd0hgJwJAinMBqyBosYQ0bkZNtInXffM6qvzo2Zq1cw0eo71kE+tPJk82Txdk5CPg8AmLGUM4B/sTjCfytSDvmOIoIKKtynLDFza6P9jsUULUwt9uddhVMJV5l/UVFfwLTwBc5OvYn7StcyUYyVb2JVrXgC6ib/ugd8Nv6HPwqcNTErh/w8RFdkx4M0mCh/qsvxuTk1PcLFj3uXgjj+lF4P5cDpZDbnIzV4RQgQjdAg3fE+Z3st9LbhTyycU5uWUC/dwTUiG	http://localhost/api/v1/upstox/callback/1	t	2026-10-20 12:39:19.582642+00	VALID	2026-10-19 12:39:19.582642+00	\N	JW9356	ALEN XAVIER	alenxavier36@gmail.com	1	2026-10-19 11:56:23.757117+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, is_default, status, created_at) FROM stdin;
1	Alen Xavier	t	1	2026-10-19 11:56:23.757117+00
\.


--
-- Name: health_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.health_policies_id_seq', 1, true);


--
-- Name: import_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.import_batches_id_seq', 1, false);


--
-- Name: registry_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.registry_items_id_seq', 54, true);


--
-- Name: rule_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rule_versions_id_seq', 3, true);


--
-- Name: rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rules_id_seq', 3, true);


--
-- Name: strategies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategies_id_seq', 33, true);


--
-- Name: strategy_health_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_health_events_id_seq', 1, false);


--
-- Name: strategy_performance_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_performance_snapshots_id_seq', 18, true);


--
-- Name: strategy_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_rules_id_seq', 1, false);


--
-- Name: strategy_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_versions_id_seq', 33, true);


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.upstox_configs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: health_policies health_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_policies
    ADD CONSTRAINT health_policies_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: registry_items registry_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registry_items
    ADD CONSTRAINT registry_items_pkey PRIMARY KEY (id);


--
-- Name: rule_versions rule_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: strategies strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT strategies_pkey PRIMARY KEY (id);


--
-- Name: strategy_health_events strategy_health_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events
    ADD CONSTRAINT strategy_health_events_pkey PRIMARY KEY (id);


--
-- Name: strategy_performance_snapshots strategy_performance_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots
    ADD CONSTRAINT strategy_performance_snapshots_pkey PRIMARY KEY (id);


--
-- Name: strategy_rules strategy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules
    ADD CONSTRAINT strategy_rules_pkey PRIMARY KEY (id);


--
-- Name: strategy_versions strategy_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions
    ADD CONSTRAINT strategy_versions_pkey PRIMARY KEY (id);


--
-- Name: upstox_configs upstox_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_health_policies_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_health_policies_code_active ON public.health_policies USING btree (code) WHERE (status = 1);


--
-- Name: ix_registry_items_type_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registry_items_type_code_active ON public.registry_items USING btree (registry_type, code) WHERE (status = 1);


--
-- Name: ix_rule_versions_rule_ver_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rule_versions_rule_ver_active ON public.rule_versions USING btree (rule_id, version_no) WHERE (status = 1);


--
-- Name: ix_rules_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rules_code_active ON public.rules USING btree (code) WHERE (status = 1);


--
-- Name: ix_strategies_code_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategies_code_active ON public.strategies USING btree (code) WHERE (status = 1);


--
-- Name: ix_strategy_versions_strat_ver_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategy_versions_strat_ver_active ON public.strategy_versions USING btree (strategy_id, version_no) WHERE (status = 1);


--
-- Name: ix_upstox_configs_user_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_upstox_configs_user_id_active ON public.upstox_configs USING btree (user_id) WHERE (status = 1);


--
-- Name: ix_users_name_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_name_active ON public.users USING btree (name) WHERE (status = 1);


--
-- Name: rule_versions rule_versions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rules(id) ON DELETE CASCADE;


--
-- Name: strategy_health_events strategy_health_events_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_health_events
    ADD CONSTRAINT strategy_health_events_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_performance_snapshots strategy_performance_snapshots_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_performance_snapshots
    ADD CONSTRAINT strategy_performance_snapshots_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_rules strategy_rules_strategy_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_rules
    ADD CONSTRAINT strategy_rules_strategy_version_id_fkey FOREIGN KEY (strategy_version_id) REFERENCES public.strategy_versions(id) ON DELETE CASCADE;


--
-- Name: strategy_versions strategy_versions_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_versions
    ADD CONSTRAINT strategy_versions_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: upstox_configs upstox_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 2umJqLa0SAmFd8vJEmwlvNNlccwO4VC2GMdZzsRnV6incdjEUzTgJLmPLWY920r

