--
-- PostgreSQL database dump
--

\restrict RYfFSeXYRD0XiviDYcXAmLuWIm6XRapuUjgW3jFXvAvOdIcNoOVkdWSYDX7ZWWS

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg12+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_user_id_fkey;
DROP INDEX IF EXISTS public.ix_users_name_active;
DROP INDEX IF EXISTS public.ix_upstox_configs_user_id_active;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.upstox_configs DROP CONSTRAINT IF EXISTS upstox_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.upstox_configs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.upstox_configs_id_seq;
DROP TABLE IF EXISTS public.upstox_configs;
DROP TABLE IF EXISTS public.alembic_version;
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: upstox_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upstox_configs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    api_key character varying(100) DEFAULT ''::character varying NOT NULL,
    api_secret_enc text DEFAULT ''::text NOT NULL,
    mobile character varying(15) DEFAULT ''::character varying NOT NULL,
    pin_enc text DEFAULT ''::text NOT NULL,
    totp_secret_enc text DEFAULT ''::text NOT NULL,
    access_token_enc text,
    redirect_uri character varying(300) DEFAULT ''::character varying NOT NULL,
    auto_auth_enabled boolean DEFAULT true NOT NULL,
    token_expires_at timestamp with time zone,
    auth_status character varying(20) DEFAULT 'NEVER'::character varying NOT NULL,
    last_auth_at timestamp with time zone,
    last_error character varying(500),
    upstox_user_id character varying(50),
    profile_name character varying(100),
    email character varying(150),
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.upstox_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.upstox_configs_id_seq OWNED BY public.upstox_configs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: upstox_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs ALTER COLUMN id SET DEFAULT nextval('public.upstox_configs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0001_create_users
\.


--
-- Data for Name: upstox_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.upstox_configs (id, user_id, api_key, api_secret_enc, mobile, pin_enc, totp_secret_enc, access_token_enc, redirect_uri, auto_auth_enabled, token_expires_at, auth_status, last_auth_at, last_error, upstox_user_id, profile_name, email, status, created_at) FROM stdin;
1	1	d9a56b8d-da64-4589-a2a7-d41211a4d642	b+TegRw2uK5Znoluj1UvGt6oV01CDJ3O8lesckxBaRZpSlYS/9k=	8301980013	GrFs+cjqdm1obu/igHxkpRfHfx2j6whMOJAJ18dqXkT0dA==	lQRKK1W6CvhqJxUWrp3kXDimsUlt9+9dYpwJiaqbrtb0P2PK/HkW2wS2ZOjnSj5jUuYgrViEpUlrq1GU	50dAFEfRX1GxEMSn7R9E41viCHDdNjMc68mXg/8+2itvMauG1eAZvXxnIcUqctPdxryNWUfwS0U/mwVVgECrqh39H/nVrRDDeZokfqUfb8ISeOq44+hgiaWonFRqK+ZJPAsX7ACyl9r+hxAk+NpKIECoJ7ZYwtAZMLZRbygmj6r7uFgauZROgAgPjDmrZd0hgJwJAinMBqyBosYQ0bkZNtInXffM6qvzo2Zq1cw0eo71kE+tPJk82Txdk5CPg8AmLGUM4B/sTjCfytSDvmOIoIKKtynLDFza6P9jsUULUwt9uddhVMJV5l/UVFfwLTwBc5OvYn7StcyUYyVb2JVrXgC6ib/ugd8Nv6HPwqcNTErh/w8RFdkx4M0mCh/qsvxuTk1PcLFj3uXgjj+lF4P5cDpZDbnIzV4RQgQjdAg3fE+Z3st9LbhTyycU5uWUC/dwTUiG	http://localhost/api/v1/upstox/callback/1	t	2026-10-20 12:39:19.582642+00	VALID	2026-10-19 12:39:19.582642+00	\N	JW9356	ALEN XAVIER	alenxavier36@gmail.com	1	2026-10-19 11:56:23.757117+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, is_default, status, created_at) FROM stdin;
1	Alen Xavier	t	1	2026-10-19 11:56:23.757117+00
\.


--
-- Name: upstox_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.upstox_configs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: upstox_configs upstox_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_upstox_configs_user_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_upstox_configs_user_id_active ON public.upstox_configs USING btree (user_id) WHERE (status = 1);


--
-- Name: ix_users_name_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_name_active ON public.users USING btree (name) WHERE (status = 1);


--
-- Name: upstox_configs upstox_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upstox_configs
    ADD CONSTRAINT upstox_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RYfFSeXYRD0XiviDYcXAmLuWIm6XRapuUjgW3jFXvAvOdIcNoOVkdWSYDX7ZWWS

